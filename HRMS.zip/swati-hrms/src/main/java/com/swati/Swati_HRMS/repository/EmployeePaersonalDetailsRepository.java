package com.swati.Swati_HRMS.repository;


import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface EmployeePaersonalDetailsRepository extends JpaRepository<EmployeePersonalDetails, Long> {
    List<EmployeePersonalDetails> findBySuspendedStatus(int suspendedStatus);
    Optional<EmployeePersonalDetails> findByEmployeeCode(String employeeCode);
}
