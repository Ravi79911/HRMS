package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.EmpEducationDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface EmpEducationRepository extends JpaRepository<EmpEducationDetails, Long> {
    List<EmpEducationDetails> findByEmployeePersonalDetails_Id(Long empId);
}
