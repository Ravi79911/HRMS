package com.swati.Swati_HRMS.dto;

import com.swati.Swati_HRMS.model.DocumentList;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class EmployeeDocumentsDTO {

    private Long id;
    private String docFile;
    private String createdBy;
    private LocalDateTime createdDate;
    private DocumentList documents;
}
