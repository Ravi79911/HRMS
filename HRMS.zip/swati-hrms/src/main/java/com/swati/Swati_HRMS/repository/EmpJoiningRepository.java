package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.EmpJoiningDetails;
import com.swati.Swati_HRMS.model.EmployeeDependent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface EmpJoiningRepository extends JpaRepository<EmpJoiningDetails, Long> {

    List<EmpJoiningDetails> findByEmployeePersonalDetails_Id(Long empId);
}
