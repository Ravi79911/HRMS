package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.SkillList;
import com.swati.Swati_HRMS.repository.SkillListRepository;
import com.swati.Swati_HRMS.service.SkillListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class SkillListServiceImpl implements SkillListService {

    @Autowired
    private SkillListRepository skillListRepository;

    @Override
    public SkillList saveSkill(SkillList skillList) {
        skillList.setCreatedDate(LocalDateTime.now());
        skillList.setSuspendedStatus(0);
        return skillListRepository.save(skillList);
    }

    @Override
    public List<SkillList> getAllSkill() {
        return skillListRepository.findBySuspendedStatus(0);
    }

    @Override
    public Optional<SkillList> updateSkillById(Long id, SkillList updatedSkillList) {
        Optional<SkillList> skillList = skillListRepository.findById(id);
        if (skillList.isPresent()) {
            skillList.get().setUpdatedDate(LocalDateTime.now());
            skillList.get().setUpdatedBy(updatedSkillList.getUpdatedBy());
            skillList.get().setSkillName(updatedSkillList.getSkillName());
            skillListRepository.save(skillList.get());
        }
        return skillList;
    }

    @Override
    public Optional<SkillList> changeStatusOfSkillById(Long id) {
        Optional<SkillList> skillList = skillListRepository.findById(id);
        if (skillList.isPresent()) {
            skillList.get().setSuspendedStatus(1);
            skillListRepository.save(skillList.get());
        }
        return skillList;

    }
}
