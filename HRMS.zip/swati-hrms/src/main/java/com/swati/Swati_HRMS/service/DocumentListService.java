package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.DocumentList;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface DocumentListService {

    DocumentList saveDocument(DocumentList documentList);
    Optional<DocumentList> updateDocument(Long id, DocumentList documentList);
    Optional<DocumentList> changeStatusOfDocumentById(Long id);
    List<DocumentList> getAllDocument();
}
