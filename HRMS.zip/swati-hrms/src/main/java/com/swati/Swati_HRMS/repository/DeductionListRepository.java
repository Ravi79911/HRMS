package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.DeductionList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface DeductionListRepository extends JpaRepository<DeductionList, Long> {
    List<DeductionList> findAllBySuspendedStatus(int suspendedStatus);
}
