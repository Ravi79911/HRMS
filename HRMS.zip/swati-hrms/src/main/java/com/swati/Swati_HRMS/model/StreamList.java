package com.swati.Swati_HRMS.model;


import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Data
@Entity
@Table(name = "streams")
public class StreamList {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Long id;

	@Column(name="stream")
	private String stream;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private LocalDateTime createdDate;

	@Column(name = "updated_by")
	private String updatedBy;

	@Column(name = "updated_date")
	private LocalDateTime updatedDate;

	@Column(name = "suspendend_status")
	private int suspendedStatus;

	@OneToMany(mappedBy = "streamCourse", cascade = CascadeType.ALL)
	private Set<EmpEducationDetails> educationDetails;
}
