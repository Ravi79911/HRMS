package com.swati.Swati_HRMS.controller;


import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import com.swati.Swati_HRMS.service.EmployeePersonalDeatilsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/employeePersonalDetails")
public class EmployeePersonalDetailsController {

    @Autowired
    private EmployeePersonalDeatilsService employeePersonalDeatilsService;

    @PostMapping("/saveEmployeePersonalDetails")
    public ResponseEntity<EmployeePersonalDetails> saveEmployeePersonalDetails(@RequestBody EmployeePersonalDetails employeePersonalDetails) {
        return ResponseEntity.ok(employeePersonalDeatilsService.saveEmployeePersonalDetails(employeePersonalDetails));
    }

    @GetMapping("/getAllEmployeePersonalDetails")
    public ResponseEntity<List<EmployeePersonalDetails>> getAllEmployeePersonalDetails() {
        return ResponseEntity.ok(employeePersonalDeatilsService.getAllDocument());
    }

    @PutMapping("/updateEmployeePersonalDetails/{id}")
    public ResponseEntity<Optional<EmployeePersonalDetails>> updateEmployeePersonalDetails(@PathVariable Long id, @RequestBody EmployeePersonalDetails employeePersonalDetails) {
        return ResponseEntity.ok(employeePersonalDeatilsService.updateEmployeePersonalDetails(id, employeePersonalDetails));
    }

    @PatchMapping("/deleteBy/{id}")
    public ResponseEntity<EmployeePersonalDetails> deleteEmployeePersonalDetails(@PathVariable("id") Long id) {
        Optional<EmployeePersonalDetails> deleted = employeePersonalDeatilsService.changeStatusOfDocumentById(id);
        return deleted.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/findById/{id}")
    public ResponseEntity<Optional<EmployeePersonalDetails>> findById(@PathVariable("id") Long id) {
        return ResponseEntity.ok(employeePersonalDeatilsService.getEmployeeWithSkills(id));
    }
}
