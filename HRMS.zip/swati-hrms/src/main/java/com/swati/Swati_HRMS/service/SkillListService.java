package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.Designation;
import com.swati.Swati_HRMS.model.SkillList;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface SkillListService {

    SkillList saveSkill(SkillList skillList);
    List<SkillList> getAllSkill();
    Optional<SkillList> updateSkillById(Long id, SkillList updatedSkillList);
    Optional<SkillList> changeStatusOfSkillById(Long id);
}
