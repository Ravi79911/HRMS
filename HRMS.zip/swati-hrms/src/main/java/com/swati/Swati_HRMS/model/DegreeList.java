package com.swati.Swati_HRMS.model;


import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Data
@Entity
@Table(name="degrees")
public class DegreeList {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "degree")
	private String degree;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private LocalDateTime createdDate;

	@Column(name = "updated_by")
	private String updatedBy;

	@Column(name = "updated_date")
	private LocalDateTime updatedDate;

	@Column(name = "suspendend_status")
	private int suspendedStatus = 0; //set initial state to 0(active)

	@OneToMany(mappedBy = "degree", cascade = CascadeType.ALL)
	private Set<EmpEducationDetails> empEducationDetails;

}
