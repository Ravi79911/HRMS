package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.dto.EmployeeKeySkillDTO;
import com.swati.Swati_HRMS.model.EmployeeKeySkill;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface EmployeeKeySkillService {

    EmployeeKeySkill saveEmployeeKeySkill(EmployeeKeySkill employeeKeySkill);
    List<EmployeeKeySkillDTO> getEmployeeKeySkillByEmployeePersonalDetailsId(Long id);
}
