package com.swati.Swati_HRMS.dto;

import com.swati.Swati_HRMS.model.SkillList;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class EmployeeKeySkillDTO {
    private Long id;
    private long expMonths;
    private String createdBy;
    private LocalDateTime createdDate;
    private String updatedBy;
    private LocalDateTime updatedDate;
    private int suspendedStatus;
    private SkillList skillList;
}
