package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.AllowanceList;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface AllowanceListService {

    AllowanceList save(AllowanceList allowanceList);
    Optional<AllowanceList> updateAllowanceList(Long id,AllowanceList allowanceList);
    List<AllowanceList> getAllAllowanceList();
    Optional<AllowanceList> deleteAllowanceListById(Long id);
}
