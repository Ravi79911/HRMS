package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.Department;
import com.swati.Swati_HRMS.model.Designation;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface DesignationService {

    Designation saveDesignation(Designation designation);
    List<Designation> getAllDesignations();
    Optional<Designation> updateDesignationById(Long id, Designation updatedDesignation);
    Optional<Designation> changeStatusOfDesignationById(Long id);
}
