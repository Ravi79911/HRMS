package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Date;


@Data
@Entity
@Table(name = "add_documents")
public class EmployeeDocuments {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "file_Name")
	private String docFile;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private LocalDateTime createdDate;

	@Column(name = "suspended_status")
	private int suspendedStatus ; // set initial state to 0 (active)

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "emp_master_id", referencedColumnName = "id", nullable = false)
	private EmployeePersonalDetails employeePersonalDetails;

	@ManyToOne//(fetch = FetchType.LAZY)
	@JoinColumn(name = "doc_id", referencedColumnName = "id")
	private DocumentList documents;

}
