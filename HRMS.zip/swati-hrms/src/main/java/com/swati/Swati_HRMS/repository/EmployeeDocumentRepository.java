package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.EmployeeDocuments;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface EmployeeDocumentRepository extends JpaRepository<EmployeeDocuments, Long> {
    List<EmployeeDocuments> findByEmployeePersonalDetails_Id(Long empId);
}
