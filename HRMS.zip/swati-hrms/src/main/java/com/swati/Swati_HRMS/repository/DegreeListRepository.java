package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.DegreeList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface DegreeListRepository extends JpaRepository<DegreeList, Long> {
    List<DegreeList> findAllBySuspendedStatus(int suspendedStatus);
}
