package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.DocumentList;
import com.swati.Swati_HRMS.repository.DocumentListRepository;
import com.swati.Swati_HRMS.service.DocumentListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class DocumentListServiceImpl implements DocumentListService {

    @Autowired
    private DocumentListRepository documentListRepository;


    @Override
    public DocumentList saveDocument(DocumentList documentList) {
        documentList.setCreatedDate(LocalDateTime.now());
        documentList.setSuspendedStatus(0);
        return documentListRepository.save(documentList);
    }

    @Override
    public Optional<DocumentList> updateDocument(Long id, DocumentList documentList) {
        Optional<DocumentList> documentList1 = documentListRepository.findById(id);
        if (documentList1.isPresent()) {
            documentList1.get().setUpdatedDate(LocalDateTime.now());
            documentList1.get().setUpdatedBy(documentList.getUpdatedBy());
            documentList1.get().setDocName(documentList.getDocName());
            documentListRepository.save(documentList1.get());
        }
        return documentList1;
    }

    @Override
    public Optional<DocumentList> changeStatusOfDocumentById(Long id) {
        Optional<DocumentList> documentList = documentListRepository.findById(id);
        if (documentList.isPresent()) {
            documentList.get().setSuspendedStatus(1);
            documentListRepository.save(documentList.get());
        }
        return documentList;
    }

    @Override
    public List<DocumentList> getAllDocument() {
        return documentListRepository.findBySuspendedStatus(0);
    }
}
