package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.DegreeList;
import com.swati.Swati_HRMS.repository.DegreeListRepository;
import com.swati.Swati_HRMS.service.DegreeListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class DegreeListServiceImpl implements DegreeListService {

    @Autowired
    private DegreeListRepository degreeListRepository;

    @Override
    public DegreeList saveDegree(DegreeList degreeList) {
        degreeList.setCreatedDate(LocalDateTime.now());
        degreeList.setSuspendedStatus(0);
        return degreeListRepository.save(degreeList);
    }

    @Override
    public List<DegreeList> getAllDegree() {
        return degreeListRepository.findAllBySuspendedStatus(0);
    }

    @Override
    public Optional<DegreeList> UpdateDegreeById(Long id,DegreeList updateDegreeList) {
    Optional<DegreeList> degreeList=degreeListRepository.findById(id);
    if(degreeList.isPresent()){
        degreeList.get().setUpdatedDate(LocalDateTime.now());
        degreeList.get().setUpdatedBy(updateDegreeList.getUpdatedBy());
        degreeList.get().setDegree(updateDegreeList.getDegree());
        degreeListRepository.save(degreeList.get());
    }
    return degreeList;
    }

    @Override
    public Optional<DegreeList> changeStatusOfDegreeById(Long id) {
        Optional<DegreeList> degreeList=degreeListRepository.findById(id);
        if(degreeList.isPresent()){
            degreeList.get().setSuspendedStatus(1);
            degreeListRepository.save(degreeList.get());
        }
        return degreeList;
    }
}
