package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.BasicList;
import com.swati.Swati_HRMS.repository.BasicListRepository;
import com.swati.Swati_HRMS.service.BasicListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class BasicListServiceImpl implements BasicListService {

    @Autowired
    private BasicListRepository basicListRepository;

    @Override
    public BasicList saveBasicList(BasicList basicList) {
       basicList.setCreatedDate(LocalDateTime.now());
       basicList.setSuspendedStatus(0);
       return basicListRepository.save(basicList);
    }

    @Override
    public Optional<BasicList> updateBasicList(Long id, BasicList basicList) {
        Optional<BasicList> basicList1 = basicListRepository.findById(id);
        if (basicList1.isPresent()) {
            basicList1.get().setUpdatedDate(LocalDateTime.now());
            basicList1.get().setUpdatedBy(basicList.getUpdatedBy());
            basicList1.get().setScaleName(basicList.getScaleName());
            basicList1.get().setScaleValue(basicList.getScaleValue());
            basicList1.get().setCalculationType(basicList.getCalculationType());
            return Optional.of(basicListRepository.save(basicList1.get()));
        }
        return Optional.empty();
    }

    @Override
    public Optional<BasicList> changeStatusOfBasicListById(Long id) {
       Optional<BasicList> basicList = basicListRepository.findById(id);
       if (basicList.isPresent()) {
           basicList.get().setSuspendedStatus(1);
           basicListRepository.save(basicList.get());
       }else {
           return Optional.empty();
       }
       return basicList;
    }

    @Override
    public List<BasicList> getAllBasicList() {
       return basicListRepository.findBySuspendedStatus(0);
    }
}
