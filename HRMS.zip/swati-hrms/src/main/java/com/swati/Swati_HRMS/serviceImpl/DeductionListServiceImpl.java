package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.DeductionList;
import com.swati.Swati_HRMS.repository.DeductionListRepository;
import com.swati.Swati_HRMS.service.DeductionListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class DeductionListServiceImpl implements DeductionListService {

    @Autowired
    private DeductionListRepository deductionListRepository;

    @Override
    public DeductionList saveDeductionList(DeductionList deductionList) {
        deductionList.setCreatedDate(LocalDateTime.now());
        deductionList.setSuspendedStatus(0);
        return deductionListRepository.save(deductionList);
    }

    @Override
    public Optional<DeductionList> updateDeductionListById(Long id, DeductionList deductionList) {
        Optional<DeductionList> deductionList1 = deductionListRepository.findById(id);
        if (deductionList1.isPresent()) {
            deductionList1.get().setDeductionName(deductionList.getDeductionName());
            deductionList1.get().setDeductionValue(deductionList.getDeductionValue());
            deductionList1.get().setCalculationType(deductionList.getCalculationType());
            deductionList1.get().setUpdatedDate(LocalDateTime.now());
            deductionList1.get().setUpdatedBy(deductionList.getUpdatedBy());
            deductionListRepository.save(deductionList1.get());
            return deductionList1;
        }
        return Optional.empty();
    }

    @Override
    public Optional<DeductionList> deleteDeductionListById(Long id) {
       Optional<DeductionList> deductionList = deductionListRepository.findById(id);
       if(deductionList.isPresent()){
           deductionList.get().setSuspendedStatus(1);
           deductionListRepository.save(deductionList.get());
           return deductionList;
       }
       return Optional.empty();
    }

    @Override
    public List<DeductionList> getAllDeductionList() {
      return deductionListRepository.findAllBySuspendedStatus(0);
    }
}
