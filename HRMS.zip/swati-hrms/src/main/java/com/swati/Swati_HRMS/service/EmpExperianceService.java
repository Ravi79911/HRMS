package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.dto.EmployeeExperienceDetailsDTO;
import com.swati.Swati_HRMS.model.EmployeeExperienceDetails;
import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface EmpExperianceService {

    EmployeeExperienceDetails saveEmployeeExperience(EmployeeExperienceDetails employeeExperienceDetails);
    List<EmployeeExperienceDetailsDTO> getEmployeeKeySkillByEmployeePesronalDetailsId(Long id);
}
