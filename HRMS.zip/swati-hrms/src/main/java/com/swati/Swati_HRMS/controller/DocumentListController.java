package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.model.DocumentList;
import com.swati.Swati_HRMS.service.DocumentListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/documentList")
public class DocumentListController {

    @Autowired
    private DocumentListService documentListService;

    @PostMapping("/save")
    public ResponseEntity<DocumentList> saveDocumentList(@RequestBody DocumentList documentList) {
        return ResponseEntity.ok(documentListService.saveDocument(documentList));
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<DocumentList>> getAllDocumentList() {
        return ResponseEntity.ok(documentListService.getAllDocument());
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<DocumentList> updateDocumentList(@PathVariable Long id, @RequestBody DocumentList updatedDocumentList) {
        Optional<DocumentList> updated = documentListService.updateDocument(id, updatedDocumentList);
        return updated.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PatchMapping("/deleteBy/{id}")
    public ResponseEntity<DocumentList> changeStatusById(Long id){
        Optional<DocumentList>documentList =documentListService.changeStatusOfDocumentById(id);
        return documentList.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
