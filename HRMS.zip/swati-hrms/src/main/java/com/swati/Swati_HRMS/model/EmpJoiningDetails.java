package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;


@Data
@Entity
@Table(name = "emp_joining_details")
public class EmpJoiningDetails {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Long id;

	@Column(name = "joining_date")
	private LocalDate joiningDate;

//	@Column(name = "designation_name")
//	private String designationName;
//
//	@Column(name = "dept_name")
//	private String departmentName;

	@Column(name = "location")
	private String location;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private LocalDateTime createdDate;

	@Column(name = "suspended_status")
	private int suspendedStatus ; // set initial state to 0 (active)

	@ManyToOne
	@JoinColumn(name = "emp_master_id", referencedColumnName = "id", nullable = false)
	private EmployeePersonalDetails employeePersonalDetails;

	@ManyToOne
	@JoinColumn(name = "designation_id", referencedColumnName = "id")
	private Designation designation;

	@ManyToOne
	@JoinColumn(name = "department_id", referencedColumnName = "id")
	private Department department;

}
