package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name="employee_basic")
public class BasicList {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "scale_name")
    private String scaleName;

    @Column(name = "scale_value")
    private Double scaleValue;

    @Column(name = "calculation_type")
    private String calculationType;

    @Column(name = "created_date")
    private LocalDateTime createdDate;
    
    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "update_date")
    private LocalDateTime updatedDate;
    
    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "suspended_status")
	private int suspendedStatus; // set initial state to 0 (active)

}
