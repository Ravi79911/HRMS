package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import com.swati.Swati_HRMS.repository.EmployeePaersonalDetailsRepository;
import com.swati.Swati_HRMS.service.EmployeePersonalDeatilsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;

@Service
public class EmployeePersonalDetailsServiceImpl implements EmployeePersonalDeatilsService {

    @Autowired
    private EmployeePaersonalDetailsRepository employeePersonalDetailsRepository;


    private static final String EMPLOYEE_CODE_PREFIX = "EMP";
    private static final int CODE_LENGTH = 10; // Total length of the employee code
    private static final int RANDOM_PART_LENGTH = CODE_LENGTH - EMPLOYEE_CODE_PREFIX.length(); // Length of the random part

    private static final Random random = new Random();

    private String generateEmployeeCode() {
        // Generate random part with digits only
        String randomPart = generateRandomDigits(RANDOM_PART_LENGTH);

        // Combine prefix and random part
        return EMPLOYEE_CODE_PREFIX + randomPart;
    }

    private String generateRandomDigits(int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            int digit = random.nextInt(10); // Generate a random digit (0-9)
            sb.append(digit);
        }
        return sb.toString();
    }

    @Override
    public EmployeePersonalDetails saveEmployeePersonalDetails(EmployeePersonalDetails employeePersonalDetails) {
        String employeeCode;
        do {
            employeeCode = generateEmployeeCode();
        } while (employeePersonalDetailsRepository.findByEmployeeCode(employeeCode).isPresent());

        employeePersonalDetails.setEmployeeCode(employeeCode);
        employeePersonalDetails.setCreatedDate(LocalDateTime.now());
        employeePersonalDetails.setSuspendedStatus(0);

        return employeePersonalDetailsRepository.save(employeePersonalDetails);
    }

    @Override
    public Optional<EmployeePersonalDetails> updateEmployeePersonalDetails(Long id, EmployeePersonalDetails employeePersonalDetails) {
        return employeePersonalDetailsRepository.findById(id).map(existingEmployee -> {

            // Update fields only if they are provided (non-null) in the input
            if (employeePersonalDetails.getEmployeeFirstName() != null) {
                existingEmployee.setEmployeeFirstName(employeePersonalDetails.getEmployeeFirstName());
            }
            if (employeePersonalDetails.getEmployeeLastName() != null) {
                existingEmployee.setEmployeeLastName(employeePersonalDetails.getEmployeeLastName());
            }
            if (employeePersonalDetails.getEmployeeFatherName() != null) {
                existingEmployee.setEmployeeFatherName(employeePersonalDetails.getEmployeeFatherName());
            }
            if (employeePersonalDetails.getEmployeeMotherName() != null) {
                existingEmployee.setEmployeeMotherName(employeePersonalDetails.getEmployeeMotherName());
            }
            if (employeePersonalDetails.getDOB() != null) {
                existingEmployee.setDOB(employeePersonalDetails.getDOB());
            }
            if (employeePersonalDetails.getGender() != null) {
                existingEmployee.setGender(employeePersonalDetails.getGender());
            }
            if (employeePersonalDetails.getMobileNo() != null) {
                existingEmployee.setMobileNo(employeePersonalDetails.getMobileNo());
            }
            if (employeePersonalDetails.getEmail() != null) {
                existingEmployee.setEmail(employeePersonalDetails.getEmail());
            }
            if (employeePersonalDetails.getGuardianMobNo() != null) {
                existingEmployee.setGuardianMobNo(employeePersonalDetails.getGuardianMobNo());
            }
            if (employeePersonalDetails.getAadhaarNo() != null) {
                existingEmployee.setAadhaarNo(employeePersonalDetails.getAadhaarNo());
            }
            if (employeePersonalDetails.getPanNo() != null) {
                existingEmployee.setPanNo(employeePersonalDetails.getPanNo());
            }
            if (employeePersonalDetails.getLocalAddress() != null) {
                existingEmployee.setLocalAddress(employeePersonalDetails.getLocalAddress());
            }
            if (employeePersonalDetails.getLocalPinCode() != null) {
                existingEmployee.setLocalPinCode(employeePersonalDetails.getLocalPinCode());
            }
            if (employeePersonalDetails.getLocalCity() != null) {
                existingEmployee.setLocalCity(employeePersonalDetails.getLocalCity());
            }
            if (employeePersonalDetails.getLocalState() != null) {
                existingEmployee.setLocalState(employeePersonalDetails.getLocalState());
            }
            if (employeePersonalDetails.getLocalCountry() != null) {
                existingEmployee.setLocalCountry(employeePersonalDetails.getLocalCountry());
            }
            if (employeePersonalDetails.getPermanentAddress() != null) {
                existingEmployee.setPermanentAddress(employeePersonalDetails.getPermanentAddress());
            }
            if (employeePersonalDetails.getPermanentPinCode() != null) {
                existingEmployee.setPermanentPinCode(employeePersonalDetails.getPermanentPinCode());
            }
            if (employeePersonalDetails.getPermanentCity() != null) {
                existingEmployee.setPermanentCity(employeePersonalDetails.getPermanentCity());
            }
            if (employeePersonalDetails.getPermanentState() != null) {
                existingEmployee.setPermanentState(employeePersonalDetails.getPermanentState());
            }
            if (employeePersonalDetails.getPermanentCountry() != null) {
                existingEmployee.setPermanentCountry(employeePersonalDetails.getPermanentCountry());
            }

            // Set updated date and save the changes
            existingEmployee.setUpdatedDate(LocalDateTime.now());
            existingEmployee.setUpdatedBy(employeePersonalDetails.getUpdatedBy());


            employeePersonalDetailsRepository.save(existingEmployee);
            return existingEmployee;
        });
    }

    @Override
    public Optional<EmployeePersonalDetails> changeStatusOfDocumentById(Long id) {
        Optional<EmployeePersonalDetails> employeePersonalDetails = employeePersonalDetailsRepository.findById(id);
        if (employeePersonalDetails.isPresent()) {
            EmployeePersonalDetails employeePersonalDetails1 = employeePersonalDetails.get();
            employeePersonalDetails1.setSuspendedStatus(1);
            employeePersonalDetailsRepository.save(employeePersonalDetails1);
            return employeePersonalDetails;
        }
        return Optional.empty();
    }

    @Override
    public List<EmployeePersonalDetails> getAllDocument() {
        return employeePersonalDetailsRepository.findBySuspendedStatus(0);
    }

    @Override
    public Optional<EmployeePersonalDetails> getEmployeeWithSkills(Long id) {
        return employeePersonalDetailsRepository.findById(id);
    }
}
