package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.BasicList;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface BasicListService {
    BasicList saveBasicList(BasicList basicList);
    Optional<BasicList> updateBasicList(Long id,BasicList basicList);
    Optional<BasicList> changeStatusOfBasicListById(Long id);
    List<BasicList> getAllBasicList();
}
