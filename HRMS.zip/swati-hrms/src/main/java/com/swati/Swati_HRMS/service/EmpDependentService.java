package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.dto.EmployeeDependentDTO;
import com.swati.Swati_HRMS.model.EmpEducationDetails;
import com.swati.Swati_HRMS.model.EmployeeDependent;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface EmpDependentService {

    EmployeeDependent saveEmployeeDependent(EmployeeDependent employeeDependent);
    List<EmployeeDependentDTO> getEmployeeKeySkillByEmployeePesronalDetailsId(Long id);
}
