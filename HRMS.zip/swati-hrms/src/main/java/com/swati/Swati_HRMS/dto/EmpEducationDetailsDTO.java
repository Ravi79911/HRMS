package com.swati.Swati_HRMS.dto;

import com.swati.Swati_HRMS.model.DegreeList;
import com.swati.Swati_HRMS.model.StreamList;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class EmpEducationDetailsDTO {

    private Long id;
    private String universityBoard;
    private String passingYear;
    private String cgpaPercentage;
    private String createdBy;
    private LocalDateTime createdDate;
    private String updatedBy;
    private LocalDateTime updatedDate;
    private int suspendedStatus;
    private DegreeList degree;
    private StreamList streamCourse;
}
