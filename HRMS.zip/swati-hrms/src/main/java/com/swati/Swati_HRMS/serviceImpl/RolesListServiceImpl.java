package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.RolesList;
import com.swati.Swati_HRMS.repository.RolesListRepository;
import com.swati.Swati_HRMS.service.RolesListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class RolesListServiceImpl implements RolesListService {

    @Autowired
    private RolesListRepository rolesListRepository;

    @Override
    public List<RolesList> getAllRolesList() {
        return rolesListRepository.findBySuspendedStatus(0);
    }

    @Override
    public RolesList saveRolesList(RolesList rolesList) {
        rolesList.setCreatedDate(LocalDateTime.now());
        rolesList.setSuspendedStatus(0);
        return rolesListRepository.save(rolesList);
    }

    @Override
    public Optional<RolesList> updateRolesListById(Long id, RolesList updatedRolesList) {
        Optional<RolesList> rolesList = rolesListRepository.findById(id);
        if(rolesList.isPresent()){
            rolesList.get().setRoleName(updatedRolesList.getRoleName());
            rolesList.get().setUpdatedBy(updatedRolesList.getUpdatedBy());
            rolesList.get().setUpdatedDate(LocalDateTime.now());
            rolesListRepository.save(rolesList.get());
        }
        return rolesList;
    }

    @Override
    public Optional<RolesList> changeStatusOfRolesListById(Long id) {
        Optional<RolesList> rolesList = rolesListRepository.findById(id);
        if(rolesList.isPresent()){
            rolesList.get().setSuspendedStatus(1);
            rolesListRepository.save(rolesList.get());
        }
        return rolesList;
    }
}
