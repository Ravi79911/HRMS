package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.dto.EmployeeDocumentsDTO;
import com.swati.Swati_HRMS.model.EmployeeDocuments;
import com.swati.Swati_HRMS.repository.EmployeeDocumentRepository;
import com.swati.Swati_HRMS.service.EmployeeDocumentsService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class EmpDocumentServiceImpl implements EmployeeDocumentsService {

    @Autowired
    private EmployeeDocumentRepository employeeDocumentRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Value("${upload.base.dir}")
    private String uploadDir;


    @Override
    public EmployeeDocuments saveEmployeeDocuments(EmployeeDocuments employeeDocuments, MultipartFile photoFile) {
        try {
            // Set metadata for the document
            employeeDocuments.setCreatedDate(LocalDateTime.now());
            employeeDocuments.setSuspendedStatus(0);

            // Handle file upload
            if (photoFile != null && !photoFile.isEmpty()) {
                // Generate a unique file name to avoid overwrites
                String fileName = UUID.randomUUID().toString() + "_" + photoFile.getOriginalFilename();
                Path uploadPath = Paths.get(uploadDir).toAbsolutePath().normalize();

                // Create directories if they do not exist
                Files.createDirectories(uploadPath);

                // Define the full path for the uploaded file
                Path filePath = uploadPath.resolve(fileName);

                // Save the file to the defined location
                Files.write(filePath, photoFile.getBytes());

                // Set the file path in the employeeDocuments object
                employeeDocuments.setDocFile(filePath.toString());
            }

            // Save the document entity to the repository
            return employeeDocumentRepository.save(employeeDocuments);

        } catch (IOException e) {
            // Log and rethrow the exception (or handle it based on your use case)
            throw new RuntimeException("Error occurred while saving the document or uploading the file", e);
        }
    }

    @Override
    public List<EmployeeDocumentsDTO> getEmployeeKeySkillByEmployeePesronalDetailsId(Long id) {
        List<EmployeeDocuments> employeeDocuments = employeeDocumentRepository.findByEmployeePersonalDetails_Id(id);
        return employeeDocuments.stream()
                .map(skill -> modelMapper.map(skill, EmployeeDocumentsDTO.class))
                .collect(Collectors.toList());
    }

}
