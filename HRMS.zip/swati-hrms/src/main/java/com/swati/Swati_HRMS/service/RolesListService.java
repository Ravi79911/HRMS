package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.RolesList;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface RolesListService {

    List<RolesList> getAllRolesList();
    RolesList saveRolesList(RolesList rolesList);
    Optional<RolesList> updateRolesListById(Long id, RolesList updatedRolesList);
    Optional<RolesList> changeStatusOfRolesListById(Long id);
}
