package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.dto.EmployeeDocumentsDTO;
import com.swati.Swati_HRMS.model.EmployeeDocuments;
import com.swati.Swati_HRMS.service.EmployeeDocumentsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/empDocuments")
public class EmpDocumentsController {

    @Autowired
    private EmployeeDocumentsService employeeDocumentsService;

    @PostMapping("/empDocumetUpload")
    public ResponseEntity<EmployeeDocuments> createSituator(@ModelAttribute EmployeeDocuments employeeDocuments,
                                                            @RequestParam("photo") MultipartFile photoFile) {

        try {
            EmployeeDocuments savedEmpDocuments = employeeDocumentsService.saveEmployeeDocuments(employeeDocuments, photoFile);
            return new ResponseEntity<>(savedEmpDocuments, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getDocuments/ByEmpPersonalDetailsId/{id}")
    public ResponseEntity<List<EmployeeDocumentsDTO>> getDocuments(@PathVariable("id") Long id) {
        List<EmployeeDocumentsDTO> documents = employeeDocumentsService.getEmployeeKeySkillByEmployeePesronalDetailsId(id);
        return ResponseEntity.ok(documents);
    }
}
