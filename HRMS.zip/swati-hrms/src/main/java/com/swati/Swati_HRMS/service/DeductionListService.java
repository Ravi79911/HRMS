package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.DeductionList;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface DeductionListService {

    DeductionList saveDeductionList(DeductionList deductionList);
    Optional<DeductionList> updateDeductionListById(Long id,DeductionList deductionList);
    Optional<DeductionList> deleteDeductionListById(Long id);
    List<DeductionList> getAllDeductionList();
}
