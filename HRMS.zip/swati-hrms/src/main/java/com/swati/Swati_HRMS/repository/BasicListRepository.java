package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.BasicList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface BasicListRepository extends JpaRepository<BasicList,Long> {
    List<BasicList> findBySuspendedStatus(int suspendedStatus);
}
