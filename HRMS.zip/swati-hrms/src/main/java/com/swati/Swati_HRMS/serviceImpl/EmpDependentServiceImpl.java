package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.dto.EmployeeDependentDTO;
import com.swati.Swati_HRMS.model.EmployeeDependent;
import com.swati.Swati_HRMS.repository.EmployeeDependentRepository;
import com.swati.Swati_HRMS.service.EmpDependentService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmpDependentServiceImpl implements EmpDependentService {

    @Autowired
    private EmployeeDependentRepository employeeDependentRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public EmployeeDependent saveEmployeeDependent(EmployeeDependent employeeDependent) {
        employeeDependent.setCreatedDate(LocalDateTime.now());
        employeeDependent.setSuspendedStatus(0);
        return employeeDependentRepository.save(employeeDependent);
    }

    @Override
    public List<EmployeeDependentDTO> getEmployeeKeySkillByEmployeePesronalDetailsId(Long id) {
        List<EmployeeDependent> employeeDependents = employeeDependentRepository.findByEmployeePersonalDetails_Id(id);
        return employeeDependents.stream()
                .map(skill -> modelMapper.map(skill, EmployeeDependentDTO.class))
                .collect(Collectors.toList());
    }
}
