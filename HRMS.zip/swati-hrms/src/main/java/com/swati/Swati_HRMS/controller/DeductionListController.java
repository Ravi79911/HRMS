package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.model.DeductionList;
import com.swati.Swati_HRMS.service.DeductionListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/deductionList")
public class DeductionListController {

    @Autowired
    private DeductionListService deductionListService;

    @PostMapping("/save")
    public ResponseEntity<DeductionList> saveDeductionList(@RequestBody DeductionList deductionList) {
        return ResponseEntity.ok(deductionListService.saveDeductionList(deductionList));
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<DeductionList>> getAllDeductionList() {
        return ResponseEntity.ok(deductionListService.getAllDeductionList());
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<DeductionList> updateDeductionList(@PathVariable("id") Long id, @RequestBody DeductionList deductionList) {
        Optional<DeductionList> updated = deductionListService.updateDeductionListById(id, deductionList);
        return updated.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PatchMapping("/deleteBy/{id}")
    public ResponseEntity<DeductionList> deleteDeductionList(@PathVariable("id") Long id) {
        Optional<DeductionList> deleted = deductionListService.deleteDeductionListById(id);
        return deleted.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
