package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.model.RolesList;
import com.swati.Swati_HRMS.service.RolesListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/roleslist")
public class RolesListController {

    @Autowired
    private RolesListService rolesListService;

    @PostMapping("/save")
    public ResponseEntity<RolesList> saveRolesList(@RequestBody RolesList rolesList){
        return ResponseEntity.ok(rolesListService.saveRolesList(rolesList));
    }

    @GetMapping("/getall")
    public ResponseEntity<List<RolesList>> getAllRolesList(){
        return ResponseEntity.ok(rolesListService.getAllRolesList());
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<RolesList> updateRolesListById(@PathVariable("id") Long id, @RequestBody RolesList updatedRolesList){
        return ResponseEntity.ok(rolesListService.updateRolesListById(id, updatedRolesList).get());

    }

    @PatchMapping("/delete/{id}")
    public ResponseEntity<RolesList> changeStatusOfRolesListById(@PathVariable("id") Long id){
        return ResponseEntity.ok(rolesListService.changeStatusOfRolesListById(id).get());

    }
}
