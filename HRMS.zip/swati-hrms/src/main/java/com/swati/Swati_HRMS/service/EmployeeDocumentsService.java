package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.dto.EmployeeDocumentsDTO;
import com.swati.Swati_HRMS.dto.EmployeeExperienceDetailsDTO;
import com.swati.Swati_HRMS.model.EmployeeDocuments;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public interface EmployeeDocumentsService {

    EmployeeDocuments saveEmployeeDocuments(EmployeeDocuments employeeDocuments, MultipartFile photoFile);
    List<EmployeeDocumentsDTO> getEmployeeKeySkillByEmployeePesronalDetailsId(Long id);
}
