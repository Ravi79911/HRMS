# Swati Industries - HRMS

Dev Server IP Address
http://192.168.29.245:8087/hrms

Dev Server Domain Name
http://swatiind.co.in:8087/hrms
