package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.model.BasicList;
import com.swati.Swati_HRMS.service.BasicListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/basicsList")
public class BasicListController {

    @Autowired
    private BasicListService basicListService;

    @PostMapping("/save")
    public ResponseEntity<BasicList> saveBasicList(@RequestBody BasicList basicList){
        BasicList basicList1=basicListService.saveBasicList(basicList);
        return new ResponseEntity<>(basicList1, HttpStatus.CREATED);
    }

    @GetMapping("/getall")
    public ResponseEntity<List<BasicList>> getAllBasicList(){
       List<BasicList> basicLists=basicListService.getAllBasicList();
       return new ResponseEntity<>(basicLists,HttpStatus.OK);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<BasicList> updateBasicList(@PathVariable Long id, @RequestBody BasicList updatedBasicList){
        Optional<BasicList> updated=basicListService.updateBasicList(id, updatedBasicList);
        return updated.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PatchMapping("/deleteBy/{id}")
    public ResponseEntity<BasicList> suspendBasicList(@PathVariable Long id){
        Optional<BasicList> updated=basicListService.changeStatusOfBasicListById(id);
        return updated.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
