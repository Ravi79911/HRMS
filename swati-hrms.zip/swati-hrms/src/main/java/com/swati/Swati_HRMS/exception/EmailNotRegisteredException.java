package com.swati.Swati_HRMS.exception;

import lombok.Data;

@Data
public class EmailNotRegisteredException extends RuntimeException {

    public EmailNotRegisteredException(String message) {
        super(message);
    }

    public EmailNotRegisteredException(String message, Throwable cause) {
        super(message, cause);
    }

}
