package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/notification")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @GetMapping("/sendBirthdayNotification")
    public ResponseEntity<String> sendBirthdayNotifications() {
        try {
            List<String> birthdayMessages = notificationService.sendBirthdayNotifications();

            if (birthdayMessages.isEmpty()) {
                return new ResponseEntity<>("No birthday notifications to send.", HttpStatus.OK);
            }

            StringBuilder responseMessage = new StringBuilder("Birthday notifications sent successfully!\n");
            for (String message : birthdayMessages) {
                responseMessage.append(message).append("\n");
            }

            return new ResponseEntity<>(responseMessage.toString(), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to send birthday notifications: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
