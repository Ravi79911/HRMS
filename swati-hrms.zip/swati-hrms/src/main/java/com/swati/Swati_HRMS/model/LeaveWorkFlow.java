package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "leave_work_flow")
public class LeaveWorkFlow {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "remarks", length = 1000)
    private String remarks;

    @Column(name = "leave_status", length = 100)
    private String leaveStatus;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Long suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "current_user_id", referencedColumnName = "id")
    private Employee currentUserId;

    @ManyToOne
    @JoinColumn(name = "next_user_id", referencedColumnName = "id")
    private Employee nextUserId;

    @ManyToOne
    @JoinColumn(name = "leave_application_id", referencedColumnName = "id")
    private LeaveApplication applicationId;

}