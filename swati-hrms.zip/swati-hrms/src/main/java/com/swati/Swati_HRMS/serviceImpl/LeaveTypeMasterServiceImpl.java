package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.LeaveTypeMaster;
import com.swati.Swati_HRMS.repository.LeaveTypeMasterRepository;
import com.swati.Swati_HRMS.service.LeaveTypeMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class LeaveTypeMasterServiceImpl implements LeaveTypeMasterService {

    @Autowired
    private LeaveTypeMasterRepository leaveTypeMasterRepository;

    @Override
    public LeaveTypeMaster createLeaveTypemaster(LeaveTypeMaster leaveTypeMaster) {
        leaveTypeMaster.setCreatedDate(LocalDateTime.now());
        leaveTypeMaster.setSuspendedStatus(0L);
        return leaveTypeMasterRepository.save(leaveTypeMaster);
    }

    @Override
    public Optional<LeaveTypeMaster> getLeaveTypemasterById(Long id) {
        Optional<LeaveTypeMaster> leaveTypeMaster = leaveTypeMasterRepository.findById(id);
        if (leaveTypeMaster.isPresent()) {
            return leaveTypeMaster;
        }
        throw new RuntimeException("LeaveTypeMaster not found : " + id);
    }

    @Override
    public Optional<LeaveTypeMaster> updateLeaveTypemaster(Long id, LeaveTypeMaster leaveTypeMaster) {
        Optional<LeaveTypeMaster> existleaveTypeMaster = leaveTypeMasterRepository.findById(id);
        if (existleaveTypeMaster.isPresent()) {
            leaveTypeMaster.setId(existleaveTypeMaster.get().getId());
            leaveTypeMaster.setCreatedBy(existleaveTypeMaster.get().getCreatedBy());
            leaveTypeMaster.setCreatedDate(existleaveTypeMaster.get().getCreatedDate());
            leaveTypeMaster.setSuspendedStatus(existleaveTypeMaster.get().getSuspendedStatus());
            return Optional.of(leaveTypeMasterRepository.saveAndFlush(leaveTypeMaster));

        }else {
            throw new RuntimeException("LeaveTypeMaster not found : " + id);
        }
    }

    @Override
    public Optional<LeaveTypeMaster> changeStatusOfLeaveTypemasterById(Long id) {
        Optional<LeaveTypeMaster> existleaveTypeMaster = leaveTypeMasterRepository.findById(id);
        if (existleaveTypeMaster.isPresent()) {
            existleaveTypeMaster.get().setSuspendedStatus(1L);
            return Optional.of(leaveTypeMasterRepository.saveAndFlush(existleaveTypeMaster.get()));
        }else {
            throw new RuntimeException("LeaveTypeMaster not found : " + id);
        }
    }

    @Override
    public List<LeaveTypeMaster> getAllLeaveTypemaster() {
        return leaveTypeMasterRepository.findAll();
    }

    @Override
    public String deleteLeaveTypemasterById(Long id) {
        Optional<LeaveTypeMaster> existleaveTypeMaster = leaveTypeMasterRepository.findById(id);
        if (existleaveTypeMaster.isPresent()) {
            leaveTypeMasterRepository.deleteById(existleaveTypeMaster.get().getId());
        } else {
            throw new RuntimeException("LeaveTypeMaster not found : " + id);
        }
        return "LeaveTypeMaster deleted successfully";
    }
}
