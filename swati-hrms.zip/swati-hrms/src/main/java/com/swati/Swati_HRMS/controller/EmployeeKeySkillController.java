package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.dto.EmployeeKeySkillDTO;
import com.swati.Swati_HRMS.model.EmployeeKeySkill;
import com.swati.Swati_HRMS.service.EmployeeKeySkillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/employeeKeySkill")
public class EmployeeKeySkillController {

    @Autowired
    private EmployeeKeySkillService employeeKeySkillService;

    @PostMapping("/saveEmployeeKeySkill")
    public ResponseEntity<EmployeeKeySkill> saveEmployeeKeySkill(@RequestBody EmployeeKeySkill employeeKeySkill){
        return ResponseEntity.ok(employeeKeySkillService.saveEmployeeKeySkill(employeeKeySkill));
    }

    @GetMapping("/getByEmployeePersonalDetailsId")
    public ResponseEntity<List<EmployeeKeySkillDTO>> getByEmployeePersonalDetailsId(@RequestParam Long id) {
        List<EmployeeKeySkillDTO> employeeKeySkills = employeeKeySkillService.getEmployeeKeySkillByEmployeePersonalDetailsId(id);
        return ResponseEntity.ok(employeeKeySkills);
    }
}
