package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.dto.EmployeeDTO;
import com.swati.Swati_HRMS.exception.*;
import com.swati.Swati_HRMS.model.*;
import com.swati.Swati_HRMS.repository.EmployeePersonalDetailsRepository;
import com.swati.Swati_HRMS.repository.RoleRepository;
import com.swati.Swati_HRMS.service.EmployeeService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/auth")
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
    EmployeePersonalDetailsRepository employeePersonalDetailsRepository;

    @PostMapping("/createEmployee")
    public ResponseEntity<ApiResponse> createUserMaster(@Valid @RequestParam(value = "userPicture", required = false) MultipartFile userPicture,
                                                        @RequestParam("role") Long roleId,
                                                        @RequestParam("employeeId") String employeeId,
                                                        @RequestParam("employeeName") String employeeName,
                                                        @RequestParam("fatherName") String fatherName,
                                                        @RequestParam("department") String department,
                                                        @RequestParam("address") String address,
                                                        @RequestParam("email") String email,
                                                        @RequestParam("mobileNo") String mobileNo,
                                                        @RequestParam("dateOfBirth") LocalDate dateOfBirth,
                                                        @RequestParam("userName") String userName,
                                                        @RequestParam("empPerId") Long employeePersonalDetailsId, // Changed to accept ID instead of object
                                                        @RequestParam("createdBy") Integer createdBy) {

        // Get the role from repository
        Role role = roleRepository.findById(roleId)
                .orElseThrow(() -> new ResourceNotFoundException("Role not found with id: " + roleId));

        // Get the employee personal details from repository
        EmployeePersonalDetails personalDetails = null;
        if (employeePersonalDetailsId != null) {
            personalDetails = employeePersonalDetailsRepository.findById(employeePersonalDetailsId)
                    .orElseThrow(() -> new ResourceNotFoundException("Employee Personal Details not found with id: " + employeePersonalDetailsId));
        }

        Employee employee = new Employee();
        employee.setRole(new ArrayList<>(List.of(role)));
        employee.setEmployeeId(employeeId);
        employee.setEmployeeName(employeeName);
        employee.setFatherName(fatherName);
        employee.setDepartment(department);
        employee.setAddress(address);
        employee.setEmail(email);
        employee.setMobileNo(mobileNo);
        employee.setDateOfBirth(dateOfBirth);
        employee.setUserName(userName);
        employee.setCreatedBy(createdBy);
        employee.setEmployeePersonalDetails(personalDetails);

        Employee createdEmployee = employeeService.createUserMaster(employee, userPicture);
        ApiResponse response = new ApiResponse("Employee created successfully", true, createdEmployee);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @PostMapping("/validateEmailOtp")
    public ResponseEntity<ApiResponse> validateEmailOtp(@RequestParam("employeeId") Long userId, @RequestParam("otp") String otp) {
        Employee employee = employeeService.findByUserId(userId);

        if (employee == null) {
            throw new ResourceNotFoundException("Employee", "employeeId", userId);
        }

        boolean isOtpValid = employeeService.validateEmailOtp(employee, otp);
        if (!isOtpValid) {
            throw new InvalidOTPException("Invalid or expired email OTP");
        }

        ApiResponse response = ApiResponse.success("Email OTP validated successfully", null);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/validateForgotUserNameOtp")
    public ResponseEntity<ApiResponse> validateForgotUserNameOtp(@RequestParam Long employeeId,
                                                                 @RequestParam String emailOtp) {
        try {
            Employee employee = employeeService.findByUserId(employeeId);
            String response = employeeService.validateForgotUsernameOtp(employee, emailOtp);
            return ResponseEntity.ok(ApiResponse.success(response, null));
        } catch (InvalidOTPException | OTPExpiredException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.failure(e.getMessage(), "INVALID_OTP"));
        } catch (Exception e) {
            log.error("Error occurred while validating OTP for employee ID: {}", employeeId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.failure("An unexpected error occurred. Please try again later.", "INTERNAL_SERVER_ERROR"));
        }
    }

    @PostMapping("/resendEmailOtp")
    public ResponseEntity<ApiResponse> resendEmailOtp(@RequestParam("employeeId") Long userId) {
        Employee employee = employeeService.findByUserId(userId);

        if (employee != null) {
            try {
                employeeService.resendEmailOtp(employee);
                return ResponseEntity.ok(new ApiResponse("Email OTP has been resent successfully.", true));
            } catch (OTPResendException ex) {
                return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.BAD_REQUEST);
            }
        } else {
            return new ResponseEntity<>(new ApiResponse("Employee not found.", false), HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/sendOtpForEmailLogin")
    public ResponseEntity<String> sendOtpForEmailLogin(@RequestParam String email) {
        try {
            String result = employeeService.sendOtpForEmailLogin(email);
            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (EmailNotRegisteredException ex) {
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (OTPGenerationException ex) {
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception ex) {
            return new ResponseEntity<>("An unexpected error occurred.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/requestForgotUserName")
    public ResponseEntity<ApiResponse> forgotUserName(@RequestBody ForgotUserNameRequest forgotUserNameRequest) {
        try {
            String response = employeeService.forgotUsername(forgotUserNameRequest);
            return ResponseEntity.ok(ApiResponse.success(response, null));
        } catch (EmailNotFoundException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.failure(e.getMessage(), "EMAIL_NOT_FOUND"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.failure("An unexpected error occurred. Please try again later.", "INTERNAL_SERVER_ERROR"));
        }
    }

    @PutMapping("/changePassword/{employeeId}")
    public ResponseEntity<String> changePasswords(@PathVariable Long employeeId, @RequestBody ChangePasswordRequest changePasswordRequest) {
        String message = employeeService.changePassword(employeeId, changePasswordRequest);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }

    @PostMapping("/forgotPassword")
    public ResponseEntity<String> forgotPasswords(@RequestParam String email) {
        String message = employeeService.forgotPassword(email);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }

    @PutMapping("/resetPassword")
    public ResponseEntity<String> resetPasswords(@RequestParam String token, @RequestBody ForgotPassword forgotPassword) {
        String message = employeeService.resetPassword(token, forgotPassword);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }

    @GetMapping("/getProfile")
    public ResponseEntity<ApiResponse> getEmployeeProfile(@RequestHeader("Authorization") String jwt) {
        try {
            if (jwt == null || !jwt.startsWith("Bearer ")) {
                throw new IllegalArgumentException("Invalid JWT token format");
            }

            String token = jwt.substring(7);

            Employee employee = employeeService.findEmployeeProfileByJwt(token);
            return ResponseEntity.ok(ApiResponse.success("Employee profile fetched successfully", employee));

        } catch (IllegalArgumentException ex) {
            log.error("Invalid JWT token format: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.BAD_REQUEST);
        } catch (InvalidTokenException ex) {
            log.error("Invalid JWT token: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.UNAUTHORIZED);
        } catch (EmployeeNotFoundException ex) {
            log.error("Employee not found: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            log.error("An error occurred while fetching the employee profile", ex);
            return new ResponseEntity<>(new ApiResponse("An error occurred while fetching the employee profile", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/updateFcmToken/{id}")
    public ResponseEntity<ApiResponse> updateFcmToken(@PathVariable("id") Long employeeId, @RequestBody RequestFcmToken requestFcmToken) {
        try {
            Employee updatedEmployee = employeeService.updateFcmToken(employeeId, requestFcmToken);
            return ResponseEntity.ok(ApiResponse.success("FCM token updated successfully!", updatedEmployee));
        } catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.failure("Employee not found with id: " + employeeId, "EMPLOYEE_NOT_FOUND"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.failure("Error updating FCM token: " + e.getMessage(), "INTERNAL_SERVER_ERROR"));
        }
    }

    @GetMapping("/getAllEmployees")
    public ResponseEntity<ApiResponse> getAllEmployees() {
        try {
            List<EmployeeDTO> employeeDTOs = employeeService.getAllEmployee();
            return ResponseEntity.ok(ApiResponse.success("Employees fetched successfully", employeeDTOs));
        } catch (ResourceNotFoundException ex) {
            log.error("No employees found: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (RuntimeException ex) {
            log.error("Error occurred while fetching employees: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse("An error occurred while fetching the employee details", false), HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception ex) {
            log.error("Unexpected error occurred: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse("Unexpected error occurred", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getById")
    public ResponseEntity<ApiResponse> getById(@RequestParam Long id) {
        try {
            Employee employee = employeeService.findByUserId(id);
            ApiResponse response = ApiResponse.success("Employee fetched successfully", employee);
            return ResponseEntity.ok(response);
        } catch (ResourceNotFoundException ex) {
            ApiResponse response = ApiResponse.failure(ex.getMessage(), "EMPLOYEE_NOT_FOUND");
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/checkEmailIdExists")
    public ResponseEntity<Boolean> checkEmailIdExists(@RequestParam String email) {
        boolean emailExist = employeeService.isEmailExists(email);
        return ResponseEntity.ok(emailExist);
    }

    @GetMapping("/checkMobileNumberExists")
    public ResponseEntity<Boolean> checkMobileNumberExists(@RequestParam String mobileNo) {
        boolean mobileNumberExist = employeeService.isMobileNumberExists(mobileNo);
        return ResponseEntity.ok(mobileNumberExist);
    }

    @GetMapping("/checkUserNameExists")
    public ResponseEntity<Boolean> checkUserNameExists(@RequestParam String userName) {
        boolean userNameExist = employeeService.isUserNameExists(userName);
        return ResponseEntity.ok(userNameExist);
    }

}
