package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.model.HolidayMaster;
import com.swati.Swati_HRMS.repository.HolidayMasterRepository;
import com.swati.Swati_HRMS.service.HolidayMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/holidayMaster")
public class HolidayMasterController {

    @Autowired
    private HolidayMasterService holidayMasterService;

    @PostMapping("/saveHolidayMaster")
    public ResponseEntity<HolidayMaster> createHolidayMaster(@RequestBody HolidayMaster holidayMaster){
        HolidayMaster holidayMaster1 = holidayMasterService.createHolidayMaster(holidayMaster);
        ApiResponse apiResponse = ApiResponse.success("Holiday Master saved successfully", holidayMaster1);
        return ResponseEntity.ok(holidayMaster1);
    }

    @GetMapping("/getAllHolidayMaster")
    public ResponseEntity<ApiResponse> getAllHolidayMaster(){
        ApiResponse response = ApiResponse.success("Holiday Master fetched successfully", holidayMasterService.getAllHolidayMaster());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getHolidayMasterById/{id}")
    public ResponseEntity<ApiResponse> getHolidayMasterById(@PathVariable Long id){
        ApiResponse response = ApiResponse.success("Holiday Master fetched successfully", holidayMasterService.getHolidayMasterById(id));
        return ResponseEntity.ok(response);
    }

    @PutMapping("/updateHolidayMaster/{id}")
    public ResponseEntity<ApiResponse> updateHolidayMaster(@PathVariable Long id, @RequestBody HolidayMaster holidayMaster){
        ApiResponse response = ApiResponse.success("Holiday Master updated successfully", holidayMasterService.updateHolidayMaster(id, holidayMaster));
        return ResponseEntity.ok(response);
    }

    @PatchMapping("/changeStatusOfHolidayMasterById/{id}")
    public ResponseEntity<ApiResponse> changeStatusOfHolidayMasterById(@PathVariable Long id){
        ApiResponse response = ApiResponse.success("Holiday Master status changed successfully", holidayMasterService.changeStatusOfHolidayMasterById(id));
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/deleteHolidayMasterById/{id}")
    public ResponseEntity<ApiResponse> deleteHolidayMasterById(@PathVariable Long id){
        ApiResponse response = ApiResponse.success("Holiday Master deleted successfully", holidayMasterService.deleteHolidayMasterById(id));
        return ResponseEntity.ok(response);
    }
}
