package com.swati.Swati_HRMS.security;

import com.swati.Swati_HRMS.jwt.JWTAuthenticationFilter;
import com.swati.Swati_HRMS.jwt.JwtAuthenticationEntryPoint;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.core.GrantedAuthorityDefaults;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@AllArgsConstructor
@Configuration
public class SecurityFilterConfig {

    @Autowired
    JwtAuthenticationEntryPoint point;

    @Autowired
    JWTAuthenticationFilter filter;

    @Autowired
    UserDetailsService userDetailsService;

    @Autowired
    PasswordEncoder passwordEncoder;

    public static final String[] PUBLIC_URLS = {
//            "/auth/authenticate",
            "/auth/**",
            "/roleMaster/**",
            "/notification/**",
            "/swagger-ui/**",
            "/v3/api-docs/**",
            "/swagger-resources/**",
            "/webjars/**",
            "/empSignupProfilePic/**",
            "/employeeDocuments/**"
    };

    public static final String[] ADMIN_URLS = {
            "/allowance/**",
            "/basicsList/**",
            "/deductionList/**",
            "/degreeList/**",
            "/department/**",
            "/designation/**",
            "/documentList/**",
            "/empDependent/**",
            "/empDocuments/**",
            "/empEductionDetails/**",
            "/experiance/**",
            "/empJoining/**",
            "/employeeKeySkill/**",
            "/employeePersonalDetails/**",
            "/roleMaster/**",
            "/skillList/**",
            "/stream/**",
            "/roleMaster/**",
            "/auth/**",
            "/notification/**",
            "/supportTicket/**",
            "/swagger-ui/**",
            "/v3/api-docs/**",
            "/swagger-resources/**",
            "/webjars/**"
    };

    public static final String[] EMPLOYEE_URLS = {
            "/allowance/**",
            "/basicsList/**",
            "/deductionList/**",
            "/degreeList/**",
            "/department/**",
            "/designation/**",
            "/documentList/**",
            "/empDependent/**",
            "/empDocuments/**",
            "/empEductionDetails/**",
            "/experiance/**",
            "/empJoining/**",
            "/employeeKeySkill/**",
            "/employeePersonalDetails/**",
            "/roleMaster/**",
            "/skillList/**",
            "/stream/**",
            "/auth/**",
            "/notification/**",
            "/supportTicket/**",
            "/swagger-ui/**",
            "/v3/api-docs/**",
            "/swagger-resources/**",
            "/webjars/**"
    };

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity security) throws Exception {
        return security.csrf(csrf -> csrf.disable())
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .authorizeHttpRequests(auth -> auth
                        // allow public URLs without authentication
                        .requestMatchers(PUBLIC_URLS).permitAll()

                        // allow EMPLOYEE and ADMIN access to Employee-specific URLs
                        .requestMatchers(EMPLOYEE_URLS).hasAnyRole("EMPLOYEE", "ADMIN")

                        // allow only ADMIN access to Admin-specific URLs
                        .requestMatchers(ADMIN_URLS).hasRole("ADMIN")

                        // all other requests need to be authenticated
                        .anyRequest().authenticated()
                )
                .exceptionHandling(ex -> ex.authenticationEntryPoint(point))
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .addFilterBefore(filter, UsernamePasswordAuthenticationFilter.class)
                .httpBasic(customizer -> customizer.realmName("Admin Realm"))
                .build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.addAllowedOrigin("http://localhost:3000");
        configuration.addAllowedOrigin("http://192.168.29.245:9093");
        configuration.addAllowedOrigin("http://www.swatiind.co.in:9093");
        configuration.addAllowedHeader("*");
        configuration.addAllowedMethod("*");
        configuration.setAllowCredentials(true);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }

    @Bean
    public GrantedAuthorityDefaults grantedAuthorityDefaults() {
        return new GrantedAuthorityDefaults("");  // removes ROLE_ prefix
    }

}
