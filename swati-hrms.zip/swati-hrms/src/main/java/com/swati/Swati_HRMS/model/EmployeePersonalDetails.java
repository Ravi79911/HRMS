package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

@Data
@Entity
@Table(name = "employee_personal_details")
public class EmployeePersonalDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "employee_id", nullable = false)
	private String employeeId;

	@Column(name = "office_working_location")
	private String officeWorkingLocation;

	@Column(name = "work_mode")
	private String workMode;

	@Column(name = "employee_first_name", nullable = false)
	private String employeeFirstName;

	@Column(name = "employee_last_name", nullable = false)
	private String employeeLastName;

	@Column(name = "employee_father_name")
	private String employeeFatherName;

	@Column(name = "employee_mothers_name")
	private String employeeMotherName;

	@Column(name = "dob", nullable = false)
	private LocalDate dob;

	@Column(name = "gender", nullable = false)
	private String gender;

	@Column(name = "mob_no", nullable = false)
	private String mobileNo;

	@Column(name = "email", nullable = false)
	private String email;

	@Column(name = "guardian_mob_no", nullable = false)
	private String guardianMobNo;

	@Column(name = "aadhaar_no", nullable = false)
	private String aadhaarNo;

	@Column(name = "pan_no", nullable = false)
	private String panNo;

	@Column(name = "local_address", nullable = false)
	private String localAddress;

	@Column(name = "local_pin_code", nullable = false)
	private String localPinCode;

	@Column(name = "local_city", nullable = false)
	private String localCity;

	@Column(name = "local_state", nullable = false)
	private String localState;

	@Column(name = "local_country", nullable = false)
	private String localCountry;

	@Column(name = "permanent_address", nullable = false)
	private String permanentAddress;

	@Column(name = "permanent_pin_code", nullable = false)
	private String permanentPinCode;

	@Column(name = "permanent_city", nullable = false)
	private String permanentCity;

	@Column(name = "permanent_state", nullable = false)
	private String permanentState;

	@Column(name = "permanent_country", nullable = false)
	private String permanentCountry;

	@Column(name = "created_by")
	private Integer createdBy;

	@Column(name = "created_date")
	private LocalDateTime createdDate;

	@Column(name = "updated_by")
	private Integer updatedBy;

	@Column(name = "updated_date")
	private LocalDateTime updatedDate;

	@Column(name = "suspendend_status")
	private Integer suspendedStatus;

	@ManyToOne
	@JoinColumn(name = "department_mas_id", referencedColumnName = "id")
	private Department department;

	@OneToMany(mappedBy = "employeePersonalDetails", cascade = CascadeType.ALL)
	private Set<EmployeeKeySkill> employeeKeySkills;

	@OneToMany(mappedBy = "employeePersonalDetails", cascade = CascadeType.ALL)
	private Set<EmpEducationDetails> empEducationDetails;

	@OneToMany(mappedBy = "employeePersonalDetails", cascade = CascadeType.ALL)
	private Set<EmployeeExperienceDetails> empExperienceDetails;

	@OneToMany(mappedBy = "employeePersonalDetails", cascade = CascadeType.ALL)
	private Set<EmployeeDependent> employeeDependents;

}
