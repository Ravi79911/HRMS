package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.PfMaster;
import com.swati.Swati_HRMS.repository.PfMasterRepository;
import com.swati.Swati_HRMS.service.PfMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PfMasterServiceImpl implements PfMasterService {

    @Autowired
    private PfMasterRepository pfMasterRepository;

    @Override
    public PfMaster savePfMaster(PfMaster pfMaster) {
        LocalDateTime currentDateTime = LocalDateTime.now();
        pfMaster.setCreatedDate(currentDateTime);
        pfMaster.setUpdatedDate(LocalDateTime.now());
        pfMaster.setUpdatedBy(pfMaster.getUpdatedBy() != null ? pfMaster.getUpdatedBy() : 0);
        pfMaster.setSuspendedStatus(pfMaster.getSuspendedStatus() != null ? pfMaster.getSuspendedStatus() : 0);
        return pfMasterRepository.saveAndFlush(pfMaster);
    }

    @Override
    public List<PfMaster> findAllPfMaster() {
        return pfMasterRepository.findAll();
    }

    @Override
    public PfMaster updatePfMaster(Long id, PfMaster updatedPfMaster) {
        Optional<PfMaster> pfMasterOptional = pfMasterRepository.findById(id);
        if (pfMasterOptional.isPresent()) {
            PfMaster existingPfMaster = pfMasterOptional.get();
            existingPfMaster.setSuspendedStatus(updatedPfMaster.getSuspendedStatus());
            existingPfMaster.setEmployerContributionRate(updatedPfMaster.getEmployerContributionRate());
            existingPfMaster.setEmployeeContributionEpf(updatedPfMaster.getEmployeeContributionEpf());
            existingPfMaster.setPensionContributionEps(updatedPfMaster.getPensionContributionEps());

            return pfMasterRepository.saveAndFlush(existingPfMaster);
        } else {
            throw new RuntimeException("moduleMaster not found with id: " + id);
        }
    }
}
