package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "emp_asset")
public class EmpAsset {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment for the id
    @Column(name = "id")
    private Long id;

    @Column(name = "asset_serial_no", nullable = false, length = 100)
    private String assetSerialNo;  // Asset serial number

    @Column(name = "asset_tag", nullable = false, length = 100)
    private String assetTag;  // Asset tag

    @Column(name = "condition", length = 50)
    private String condition;  // Asset condition (can be null or empty)

    @Column(name = "assign_date", nullable = false)
    private LocalDate assignDate;  // Date the asset was assigned

    @Column(name = "return_date")
    private LocalDate returnDate;  // Date the asset is to be returned (nullable)

    @Column(name = "issued_by", nullable = false)
    private Integer issuedBy;  // ID of the person who issued the asset

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;  // Timestamp of when the record was created

    @Column(name = "created_by", nullable = false)
    private Integer createdBy;  // ID of the user who created the record

    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "dd_asset_name_id", referencedColumnName = "id", nullable = false)
    private DDAssetNameMaster ddAssetName;

    @ManyToOne
    @JoinColumn(name = "emp_per_id", referencedColumnName = "id", nullable = false)
    private EmployeePersonalDetails employeePersonalDetails;
}
