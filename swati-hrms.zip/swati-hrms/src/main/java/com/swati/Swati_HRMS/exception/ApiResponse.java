package com.swati.Swati_HRMS.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.poi.ss.formula.functions.T;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApiResponse {

    private String message;
    private boolean success;
    private LocalDateTime timestamp;
    private String errorCode;
    private Map<String, String> errors;
    private Optional<Object> data;

    // constructor for basic response with message and success status
    public ApiResponse(String message, boolean success) {
        this.message = message;
        this.success = success;
        this.timestamp = LocalDateTime.now();
        this.errors = Map.of();
        this.data = Optional.empty();
    }

    // constructor for response with message, success, and additional data
    public ApiResponse(String message, boolean success, Object data) {
        this.message = message;
        this.success = success;
        this.timestamp = LocalDateTime.now();
        this.errors = Map.of();
        this.data = Optional.ofNullable(data);
    }

    // constructor for response with message, success, and error code (no validation errors)
    public ApiResponse(String message, boolean success, String errorCode) {
        this.message = message;
        this.success = success;
        this.timestamp = LocalDateTime.now();
        this.errorCode = errorCode;
        this.errors = Map.of();
        this.data = Optional.empty();
    }

    public ApiResponse(String message, boolean success, LocalDateTime timestamp, String errorCode, Map<String, String> errors) {
        this.message = message;
        this.success = success;
        this.timestamp = timestamp;
        this.errorCode = errorCode;
        this.errors = errors != null ? errors : Map.of();
        this.data = Optional.empty();
    }

    // convenient method to create a failure response
    public static ApiResponse failure(String message, String errorCode) {
        return new ApiResponse(message, false, errorCode);
    }

    // convenient method to create a successful response
    public static ApiResponse success(String message, Object data) {
        return new ApiResponse(message, true, data);
    }

    @Override
    public String toString() {
        return "ApiResponse{" +
                "message='" + message + '\'' +
                ", success=" + success +
                ", timestamp=" + timestamp +
                ", errorCode='" + errorCode + '\'' +
                ", errors=" + errors +
                ", data=" + data.orElse("No data available") +
                '}';
    }

}
