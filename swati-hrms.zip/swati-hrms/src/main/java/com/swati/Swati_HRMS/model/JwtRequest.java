package com.swati.Swati_HRMS.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class JwtRequest {

    private String emailOrEmployeeId;
    private String password;

}
