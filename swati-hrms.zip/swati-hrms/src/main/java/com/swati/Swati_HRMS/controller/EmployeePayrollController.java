package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.dto.EmployeePayrollResponse;
import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.exception.ResourceNotFoundException;
import com.swati.Swati_HRMS.model.EmployeePayroll;
import com.swati.Swati_HRMS.model.EmployeePayrollSetup;
import com.swati.Swati_HRMS.repository.EmployeePayrollSetupRepository;
import com.swati.Swati_HRMS.service.EmployeePayrollService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Month;
import java.time.YearMonth;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/employeePayroll")
public class EmployeePayrollController {

    @Autowired
    private EmployeePayrollService payrollService;

    @Autowired
    private EmployeePayrollSetupRepository payrollSetupRepository;

    @PostMapping("/generate")
    public ResponseEntity<?> generatePayroll(
            @RequestParam Long employeePersonalId,
            @RequestParam String month,
            @RequestParam Integer year){

       //  Validate month and year are not current or future
        if (!isValidHistoricalDate(month, year)) {
            ApiResponse errorResponse = ApiResponse.failure("Cannot process current or future months", "INVALID_DATE_RANGE");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }

        // Find the payroll setup by ID
        Optional<EmployeePayrollSetup> payrollSetupOptional = payrollSetupRepository.findByEmployee_Id(employeePersonalId);

        // Return 404 if the payroll setup doesn't exist
        if (!payrollSetupOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        // Get the payroll setup from the Optional
        EmployeePayrollSetup payrollSetup = payrollSetupOptional.get();

        EmployeePayrollResponse response = payrollService.generateAndSavePayroll(
                payrollSetup, month, year);

        if (response == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(response);
    }


    @GetMapping("/getAll")
    public ResponseEntity<List<EmployeePayrollResponse>> getAllPayrolls() {
        List<EmployeePayrollResponse> payrolls = payrollService.getAllPayrolls();
        return ResponseEntity.ok(payrolls);
    }

    @GetMapping("/getByEmployeePersonalIdMonthAndByYear")
    public ResponseEntity<?> getPayrollByEmpCodeAndPeriod(
            @RequestParam Long employeePersonalId,
            @RequestParam String month,
            @RequestParam Integer year) {

        //  Validate month and year are not current or future
        if (!isValidHistoricalDate(month, year)) {
            ApiResponse errorResponse = ApiResponse.failure("Cannot process current or future months", "INVALID_DATE_RANGE");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }

        // Find the payroll setup by ID
        Optional<EmployeePayrollSetup> payrollSetupOptional = payrollSetupRepository.findByEmployee_Id(employeePersonalId);

        // Return 404 if the payroll setup doesn't exist
        if (!payrollSetupOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        // Get the payroll setup from the Optional
        EmployeePayrollSetup payrollSetup = payrollSetupOptional.get();

        return new ResponseEntity<>(payrollService.getPayrollByEmpCodeAndPeriod(payrollSetup.getEmployee().getEmployeeId(), month, year), HttpStatus.OK);

    }

    @GetMapping("/getByEmployeeCodeAndMonthAndYear")
    public ResponseEntity<?> getPayrollByEmpCodeAndPeriod(
            @RequestParam String employeeCode,
            @RequestParam String month,
            @RequestParam Integer year) {

        //  Validate month and year are not current or future
        if (!isValidHistoricalDate(month, year)) {
            ApiResponse errorResponse = ApiResponse.failure("Cannot process current or future months", "INVALID_DATE_RANGE");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }

        return new ResponseEntity<>(payrollService.getPayrollByEmpCodeAndPeriod(employeeCode, month, year), HttpStatus.OK);
    }

//    @GetMapping("/employee/{empCode}")
//    public ResponseEntity<List<EmployeePayrollResponse>> getPayrollsByEmpCode(
//            @PathVariable String empCode) {
//
//        List<EmployeePayrollResponse> payrolls = payrollService.getPayrollsByEmpCode(empCode);
//        return ResponseEntity.ok(payrolls);
//    }
//
//    @GetMapping("/period")
//    public ResponseEntity<List<EmployeePayrollResponse>> getPayrollsByPeriod(
//            @RequestParam String month,
//            @RequestParam Integer year) {
//
//        List<EmployeePayrollResponse> payrolls = payrollService.getPayrollsByPeriod(month, year);
//        return ResponseEntity.ok(payrolls);
//    }

    private boolean isValidHistoricalDate(String monthStr, Integer year) {
        try {
            // Convert month string to Month enum (case insensitive)
            Month requestMonth = Month.valueOf(monthStr.toUpperCase());
            YearMonth requestYearMonth = YearMonth.of(year, requestMonth);
            YearMonth currentYearMonth = YearMonth.now();

            // Check if the requested year is future
            if (year > currentYearMonth.getYear()) {
                return false;
            }

            // If same year, ensure the month is before current month
            if (year.equals(currentYearMonth.getYear())) {
                return requestMonth.getValue() < currentYearMonth.getMonth().getValue();
            }

            // Past years are always valid
            return true;
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid month provided: " + monthStr);
            return false;
        }
    }

    @GetMapping("/getByDepartmentMonthAndYear")
    public ResponseEntity<List<?>> getEmployeePayrollsByDepartment(
            @RequestParam String department,
            @RequestParam String month,
            @RequestParam Integer year) {

        //  Validate month and year are not current or future
        if (!isValidHistoricalDate(month, year)) {
            ApiResponse errorResponse = ApiResponse.failure("Cannot process current or future months", "INVALID_DATE_RANGE");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.singletonList(errorResponse));
        }
        return ResponseEntity.ok(payrollService.getEmployeePayrollsByDepartment(department, month, year));
    }

    @PutMapping("/updateById")
    public ResponseEntity<?> updatePayrollAndApprove(
            @RequestParam Long payrollId,
            @RequestBody EmployeePayroll updatedPayrollData) {

        try {
            Optional<EmployeePayrollResponse> response = payrollService.updatePayrollAndApprovedStatus(payrollId, updatedPayrollData);

            if (response.isPresent()) {
                return ResponseEntity.ok(response.get());
            } else {
                return ResponseEntity.notFound().build();
            }        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PatchMapping("/verifyPayroll/{payrollId}")
    public ResponseEntity<?> verifyPayroll(@PathVariable Long payrollId) {
        ApiResponse response= ApiResponse.success("Payroll verified successfully", payrollService.verifyPayroll(payrollId));
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/deletePayroll/{payrollId}")
    public String deletePayroll(@PathVariable Long payrollId) {
       ApiResponse response= ApiResponse.success("Payroll deleted successfully", payrollService.deletePayroll(payrollId));
        return response.getMessage();
    }
}
