package com.swati.Swati_HRMS.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmployeePfCalculationDTO {
    private Long id;
    private String empCode;
    private String empName;
    private String department;
    private String designation;
    private String month;
    private Integer year;
    private Integer monthDays;
    private Integer totalWorkingDays;
    private Integer totalPresentDays;
    private Integer totalAbsentDays;
    private Double basicSalary;
    private Double employeePfAmount;
    private Double employerEpfAmount;
    private Double employerNpsAmount;
    private Double totalEmployerContribution;
    private LocalDateTime createdDate;
    private Long suspendedStatus;
    private boolean isApproved;
}
