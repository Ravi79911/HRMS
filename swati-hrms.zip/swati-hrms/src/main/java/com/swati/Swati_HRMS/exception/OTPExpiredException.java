package com.swati.Swati_HRMS.exception;

import lombok.Data;

@Data
public class OTPExpiredException extends RuntimeException {

    public OTPExpiredException(String message) {
        super(message);
    }

}
