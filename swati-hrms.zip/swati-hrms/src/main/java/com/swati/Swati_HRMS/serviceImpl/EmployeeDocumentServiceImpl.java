package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.dto.EmployeeDocumentsDTO;
import com.swati.Swati_HRMS.exception.ResourceNotFoundException;
import com.swati.Swati_HRMS.model.DocumentList;
import com.swati.Swati_HRMS.model.EmployeeDocument;
import com.swati.Swati_HRMS.repository.DocumentListRepository;
import com.swati.Swati_HRMS.repository.EmployeeDocumentRepository;
import com.swati.Swati_HRMS.service.EmployeeDocumentService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class EmployeeDocumentServiceImpl implements EmployeeDocumentService {

    @Autowired
    EmployeeDocumentRepository employeeDocumentRepository;

    @Autowired
    DocumentListRepository documentListRepository;

    @Autowired
    ModelMapper modelMapper;

    @Value("${upload.employee.doc.dir}")
    private String BASE_UPLOAD_DIR;

    private static final long MAX_FILE_SIZE = 2 * 1024 * 1024; // 2MB

    @Override
    public EmployeeDocument createEmployeeDocument(EmployeeDocument employeeDocument, Long documentListId, MultipartFile documentFile) {
        employeeDocument.setSuspendedStatus(employeeDocument.getSuspendedStatus() != null ? employeeDocument.getSuspendedStatus() : 0);
        employeeDocument.setCreatedDate(LocalDateTime.now());

        // handle file upload if a file is provided
        if (documentFile != null && !documentFile.isEmpty()) {
            String uploadedFilePath = handleDocumentUpload(employeeDocument, documentListId, documentFile);
            employeeDocument.setDocFile(uploadedFilePath);
        }
        return employeeDocumentRepository.saveAndFlush(employeeDocument);
    }

    @Override
    public List<String> getDocumentUrlsByEmployeePersonalDetailsId(Long employeePersonalDetailsId) {
        List<EmployeeDocument> documentList = employeeDocumentRepository.findByEmployeePersonalDetails_Id(employeePersonalDetailsId);

        if (documentList.isEmpty()) {
            throw new ResourceNotFoundException("Employee Documents", "employeePersonalDetailsId", employeePersonalDetailsId);
        }

        return documentList.stream()
                .map(EmployeeDocument::getDocFile)
                .collect(Collectors.toList());
    }

    @Override
    public List<EmployeeDocumentsDTO> getEmployeeKeySkillByEmployeePersonalDetailsId(Long id) {
        List<EmployeeDocument> employeeDocuments = employeeDocumentRepository.findByEmployeePersonalDetails_Id(id);
        return employeeDocuments.stream()
                .map(skill -> modelMapper.map(skill, EmployeeDocumentsDTO.class))
                .collect(Collectors.toList());
    }

    public String handleDocumentUpload(EmployeeDocument employeeDocument, Long documentListId, MultipartFile documentFile) {
        // fetch DocumentList from the id
        DocumentList documentList = documentListRepository.findById(documentListId)
                .orElseThrow(() -> new ResourceNotFoundException("Document List", "id", documentListId));

        String documentName = documentList.getDocName();
        if (documentName == null || documentName.isEmpty()) {
            throw new IllegalArgumentException("Document name is missing.");
        }

        documentName = documentName.replace(" ", "_");

        if (documentFile != null && !documentFile.isEmpty()) {
            if (!isPdf(documentFile)) {
                throw new IllegalArgumentException("Only PDF files are allowed.");
            }

            if (documentFile.getSize() > MAX_FILE_SIZE) {
                throw new IllegalArgumentException("File size exceeds the maximum limit of " + MAX_FILE_SIZE / (1024 * 1024) + " MB.");
            }

            try {
                // ensure the directory exists
                Path typeDirectory = Paths.get(BASE_UPLOAD_DIR, documentName);
                if (!Files.exists(typeDirectory)) {
                    Files.createDirectories(typeDirectory);
                }

                // generate unique filename
                String newFileName = documentName + "_" + UUID.randomUUID() + ".pdf";
                newFileName = newFileName.replace(" ", "_");

                // save the file locally
                Path filePath = typeDirectory.resolve(newFileName);
                Files.write(filePath, documentFile.getBytes());

                // generate the file URL
                String fileUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                        .path("/employeeDocuments/")
                        .path(documentName + "/")
                        .path(newFileName)
                        .toUriString();

                return fileUrl;
            } catch (IOException e) {
                throw new RuntimeException("Error while saving the document: " + e.getMessage(), e);
            }
        } else {
            throw new IllegalArgumentException("Uploaded file is null or empty.");
        }
    }

    // check if the uploaded file is a PDF
    private boolean isPdf(MultipartFile file) {
        String contentType = file.getContentType();
        return contentType != null && contentType.equals("application/pdf");
    }

//    public String handleDocumentUpload(EmployeeDocument employeeDocument, Long documentListId, MultipartFile documentFile) {
//        // fetch DocumentList from the id
//        DocumentList documentList = documentListRepository.findById(documentListId)
//                .orElseThrow(() -> new ResourceNotFoundException("Document List", "id", documentListId));
//
//        String documentName = documentList.getDocName();
//        if (documentName == null || documentName.isEmpty()) {
//            throw new IllegalArgumentException("Document name is missing.");
//        }
//
//        documentName = documentName.replace(" ", "_");
//
//        if (documentFile != null && !documentFile.isEmpty()) {
//            if (!isValidDocumentType(documentFile)) {
//                throw new IllegalArgumentException("Only PDF, JPG, and JPEG files are allowed.");
//            }
//
//            if (documentFile.getSize() > MAX_FILE_SIZE) {
//                throw new IllegalArgumentException("File size exceeds the maximum limit of " + MAX_FILE_SIZE / (1024 * 1024) + " MB.");
//            }
//
//            try {
//                Path typeDirectory = Paths.get(BASE_UPLOAD_DIR, documentName);
//                if (!Files.exists(typeDirectory)) {
//                    Files.createDirectories(typeDirectory);
//                }
//
//                String newFileName = documentName + "_" + UUID.randomUUID();
//                String extension = getFileExtension(documentFile);  // Get the file extension
//                newFileName = newFileName + "." + extension;
//
//                Path filePath = typeDirectory.resolve(newFileName);
//                Files.write(filePath, documentFile.getBytes());
//
//                String fileUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
//                        .path("/employeeDocuments/")
//                        .path(documentName + "/")
//                        .path(newFileName)
//                        .toUriString();
//
//                return fileUrl;
//            } catch (IOException e) {
//                throw new RuntimeException("Error while saving the document: " + e.getMessage(), e);
//            }
//        } else {
//            throw new IllegalArgumentException("Uploaded file is null or empty.");
//        }
//    }
//
//    // check if the uploaded file is a valid type (PDF, JPG, JPEG)
//    private boolean isValidDocumentType(MultipartFile file) {
//        String contentType = file.getContentType();
//        return contentType != null &&
//                (contentType.equals("application/pdf") || contentType.equals("image/jpeg"));
//    }
//
//    // get the file extension (jpg or pdf)
//    private String getFileExtension(MultipartFile file) {
//        String contentType = file.getContentType();
//        if (contentType != null) {
//            if (contentType.equals("application/pdf")) {
//                return "pdf";
//            } else if (contentType.equals("image/jpeg")) {
//                return "jpg";
//            }
//        }
//        return null;
//    }

}
