package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.exception.ResourceNotFoundException;
import com.swati.Swati_HRMS.model.Department;
import com.swati.Swati_HRMS.model.EmployeeEsicCalculation;
import com.swati.Swati_HRMS.model.EmployeePayroll;
import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import com.swati.Swati_HRMS.repository.EmployeeEsicCalculationRepo;
import com.swati.Swati_HRMS.repository.EmployeePayrollRepository;
import com.swati.Swati_HRMS.repository.EmployeePersonalDetailsRepository;
import com.swati.Swati_HRMS.service.EmployeeEsicCalculationService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.YearMonth;
import java.util.Optional;

@Service
public class EmployeeEsicCalculationServiceImpl implements EmployeeEsicCalculationService {

    @Autowired
    private EmployeeEsicCalculationRepo employeeEsicCalculationRepo;

    @Autowired
    private EmployeePersonalDetailsRepository employeePersonalDetailsRepository;

    @Autowired
    private EmployeePayrollRepository employeePayrollRepository;

    @Override
    public EmployeeEsicCalculation saveEmployeeEsicCalculation(Long employeePersonalInfoId, String month, Integer year) {

        EmployeePersonalDetails employeePersonalDetails = employeePersonalDetailsRepository
                .findById(employeePersonalInfoId)
                .orElseThrow(() -> new EntityNotFoundException("Employee not found with ID: " + employeePersonalInfoId));

        Department department = employeePersonalDetails.getDepartment();
        if (department == null) {
            throw new EntityNotFoundException("Department not found for employee ID: " + employeePersonalInfoId);
        }

        EmployeePayroll employeePayroll = employeePayrollRepository
                .findByEmpCodeAndMonthAndYear(employeePersonalDetails.getEmployeeId(), month, year)
                .orElseThrow(() -> new EntityNotFoundException("Payroll not found for employee "
                        + employeePersonalDetails.getEmployeeId() + " for " + month + "/" + year));
        Optional<EmployeeEsicCalculation> existingEsicCalculationOpt = employeeEsicCalculationRepo
                .findByEmpCodeAndMonthAndYear(employeePersonalDetails.getEmployeeId(), month, year);

        if (existingEsicCalculationOpt.isPresent()) {
            throw new IllegalArgumentException("ESIC calculation already exists for employee "
                    + employeePersonalDetails.getEmployeeId() + " for " + month + "/" + year);
        }
        EmployeeEsicCalculation employeeEsicCalculation = new EmployeeEsicCalculation();
        employeeEsicCalculation.setEmpCode(employeePersonalDetails.getEmployeeId());
        employeeEsicCalculation.setEmpName(employeePersonalDetails.getEmployeeFirstName() + " " + employeePersonalDetails.getEmployeeLastName());
        employeeEsicCalculation.setDepartment(department.getDepartment());
        employeeEsicCalculation.setDesignation(employeePayroll.getDesignation());
        employeeEsicCalculation.setMonth(employeePayroll.getMonth());
        employeeEsicCalculation.setYear(employeePayroll.getYear());
        employeeEsicCalculation.setTotalWorkingDays(employeePayroll.getTotalWorkingDays());
        employeeEsicCalculation.setTotalPresentDays(employeePayroll.getTotalPresentDays());
        employeeEsicCalculation.setTotalAbsentDays(employeePayroll.getTotalAbsentDays());
        employeeEsicCalculation.setGrossSalary(employeePayroll.getGrossSalary());

        if (employeePayroll.getGrossSalary() <= 21000) {
            double employeeContribution = round(employeePayroll.getGrossSalary() * 0.0075);
            double employerContribution = round(employeePayroll.getGrossSalary() * 0.0325);
            employeeEsicCalculation.setEmployeeContributionAmount(employeeContribution);
            employeeEsicCalculation.setEmployerContributionAmount(employerContribution);
        } else {
            employeeEsicCalculation.setEmployeeContributionAmount(0.0);
            employeeEsicCalculation.setEmployerContributionAmount(0.0);
        }

        Integer monthDays = getDaysInMonth(employeePayroll.getMonth(), employeePayroll.getYear());
        employeeEsicCalculation.setMonthDays(monthDays.longValue());
        employeeEsicCalculation.setCreatedDate(LocalDateTime.now());
        employeeEsicCalculation.setSuspendedStatus(0L);
        employeeEsicCalculation.setIsApproved(false);

        return employeeEsicCalculationRepo.saveAndFlush(employeeEsicCalculation);
    }

    // Utility method for rounding
    private double round(double value) {
        return new BigDecimal(value).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }


    public static int getDaysInMonth(String monthName, int year) {
        // Convert the month name to uppercase and map it to the Month enum
        Month month = Month.valueOf(monthName.toUpperCase());
        // Use YearMonth to get number of days
        YearMonth yearMonth = YearMonth.of(year, month);
        return yearMonth.lengthOfMonth();
    }

    @Override
    public Optional<EmployeeEsicCalculation> getEmployeeEsicCalculationByEmpCode(String empCode, String month, Integer year) {
        return employeeEsicCalculationRepo.findByEmpCodeAndMonthAndYear(empCode, month, year);
    }

    @Override
    public Optional<EmployeeEsicCalculation> verifyPfCalculation(Long id) {
        Optional<EmployeeEsicCalculation> existingPfCalculationOpt = employeeEsicCalculationRepo.findById(id);
        if (!existingPfCalculationOpt.isPresent()) {
            throw new ResourceNotFoundException("ESIC Calculation not found for ID: " + id);
        }
        existingPfCalculationOpt.get().setIsApproved(true);
        EmployeeEsicCalculation savedPfCalculation = employeeEsicCalculationRepo.save(existingPfCalculationOpt.get());
        return Optional.of(savedPfCalculation);
    }

    @Override
    public String deleteEsicCalculation(Long id) {
        Optional<EmployeeEsicCalculation> existingPfCalculationOpt = employeeEsicCalculationRepo.findById(id);
        if (!existingPfCalculationOpt.isPresent()) {
            throw new ResourceNotFoundException("ESIC Calculation not found for ID: " + id);
        }
        employeeEsicCalculationRepo.delete(existingPfCalculationOpt.get());
        return "Deleted Successfully";
    }
}
