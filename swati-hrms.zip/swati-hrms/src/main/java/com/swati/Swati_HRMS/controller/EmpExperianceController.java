package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.dto.EmployeeExperienceDetailsDTO;
import com.swati.Swati_HRMS.dto.EmployeeKeySkillDTO;
import com.swati.Swati_HRMS.model.EmployeeExperienceDetails;
import com.swati.Swati_HRMS.service.EmpExperianceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/experiance")
public class EmpExperianceController {

    @Autowired
    private EmpExperianceService empExperianceService;

    @PostMapping("/saveEmployeeExperience")
    public ResponseEntity<EmployeeExperienceDetails> saveEmployeeExperience(@RequestBody EmployeeExperienceDetails employeeExperienceDetails) {
        return ResponseEntity.ok(empExperianceService.saveEmployeeExperience(employeeExperienceDetails));
    }

    @GetMapping("/getByEmployeeKeySkillByPersonalDetailsId")
    public ResponseEntity<List<EmployeeExperienceDetailsDTO>> getByEmployeeKeySkillId(@RequestParam Long id){
        List<EmployeeExperienceDetailsDTO> employeeExperienceDto = empExperianceService.getEmployeeKeySkillByEmployeePesronalDetailsId(id);
        return ResponseEntity.ok(employeeExperienceDto);
    }
}
