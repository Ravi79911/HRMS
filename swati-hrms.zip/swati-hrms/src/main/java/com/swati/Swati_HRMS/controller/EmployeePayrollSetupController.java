package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.dto.EmployeePayrollResponse;
import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.exception.ResourceNotFoundException;
import com.swati.Swati_HRMS.model.Employee;
import com.swati.Swati_HRMS.model.EmployeePayrollSetup;
import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import com.swati.Swati_HRMS.repository.*;
import com.swati.Swati_HRMS.service.EmployeePayrollSetupService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.Month;
import java.time.YearMonth;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/employeePayrollSetup")
public class EmployeePayrollSetupController {

    @Autowired
    EmployeePayrollSetupService employeePayrollSetupService;

//    @Autowired
//    EmployeeRepository employeeRepository;

    @Autowired
    EmployeePersonalDetailsRepository employeePersonalDetailsRepository;

    @Autowired
    BasicListRepository basicListRepository;

    @Autowired
    AllowanceListRepository allowanceListRepository;

    @Autowired
    DeductionListRepository deductionListRepository;

    @PostMapping("/createEmployeePayrollSetup")
    public ResponseEntity<ApiResponse> createPayrollSetups(@RequestParam("empId") Long empId,
                                                           @RequestParam("basicListIds") List<Long> basicListIds,
                                                           @RequestParam("allowanceListIds") List<Long> allowanceListIds,
                                                           @RequestParam("deductionListIds") List<Long> deductionListIds,
                                                           @RequestParam("createdBy") Long createdBy) {
        try {
            // validate employee existence
//            Employee employee = employeeRepository.findById(empId)
//                    .orElseThrow(() -> new ResourceNotFoundException("Employee", "id", empId));

            // get associated personal details
            EmployeePersonalDetails personalDetails = employeePersonalDetailsRepository.findById(empId)
                    .orElseThrow(() -> new ResourceNotFoundException("EmployeePersonalDetails", "employeePersonalDetailsId", empId));

            EmployeePayrollSetup employeePayrollSetup = new EmployeePayrollSetup();
            employeePayrollSetup.setEmployee(personalDetails);
            employeePayrollSetup.setBasicLists(basicListRepository.findAllById(basicListIds));
            employeePayrollSetup.setAllowanceLists(allowanceListRepository.findAllById(allowanceListIds));
            employeePayrollSetup.setDeductionLists(deductionListRepository.findAllById(deductionListIds));
            employeePayrollSetup.setCreatedBy(createdBy);
            EmployeePayrollSetup createdPayrollSetup = employeePayrollSetupService.createEmployeePayrollSetup(employeePayrollSetup);
            return ResponseEntity.ok(new ApiResponse("Payroll setup created successfully", true, createdPayrollSetup));

        } catch (ResourceNotFoundException ex) {
            log.error("Resource not found: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (RuntimeException ex) {
            log.error("Error occurred while creating payroll setup: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse("An error occurred while creating payroll setup", false), HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception ex) {
            log.error("Unexpected error occurred: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse("Unexpected error occurred", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getAllEmployeePayrollSetup")
    public ResponseEntity<ApiResponse> getAllEmployeePayrollSetups() {
        try {
            List<EmployeePayrollSetup> payrollSetups = employeePayrollSetupService.getAllEmployeePayrollSetup();
            if (payrollSetups.isEmpty()) {
                return new ResponseEntity<>(new ApiResponse("No payroll setups found", false), HttpStatus.NOT_FOUND);
            }
            return ResponseEntity.ok(new ApiResponse("Fetched all payroll setups successfully", true, payrollSetups));
        } catch (RuntimeException ex) {
            log.error("Error occurred while fetching payroll setups: {}", ex.getMessage(), ex);
            return new ResponseEntity<>(new ApiResponse("An error occurred while fetching payroll setups", false), HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception ex) {
            log.error("Unexpected error occurred while fetching payroll setups: {}", ex.getMessage(), ex);
            return new ResponseEntity<>(new ApiResponse("Unexpected error occurred", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getByEmployeeId/{id}")
    public ResponseEntity<ApiResponse> getPayrollSetupsByEmployeeId(@PathVariable Long id) {
        try {
            Optional<EmployeePayrollSetup> payrollSetups = employeePayrollSetupService.getPayrollSetupsByEmployeeId(id);
            if (payrollSetups.isEmpty()) {
                return new ResponseEntity<>(new ApiResponse("No payroll setups found for employee ID: " + id, false), HttpStatus.NOT_FOUND);
            }
            return ResponseEntity.ok(new ApiResponse("Fetched payroll setups for employee ID: " + id, true, payrollSetups));
        } catch (RuntimeException ex) {
            log.error("Error occurred while fetching payroll setups for employee ID {}: {}", id, ex.getMessage(), ex);
        }
        return new ResponseEntity<>(new ApiResponse("An error occurred while fetching payroll setups for employee ID: " + id, false), HttpStatus.INTERNAL_SERVER_ERROR);
    }


    @GetMapping("/calculateAndByEmployeeId/{id}")
    public ResponseEntity<?> calculateSalary(@PathVariable Long id) {
        Optional<EmployeePayrollSetup> payrollSetupOpt = employeePayrollSetupService.getPayrollSetupsByEmployeeId(id);

        if (payrollSetupOpt.isPresent()) {
            EmployeePayrollSetup payrollSetup = payrollSetupOpt.get();
            double grossSalary = employeePayrollSetupService.calculateGrossSalary(payrollSetup);
            double deductions = employeePayrollSetupService.calculateDeductions(payrollSetup);
            double netSalary = employeePayrollSetupService.calculateNetSalary(payrollSetup);

            Map<String, Object> response = new HashMap<>();
            response.put("grossSalary", grossSalary);
            response.put("deductions", deductions);
            response.put("netSalary", netSalary);

            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(404)
                    .body("Payroll setup not found for ID: " + id);
        }
    }


    @GetMapping
    public ResponseEntity<ApiResponse> getAllEmployeePayrolls(
            @RequestParam(required = false) String month,
            @RequestParam(required = false) Integer year) {

        // Validate month and year are not current or future
        if (!isValidHistoricalDate(month, year)) {
            ApiResponse errorResponse = ApiResponse.failure("Cannot process current or future months", "INVALID_DATE_RANGE");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }

        log.info("Fetching all employee payrolls for {}-{}", month, year);
        List<EmployeePayrollResponse> payrolls = employeePayrollSetupService.getAllEmployeePayrolls(month, year);

        ApiResponse response = ApiResponse.success("Fetched all employee payrolls successfully", payrolls);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/employee/{empCode}")
    public ResponseEntity<ApiResponse> getEmployeePayrollByEmpCode(
            @PathVariable String empCode,
            @RequestParam(required = false) String month,
            @RequestParam(required = false) Integer year) {

        // Validate month and year are not current or future
        if (!isValidHistoricalDate(month, year)) {
            ApiResponse errorResponse = ApiResponse.failure("Cannot process current or future months", "INVALID_DATE_RANGE");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }

        log.info("Fetching payroll for employee code: {} for {}-{}", empCode, month, year);
        EmployeePayrollResponse payroll = employeePayrollSetupService.getEmployeePayrollByEmpCode(empCode, month, year);

        if (payroll == null) {
            ApiResponse errorResponse = ApiResponse.failure("Employee payroll not found", "PAYROLL_NOT_FOUND");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
        }

        ApiResponse response = ApiResponse.success("Fetched employee payroll successfully", payroll);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/department/{department}")
    public ResponseEntity<ApiResponse> getEmployeePayrollsByDepartment(
            @PathVariable String department,
            @RequestParam(required = false) String month,
            @RequestParam(required = false) Integer year) {

        // Validate month and year are not current or future
        if (!isValidHistoricalDate(month, year)) {
            ApiResponse errorResponse = ApiResponse.failure("Cannot process current or future months", "INVALID_DATE_RANGE");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }

        log.info("Fetching payrolls for department: {} for {}-{}", department, month, year);
        List<EmployeePayrollResponse> payrolls = employeePayrollSetupService.getEmployeePayrollsByDepartment(department, month, year);

        ApiResponse response = ApiResponse.success("Fetched department payrolls successfully", payrolls);
        return ResponseEntity.ok(response);
    }

    private boolean isValidHistoricalDate(String monthStr, Integer year) {
        try {
            // Convert month string to Month enum (case insensitive)
            Month requestMonth = Month.valueOf(monthStr.toUpperCase());
            YearMonth requestYearMonth = YearMonth.of(year, requestMonth);
            YearMonth currentYearMonth = YearMonth.now();

            // Check if the requested year is future
            if (year > currentYearMonth.getYear()) {
                return false;
            }

            // If same year, ensure the month is before current month
            if (year.equals(currentYearMonth.getYear())) {
                return requestMonth.getValue() < currentYearMonth.getMonth().getValue();
            }

            // Past years are always valid
            return true;
        } catch (IllegalArgumentException e) {
            log.error("Invalid month provided: {}", monthStr, e);
            return false;
        }
    }
}
