package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "dd_office_working_location")
public class DDOfficeWorkingLocation {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;

    @Column(name = "location_name")
    private String locationName;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name="suspended_status")
    private Integer suspendedStatus;

}
