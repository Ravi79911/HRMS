package com.swati.Swati_HRMS.dto;


import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class EmployeeDependentDTO {

    private Long id;
    private String dependentName;
    private String relation;
    private LocalDate DOB;
    private String aadhaarNo;
    private int suspendedStatus;
    private String createdBy;
    private LocalDateTime createdDate ;
}

