package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Data
@Entity
@Table(name = "employee_attendance",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = {"employee_id", "attendance_month"})
        })
public class EmployeeAttendance {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "attendance_seq")
    @SequenceGenerator(name = "attendance_seq", sequenceName = "employee_attendance_id_seq", allocationSize = 1)
    private Long id;

    @Column(name = "employee_id", nullable = false)
    private Integer employeeId;

    @Column(name = "employee_name", nullable = false)
    private String employeeName;

    @Column(name = "designation")
    private String designation;

    @Column(name = "attendance_month", nullable = false)
    private String month;

    @Column(name = "attendance_year", nullable = false)
    private Integer year;

    @ManyToOne
    @JoinColumn(name = "emp_per_id", referencedColumnName = "id")
    private EmployeePersonalDetails employeePersonalDetails;

    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "employee_attendance_days",
            joinColumns = @JoinColumn(name = "attendance_id"))
    @MapKeyColumn(name = "day")
    @Column(name = "status")
    private Map<Integer, String> dailyAttendance = new HashMap<>();

    @CreationTimestamp
    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;
}