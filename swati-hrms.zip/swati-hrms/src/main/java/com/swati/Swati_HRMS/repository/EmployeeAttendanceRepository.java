package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.EmployeeAttendance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface EmployeeAttendanceRepository extends JpaRepository<EmployeeAttendance, Long> {
    Optional<EmployeeAttendance> findByEmployeeIdAndMonthAndYear(Integer employeeId, String month, Integer year);

    List<EmployeeAttendance> findByEmployeeId(Integer employeeId);

    List<EmployeeAttendance> findByMonth(String month);

    List<EmployeeAttendance> findByYear(Integer year);

    Optional<EmployeeAttendance> findByEmployeeIdAndMonth(Integer employeeId, String month);

    List<EmployeeAttendance> findByMonthAndYear(String month, Integer year);

    List<EmployeeAttendance> findByEmployeePersonalDetails_Id(Integer employeePersonalDetailsId);
}
