package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.Role;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface RoleService {

    Role createRole(Role role);

    List<Role> getAllRoles();

    Role getRoleById(Long id);

    Role updateRoleById(Long id, Role role);

    Role updateSuspendedStatus(Long id, Integer suspendedStatus, int updatedBy);

}
