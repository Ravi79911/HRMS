package com.swati.Swati_HRMS.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "emp_dependent_details")
public class EmployeeDependent {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "dependent_name")
	private String dependentName;

	@Column(name = "relation")
	private String relation;

	@Column(name = "dob")
	private LocalDate DOB;

	@Column(name = "aadhaar_no")
	private String aadhaarNo;

	@Column(name = "suspendend_status")
	private int suspendedStatus;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private LocalDateTime createdDate ;

	@ManyToOne
	@JoinColumn(name = "emp_master_id", referencedColumnName = "id", nullable = false)
	private EmployeePersonalDetails employeePersonalDetails;

}
