package com.swati.Swati_HRMS.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

@Data
@Entity
@Table(name = "employee_experience_details")
public class EmployeeExperienceDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "comp_name")
	private String companyName;

	@Column(name = "designation_name")
	private String designationName;

	@Column(name = "from_date")
	private LocalDate fromDate;

	@Column(name = "upto_date")
	private LocalDate uptoDate;

	@Column(name = "project_details")
	private String projectDetails;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private LocalDateTime createdDate;

	@Column(name = "suspendend_status")
	private int suspendedStatus ;

	@ManyToOne
	@JoinColumn(name = "emp_master_id", referencedColumnName = "id", nullable = false)
	private EmployeePersonalDetails employeePersonalDetails;

	@ManyToOne
	@JoinColumn(name = "designation_id", referencedColumnName = "id")
	private Designation designation;

}
