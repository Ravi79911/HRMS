package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.exception.ResourceNotFoundException;
import com.swati.Swati_HRMS.model.EmployeeAttendance;
import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import com.swati.Swati_HRMS.repository.EmployeeAttendanceRepository;
import com.swati.Swati_HRMS.repository.EmployeePersonalDetailsRepository;
import jakarta.transaction.Transactional;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.*;

@Service
@Transactional
public class ExcelImportService {

    private static final Logger logger = LoggerFactory.getLogger(ExcelImportService.class);

    @Autowired
    private EmployeeAttendanceRepository repository;

    @Autowired
    private EmployeePersonalDetailsRepository employeeRepository;

    @Transactional
    public void importAttendance(MultipartFile file) {
        try (InputStream inputStream = file.getInputStream();
             Workbook workbook = new XSSFWorkbook(inputStream)) {

            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rows = sheet.iterator();

            // Skip header row
            if (rows.hasNext()) rows.next();

            while (rows.hasNext()) {
                Row row = rows.next();

                // Validate row has enough cells
                if (row.getLastCellNum() < 7) continue; // Updated to account for new year column

                // Create attendance record
                EmployeeAttendance attendance = processRow(row);

                // Only save if we have valid data
                if (attendance != null) {
                    // Find corresponding EmployeePersonalDetails
                    Optional<EmployeePersonalDetails> employeeOpt =
                            employeeRepository.findByEmployeeId(
                                    getStringCellValue(row.getCell(2)) // Assuming column 2 is employee code
                            );

                    if (employeeOpt.isPresent()) {
                        // Set the EmployeePersonalDetails
                        attendance.setEmployeePersonalDetails(employeeOpt.get());

                        // Check if an attendance record for this employee, month, and year already exists
                        Optional<EmployeeAttendance> existingAttendance =
                                repository.findByEmployeeIdAndMonthAndYear(
                                        attendance.getEmployeeId(),
                                        attendance.getMonth(),
                                        attendance.getYear()
                                );

                        if (existingAttendance.isPresent()) {
                            // Update existing record
                            EmployeeAttendance existing = existingAttendance.get();
                            existing.setDesignation(attendance.getDesignation());
                            existing.setDailyAttendance(attendance.getDailyAttendance());
                            existing.setEmployeePersonalDetails(attendance.getEmployeePersonalDetails());
                            repository.save(existing);
                        } else {
                            // Save new record
                            repository.save(attendance);
                        }
                    } else {
                        // Log warning for employee not found
                        logger.warn("No employee found for code: " +
                                getStringCellValue(row.getCell(2)));
                    }
                }
            }

        } catch (Exception e) {
            logger.error("Failed to import attendance data", e);
            throw new RuntimeException("Failed to import attendance data: " + e.getMessage(), e);
        }
    }

    // Updated processRow method to include year
    private EmployeeAttendance processRow(Row row) {
        try {
            EmployeeAttendance attendance = new EmployeeAttendance();

            // Safely extract employee details
            attendance.setEmployeeId(getIntegerCellValue(row.getCell(2)));
            attendance.setEmployeeName(getStringCellValue(row.getCell(1)));
            attendance.setDesignation(getStringCellValue(row.getCell(3)));
            attendance.setMonth(getStringCellValue(row.getCell(4)));
            attendance.setYear(getIntegerCellValue(row.getCell(5))); // Assuming column 5 is year

            // Process daily attendance
            Map<Integer, String> dailyAttendance = new HashMap<>();
            for (int i = 7; i < row.getLastCellNum(); i++) { // Start from 7 instead of 6 due to new year column
                Cell cell = row.getCell(i);
                if (cell != null) {
                    String cellValue = getStringCellValue(cell);
                    // Skip weekend or empty entries
                    if (!cellValue.equalsIgnoreCase("Sunday") && !cellValue.isEmpty()) {
                        dailyAttendance.put(i - 6, cellValue); // "P", "A", "L", etc. (adjusted index for year column)
                    }
                }
            }
            attendance.setDailyAttendance(dailyAttendance);

            return attendance;
        } catch (Exception e) {
            logger.warn("Could not process row: " + e.getMessage());
            return null;
        }
    }

    // Existing helper methods for cell value extraction
    private Integer getIntegerCellValue(Cell cell) {
        if (cell == null) return null;

        switch (cell.getCellType()) {
            case NUMERIC:
                return (int) cell.getNumericCellValue();
            case STRING:
                try {
                    return Integer.parseInt(cell.getStringCellValue());
                } catch (NumberFormatException e) {
                    return null;
                }
            default:
                return null;
        }
    }

    private String getStringCellValue(Cell cell) {
        if (cell == null) return "";

        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                return String.valueOf((int) cell.getNumericCellValue());
            default:
                return "";
        }
    }

    public List<EmployeeAttendance> getAllAttendanceRecords() {
        return repository.findAll();
    }

    public EmployeeAttendance getAttendanceById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Attendance record not found with id: " + id));
    }

    public List<EmployeeAttendance> getAttendanceByEmployeeId(Integer employeeId) {
        return repository.findByEmployeeId(employeeId);
    }

    public List<EmployeeAttendance> getAttendanceByMonth(String month) {
        return repository.findByMonth(month);
    }

    public Optional<EmployeeAttendance> getAttendanceByEmployeeIdAndMonth(Integer employeeId, String month) {
        return repository.findByEmployeeIdAndMonth(employeeId, month);
    }

    public List<EmployeeAttendance> getAttendanceByEmployeePersonalDetailsId(Integer employeePersonalDetailsId) {
        return repository.findByEmployeePersonalDetails_Id(employeePersonalDetailsId);
    }

    public List<EmployeeAttendance> getAttendanceByMonthAndYear(String month, Integer year) {
        return repository.findByMonthAndYear(month, year);
    }

    public Optional<EmployeeAttendance> getAttendanceByEmployeeIdAndMonthAndYear(Integer employeeId, String month, Integer year) {
        return repository.findByEmployeeIdAndMonthAndYear(employeeId, month, year);
    }

    public List<EmployeeAttendance> getAttendanceByYear(Integer year) {
        return repository.findByYear(year);
    }
}