package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import com.swati.Swati_HRMS.model.HelpAndSupportTicket;
import com.swati.Swati_HRMS.notification.EmailService;
import com.swati.Swati_HRMS.repository.EmployeePersonalDetailsRepository;
import com.swati.Swati_HRMS.repository.HelpAndSupportTicketRepository;
import com.swati.Swati_HRMS.service.HelpAndSupportTicketService;
import jakarta.mail.MessagingException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
public class HelpAndSupportTicketServiceImpl implements HelpAndSupportTicketService {

    @Autowired
    HelpAndSupportTicketRepository helpAndSupportTicketRepository;

    @Autowired
    EmployeePersonalDetailsRepository employeePersonalDetailsRepository;

    @Autowired
    EmailService emailService;

    @Override
    public HelpAndSupportTicket createTicket(HelpAndSupportTicket helpAndSupportTicket) {
        helpAndSupportTicket.setCreatedDate(LocalDateTime.now());
        helpAndSupportTicket.setSuspendedStatus(helpAndSupportTicket.getSuspendedStatus() != null ? helpAndSupportTicket.getSuspendedStatus() : 0);

        HelpAndSupportTicket savedTicket = helpAndSupportTicketRepository.saveAndFlush(helpAndSupportTicket);

        // get employee details
        String employeeName = "Unknown";
        EmployeePersonalDetails employeePersonalDetails = employeePersonalDetailsRepository.findById(helpAndSupportTicket.getEmployeePersonalDetails().getId()).orElse(null);
        if (employeePersonalDetails != null) {
            String firstName = employeePersonalDetails.getEmployeeFirstName();
            String lastName = employeePersonalDetails.getEmployeeLastName();
            employeeName = firstName + " " + lastName;
            System.out.println("Employee name: " + employeeName);
        }

        String ticketSubject = helpAndSupportTicket.getSubject();
        String ticketDescription = helpAndSupportTicket.getDescription();

        // retrieve HR email from properties or config file (assuming `hrEmail` is stored in application.properties)
        String hrEmail = System.getenv("HR_EMAIL");

        // send email notification to HR after saving the ticket
        try {
            emailService.sendHelpAndSupportTicketConfirmationEmail(
                    hrEmail,
                    employeeName,
                    ticketSubject,
                    ticketDescription
            );
        } catch (MessagingException | UnsupportedEncodingException e) {
            log.error("Failed to send confirmation email to HR. Employee: {}. Ticket Subject: {}",
                    helpAndSupportTicket.getEmployeePersonalDetails() != null ? helpAndSupportTicket.getEmployeePersonalDetails().getEmail() : "Unknown",
                    ticketSubject, e);
        }
        return savedTicket;
    }

    @Override
    public List<HelpAndSupportTicket> getAllTickets() {
        return helpAndSupportTicketRepository.findAll().stream()
                .sorted(Comparator.comparing(HelpAndSupportTicket::getId))
                .collect(Collectors.toList());
    }

    @Override
    public Optional<HelpAndSupportTicket> getTicketById(Long id) {
        return helpAndSupportTicketRepository.findById(id);
    }

    @Override
    public HelpAndSupportTicket updateTicket(Long id, HelpAndSupportTicket ticket) {
        if (helpAndSupportTicketRepository.existsById(id)) {
            ticket.setId(id);
            return helpAndSupportTicketRepository.save(ticket);
        }
        return null;
    }

    @Override
    public boolean resolveTicket(Long id) {
        Optional<HelpAndSupportTicket> ticket = helpAndSupportTicketRepository.findById(id);
        if (ticket.isPresent()) {
            HelpAndSupportTicket resolvedTicket = ticket.get();
            resolvedTicket.setStatus("Resolved");

            helpAndSupportTicketRepository.saveAndFlush(resolvedTicket);

            // fetch employee details (first name and last name)
            EmployeePersonalDetails employeePersonalDetails = resolvedTicket.getEmployeePersonalDetails();
            String employeeEmail = employeePersonalDetails != null ? employeePersonalDetails.getEmail() : null;
            String employeeFirstName = employeePersonalDetails != null ? employeePersonalDetails.getEmployeeFirstName() : "Unknown";
            String employeeLastName = employeePersonalDetails != null ? employeePersonalDetails.getEmployeeLastName() : "Employee";

            String employeeFullName = employeeFirstName + " " + employeeLastName;

//            System.out.println("Employee Name Ticket Resolved: " + employeeFullName);
//            System.out.println("Employee Email: " + employeeEmail);

            if (employeeEmail != null) {
                try {
                    emailService.sendTicketResolvedNotification(employeeEmail, employeeFullName, resolvedTicket.getSubject(), resolvedTicket.getDescription());
                } catch (MessagingException | UnsupportedEncodingException e) {
                    log.error("Failed to send ticket resolved notification to employee. Ticket ID: {}. Error: ", id, e);
                }
            }
            return true;
        }
        return false;
    }

    @Override
    public List<HelpAndSupportTicket> getAllTicketsByEmployeeId(Long id) {
        return helpAndSupportTicketRepository.findByEmployeePersonalDetails_Id(id);
    }

}
