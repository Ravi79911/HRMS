package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.exception.ResourceNotFoundException;
import com.swati.Swati_HRMS.model.*;
import com.swati.Swati_HRMS.repository.*;

import com.swati.Swati_HRMS.service.EmployeePfCalculationService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.YearMonth;
import java.util.Optional;

@Service
public class EmployeePfCalculationServiceImpl implements EmployeePfCalculationService {

    @Autowired
    private EmployeePfCalculationRepo employeePfCalculationRepo;

    @Autowired
    private EmployeePersonalDetailsRepository employeePersonalDetailsRepository;

    @Autowired
    private EmployeePayrollRepository employeePayrollRepository;

    @Override
    public EmployeePfCalculation calculatePf(Long employeePersonalInfoId, String month, Integer year) {
        EmployeePersonalDetails employeePersonalDetails = employeePersonalDetailsRepository
                .findById(employeePersonalInfoId)
                .orElseThrow(() -> new EntityNotFoundException("Employee not found with ID: " + employeePersonalInfoId));

        Department department = employeePersonalDetails.getDepartment();
        if (department == null) {
            throw new EntityNotFoundException("Department not found for employee ID: " + employeePersonalInfoId);
        }

        EmployeePayroll employeePayroll = employeePayrollRepository
                .findByEmpCodeAndMonthAndYear(employeePersonalDetails.getEmployeeId(), month, year)
                .orElseThrow(() -> new EntityNotFoundException("Payroll not found for employee "
                        + employeePersonalDetails.getEmployeeId() + " for " + month + "/" + year));
        Optional<EmployeePfCalculation> existingPfCalculationOpt = employeePfCalculationRepo.findByEmpCodeAndMonthAndYear(employeePersonalDetails.getEmployeeId(), month, year);

        if (existingPfCalculationOpt.isPresent()) {
            throw new IllegalArgumentException("PF calculation already exists for employee "
                    + employeePersonalDetails.getEmployeeId() + " for " + month + "/" + year);
        }
        EmployeePfCalculation employeePfCalculation = new EmployeePfCalculation();
        employeePfCalculation.setEmpCode(employeePersonalDetails.getEmployeeId());
        employeePfCalculation.setEmpName(employeePersonalDetails.getEmployeeFirstName() + " " + employeePersonalDetails.getEmployeeLastName());
        employeePfCalculation.setDepartment(department.getDepartment());
        employeePfCalculation.setDesignation(employeePayroll.getDesignation());
        employeePfCalculation.setMonth(employeePayroll.getMonth());
        employeePfCalculation.setYear(employeePayroll.getYear());
        employeePfCalculation.setTotalWorkingDays(employeePayroll.getTotalWorkingDays());
        employeePfCalculation.setTotalPresentDays(employeePayroll.getTotalPresentDays());
        employeePfCalculation.setTotalAbsentDays(employeePayroll.getTotalAbsentDays());
        Integer monthDays =  getDaysInMonth(employeePayroll.getMonth(), employeePayroll.getYear());
        employeePfCalculation.setMonthDays(monthDays);
        employeePfCalculation.setBasicSalary(employeePayroll.getBasicSalary());

        double employeePf = round(employeePayroll.getBasicSalary() * 0.12);
        double employerEPf = round(employeePayroll.getBasicSalary() * 0.0367);
        double employerNps = round(employeePayroll.getBasicSalary() * 0.0833);
        double employerTotalContribution = employerEPf + employerNps;

        employeePfCalculation.setEmployeePfAmount(employeePf);
        employeePfCalculation.setEmployerEpfAmount(employerEPf);
        employeePfCalculation.setEmployerNpsAmount(employerNps);
        employeePfCalculation.setTotalEmployerContribution(employerTotalContribution);

        employeePfCalculation.setCreatedDate(LocalDateTime.now());
        employeePfCalculation.setSuspendedStatus(0L);
        employeePfCalculation.setIsApproved(false);

        return employeePfCalculationRepo.saveAndFlush(employeePfCalculation);
    }

    // Utility method for rounding
    private double round(double value) {
        return new BigDecimal(value).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    public static int getDaysInMonth(String monthName, int year) {
        // Convert the month name to uppercase and map it to the Month enum
        Month month = Month.valueOf(monthName.toUpperCase());
        // Use YearMonth to get number of days
        YearMonth yearMonth = YearMonth.of(year, month);
        return yearMonth.lengthOfMonth();
    }

    @Override
    public Optional<EmployeePfCalculation> getEmployeePfCalculationByEmpCode(String empCode, String month, Integer year) {
        return employeePfCalculationRepo.findByEmpCodeAndMonthAndYear(empCode, month, year);
    }

    @Override
    public Optional<EmployeePfCalculation> verifyPfCalculation(Long id) {
        Optional<EmployeePfCalculation> existingPfCalculationOpt = employeePfCalculationRepo.findById(id);
        if (!existingPfCalculationOpt.isPresent()) {
            throw new ResourceNotFoundException("PF Calculation not found for ID: " + id);
        }
        existingPfCalculationOpt.get().setIsApproved(true);
        EmployeePfCalculation savedPfCalculation = employeePfCalculationRepo.save(existingPfCalculationOpt.get());
        return Optional.of(savedPfCalculation);
    }

    @Override
    public String deletePfCalculation(Long id) {
        Optional<EmployeePfCalculation> existingPfCalculationOpt = employeePfCalculationRepo.findById(id);
        if (!existingPfCalculationOpt.isPresent()) {
            throw new ResourceNotFoundException("PF Calculation not found for ID: " + id);
        }
        employeePfCalculationRepo.delete(existingPfCalculationOpt.get());
        return "PF Calculation deleted successfully";
    }
}
