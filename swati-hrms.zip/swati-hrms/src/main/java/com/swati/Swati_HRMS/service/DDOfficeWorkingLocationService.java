package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.DDOfficeWorkingLocation;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface DDOfficeWorkingLocationService {

    DDOfficeWorkingLocation saveDDOfficeWorkingLocation(DDOfficeWorkingLocation ddOfficeWorkingLocation);
    List<DDOfficeWorkingLocation> getAllDDOfficeWorkingLocation();
    Optional<DDOfficeWorkingLocation> getDDOfficeWorkingLocationById(Long id);
    String deleteDDOfficeWorkingLocationById(Long id);
}
