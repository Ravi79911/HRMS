package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.EmployeePfCalculation;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public interface EmployeePfCalculationService {

    EmployeePfCalculation calculatePf(Long employeePersonalInfoId, String month, Integer year);
    Optional<EmployeePfCalculation> getEmployeePfCalculationByEmpCode(String empCode, String month, Integer year);
    Optional<EmployeePfCalculation> verifyPfCalculation(Long id);
    String deletePfCalculation(Long id);
}