package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.dto.EmployeePayrollResponse;
import com.swati.Swati_HRMS.exception.ResourceNotFoundException;
import com.swati.Swati_HRMS.model.*;
import com.swati.Swati_HRMS.repository.*;
import com.swati.Swati_HRMS.service.EmployeePayrollService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.lang.Math.round;

@Service
public class EmployeePayrollServiceImpl implements EmployeePayrollService {

    @Autowired
    private EmployeePayrollRepository payrollRepository;

    @Autowired
    private EmployeeAttendanceRepository attendanceRepository;

    @Autowired
    private EmployeePayrollSetupRepository payrollSetupRepository;

    @Autowired
    private PfMasterRepository pfMasterRepository;

    @Autowired
    private EsicMasterRepository esicMasterRepository;

    @Override
    public EmployeePayrollResponse generateAndSavePayroll(EmployeePayrollSetup payrollSetup, String month, Integer year) {
        // Validate input
        if (payrollSetup == null || payrollSetup.getEmployee() == null) {
            throw new IllegalArgumentException("Invalid payroll setup: Employee information is missing.");
        }

        String employeeId = payrollSetup.getEmployee().getEmployeeId();

        // Check for existing payroll
        Optional<EmployeePayroll> existingPayroll = payrollRepository.findByEmpCodeAndMonthAndYear(employeeId, month, year);

        if (existingPayroll.isPresent()) {
            throw new IllegalArgumentException("Payroll for the given employee, month, and year already exists.");
        }

        // Generate payroll response for new payroll
        EmployeePayrollResponse payrollResponse = generatePayrollResponse(payrollSetup, month, year);
        EmployeePayroll payrollEntity = convertToEntity(payrollResponse);

        try {
            payrollEntity.setCreatedDate(LocalDateTime.now());
            payrollEntity.setSuspendedStatus(0L);
            payrollEntity.setIsVerified(false);
            Long payrollId = payrollRepository.save(payrollEntity).getId();

            payrollResponse.setId(payrollId);

        } catch (DataIntegrityViolationException e) {
            throw new IllegalArgumentException("Payroll for the given employee, month, and year already exists.");
        }
        return payrollResponse;
    }

    /**
     * Converts EmployeePayrollResponse to EmployeePayroll entity for database storage
     */
    private EmployeePayroll convertToEntity(EmployeePayrollResponse response) {
        return EmployeePayroll.builder()
                .id(response.getId())
                .empCode(response.getEmpCode())
                .empName(response.getEmpName())
                .department(response.getDepartment())
                .designation(response.getDesignation())
                .month(response.getMonth())
                .year(response.getYear())
                .totalWorkingDays(response.getTotalWorkingDays())
                .totalPresentDays(response.getTotalPresentDays())
                .totalAbsentDays(response.getTotalAbsentDays())
                .basicSalary(response.getBasicSalary())
                .hra(response.getHra())
                .allowances(response.getAllowances())
                .grossSalary(response.getGrossSalary())
                .pf(response.getPf())
                .esic(response.getEsic())
                .totalDeductions(response.getTotalDeductions())
                .netSalary(response.getNetSalary())
                .isVerified(response.isVerified())
                .build();
    }

    /**
     * Converts EmployeePayroll entity to EmployeePayrollResponse
     */
    private EmployeePayrollResponse convertToResponse(EmployeePayroll entity) {
        EmployeePayrollResponse response = EmployeePayrollResponse.builder()
                .id(entity.getId())
                .empCode(entity.getEmpCode())
                .empName(entity.getEmpName())
                .department(entity.getDepartment())
                .designation(entity.getDesignation())
                .month(entity.getMonth())
                .year(entity.getYear())
                .totalWorkingDays(entity.getTotalWorkingDays())
                .totalPresentDays(entity.getTotalPresentDays())
                .totalAbsentDays(entity.getTotalAbsentDays())
                .basicSalary(entity.getBasicSalary())
                .hra(entity.getHra())
                .allowances(entity.getAllowances())
                .grossSalary(entity.getGrossSalary())
                .pf(entity.getPf())
                .esic(entity.getEsic())
                .totalDeductions(entity.getTotalDeductions())
                .netSalary(entity.getNetSalary())
                .isVerified(entity.getIsVerified())
                .build();
        return response;
    }

    private EmployeePayrollResponse generatePayrollResponse(EmployeePayrollSetup payrollSetup, String month, Integer year) {
        // Get employee details
        String empCode = payrollSetup.getEmployee().getEmployeeId();
        String empName = payrollSetup.getEmployee().getEmployeeFirstName() + " " + payrollSetup.getEmployee().getEmployeeLastName();
        String department = payrollSetup.getEmployee().getDepartment() != null ?
                payrollSetup.getEmployee().getDepartment().getDepartment() : "Not Assigned";

        // Get attendance for the specified month and year
        Optional<EmployeeAttendance> attendance = attendanceRepository.findByEmployeeIdAndMonthAndYear(
                Integer.parseInt(empCode), month.toLowerCase(), year);

        // Calculate attendance metrics
        int totalWorkingDays = 0;
        int totalPresentDays = 0;
        int totalAbsentDays = 0;

        if (attendance.isPresent()) {
            Map<Integer, String> dailyAttendance = attendance.get().getDailyAttendance();
            totalWorkingDays = dailyAttendance.size();
            totalPresentDays = (int) dailyAttendance.values().stream().filter(status -> status.equals("P")).count();
            totalAbsentDays = totalWorkingDays - totalPresentDays;
        }

        // Calculate salary components
        double basicSalary = payrollSetup.getBasicLists().stream()
                .filter(basic -> basic.getScaleName().equalsIgnoreCase("Basic"))
                .findFirst()
                .map(basic -> basic.getScaleValue())
                .orElse(0.0);

        double hra = payrollSetup.getBasicLists().stream()
                .filter(basic -> basic.getScaleName().equalsIgnoreCase("HRA"))
                .findFirst()
                .map(basic -> basic.getScaleValue())
                .orElse(0.0);

        // Calculate allowances
//        double totalAllowances = payrollSetup.getAllowanceLists().stream()
//                .mapToDouble(allowance -> allowance.getAllowanceValue())
//                .sum();
        double totalAllowances = payrollSetup.getAllowanceLists().stream()
                .mapToDouble(allowance -> Optional.ofNullable(allowance.getAllowanceValue()).orElse(0.0))
                .sum();

        // Get individual allowances for display
//        Map<String, Double> allowanceBreakdown = payrollSetup.getAllowanceLists().stream()
//                .collect(Collectors.toMap(
//                        allowance -> allowance.getAllowanceName(),
//                        allowance -> allowance.getAllowanceValue()
//                ));
        Map<String, Double> allowanceBreakdown = payrollSetup.getAllowanceLists().stream()
                .collect(Collectors.toMap(
                        allowance -> allowance.getAllowanceName(),
                        allowance -> allowance.getAllowanceValue() != null ? allowance.getAllowanceValue() : 0.0
                ));

        // Calculate gross salary
        double grossSalary = basicSalary + hra + totalAllowances;

        // Calculate deductions
        Map<String, Double> deductionBreakdown = payrollSetup.getDeductionLists().stream()
                .collect(Collectors.toMap(
                        deduction -> deduction.getDeductionName(),
                        deduction -> deduction.getDeductionValue()
                ));

// Get PF and ESIC values
        double pf = deductionBreakdown.getOrDefault("PF", 0.0);
//        double esic = deductionBreakdown.getOrDefault("ESIC", 0.0);

// Calculate total deductions, excluding PF
        double totalDeductions = payrollSetup.getDeductionLists().stream()
                .filter(deduction -> !deduction.getDeductionName().equals("PF"))  // Exclude PF from total
                .mapToDouble(deduction -> deduction.getDeductionValue())
                .sum();


//// Check if PF calculation type is percent and recalculate PF if necessary
//        String pfCalculationType = payrollSetup.getDeductionLists().stream()
//                .filter(deduction -> deduction.getDeductionName().equals("PF"))
//                .findFirst().map(DeductionList::getCalculationType).orElse("fixed"); // Assume this method gives PF calculation type as "fixed" or "percent"
//
//        double totalDeductionsWithPF = 0.0;
//
//        double esic=0.0;
//        if ("percent".equalsIgnoreCase(pfCalculationType)) {
//            pf = basicSalary * pf / 100; // Calculate PF as a percentage of basic salary
//
//             totalDeductionsWithPF = totalDeductions + pf;
//        }
//        else {
//             totalDeductionsWithPF = totalDeductions+pf;
//        }
//
//        if (grossSalary <= 21000) {
//            esic = round(grossSalary * 0.0075);
//        }else {
//             esic = 0.0;
//        }
//// Calculate net salary
//        double netSalary = grossSalary - totalDeductionsWithPF-esic;

        // Fetch PF and ESIC master values
        PfMaster pfMaster = pfMasterRepository.findTopBySuspendedStatusOrderByUpdatedDateDesc(0);
        EsicMaster esicMaster = esicMasterRepository.findTopBySuspendedStatusOrderByUpdatedDateDesc(0);

// Extract PF rates
        double pfEmployeeEpf = pfMaster.getEmployeeContributionEpf(); // Employee EPF
        double pfEmployeeEps = pfMaster.getPensionContributionEps();  // Employee EPS
        double pfEmployer = pfMaster.getEmployerContributionRate();   // Employer PF

// PF Calculations
        double pfEmployeeTotal = basicSalary * (pfEmployeeEpf + pfEmployeeEps) / 100;
        double pfEmployerContribution = basicSalary * pfEmployer / 100;

// Total deductions affecting net salary (only employee part)
        double totalDeductionsWithPF = totalDeductions + pfEmployeeTotal;

// ESIC Calculations
        double esic = 0.0;
        double esicEmployerContribution = 0.0;
        if (grossSalary <= 21000) {
            double esicEmployeeRate = esicMaster.getEmployeeContributionRate();
            double esicEmployerRate = esicMaster.getEmployerContributionRate();

            esic = round(grossSalary * esicEmployeeRate / 100);
            esicEmployerContribution = round(grossSalary * esicEmployerRate / 100);
        }

// Net Salary = Gross - Employee Deductions (Employer parts don't affect this)
        double netSalary = grossSalary - totalDeductionsWithPF - esic;

// Optionally compute total CTC (Cost to Company)
        double totalEmployerCost = grossSalary + pfEmployerContribution + esicEmployerContribution;


        // Build and return the response
        return EmployeePayrollResponse.builder()
                .empCode(empCode)
                .empName(empName)
                .department(department)
                .designation(attendance.map(EmployeeAttendance::getDesignation).orElse("Not Available"))
                .month(month)
                .year(year)
                .totalWorkingDays(totalWorkingDays)
                .totalPresentDays(totalPresentDays)
                .totalAbsentDays(totalAbsentDays)
                .basicSalary(basicSalary)
                .hra(hra)
                .allowances(allowanceBreakdown)
                .grossSalary(grossSalary)
                .pf(totalDeductionsWithPF)
                .esic(esic)
                .totalDeductions(totalDeductions)
                .netSalary(netSalary)
                .isVerified(false) // Default value, will be updated when saved
                .build();
    }

    @Override
    public List<EmployeePayrollResponse> getAllPayrolls() {
        List<EmployeePayroll> payrolls = payrollRepository.findAll();
        return payrolls.stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<EmployeePayrollResponse> getPayrollByEmpCodeAndPeriod(String empCode, String month, Integer year) {
        return payrollRepository.findByEmpCodeAndMonthAndYear(empCode, month, year)
                .map(this::convertToResponse);
    }

    @Override
    public List<EmployeePayrollResponse> getEmployeePayrollsByDepartment(String department, String month, Integer year) {
        List<EmployeePayroll> payrolls = payrollRepository.findByDepartmentAndMonthAndYear(department, month, year);
        return payrolls.stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<EmployeePayrollResponse> updatePayrollAndApprovedStatus(Long payrollId, EmployeePayroll updatedPayrollData) {
        // Validate input
        if (updatedPayrollData == null) {
            throw new IllegalArgumentException("Updated payroll data cannot be null.");
        }

        Optional<EmployeePayroll> existingPayrollOpt = payrollRepository.findById(payrollId);

        if (!existingPayrollOpt.isPresent()) {
            throw new ResourceNotFoundException("Payroll not found for employee ID: " + payrollId);
        }

        // Get existing record
        EmployeePayroll existingPayroll = existingPayrollOpt.get();

        // Update payroll details
        existingPayroll.setBasicSalary(updatedPayrollData.getBasicSalary());
        existingPayroll.setHra(updatedPayrollData.getHra());
        existingPayroll.setAllowances(updatedPayrollData.getAllowances());
        existingPayroll.setGrossSalary(updatedPayrollData.getGrossSalary());
        existingPayroll.setPf(updatedPayrollData.getPf());
        existingPayroll.setEsic(updatedPayrollData.getEsic());
        existingPayroll.setTotalDeductions(updatedPayrollData.getTotalDeductions());
        existingPayroll.setNetSalary(updatedPayrollData.getNetSalary());

        // Update attendance-related fields
        existingPayroll.setTotalWorkingDays(updatedPayrollData.getTotalWorkingDays());
        existingPayroll.setTotalPresentDays(updatedPayrollData.getTotalPresentDays());
        existingPayroll.setTotalAbsentDays(updatedPayrollData.getTotalAbsentDays());
        existingPayroll.setIsVerified(true);
        EmployeePayroll savedPayroll = payrollRepository.save(existingPayroll);
        EmployeePayrollResponse response = convertToResponse(savedPayroll);
        return Optional.of(response);
    }

    @Override
    public Optional<EmployeePayrollResponse> verifyPayroll(Long payrollId) {
        Optional<EmployeePayroll> existingPayrollOpt = payrollRepository.findById(payrollId);

        if (!existingPayrollOpt.isPresent()) {
            throw new ResourceNotFoundException("Payroll not found for employee ID: " + payrollId);
        }
        existingPayrollOpt.get().setIsVerified(true);
        EmployeePayroll savedPayroll = payrollRepository.save(existingPayrollOpt.get());
        EmployeePayrollResponse response = convertToResponse(savedPayroll);
        return Optional.of(response);

    }

    @Override
    public String deletePayroll(Long payrollId) {
        Optional<EmployeePayroll> existingPayrollOpt = payrollRepository.findById(payrollId);

        if (!existingPayrollOpt.isPresent()) {
            throw new ResourceNotFoundException("Payroll not found for employee ID: " + payrollId);
        }
        payrollRepository.deleteById(payrollId);
        return "Payroll deleted successfully";
    }


}
