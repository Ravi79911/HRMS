package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.EmployeeEsicCalculation;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public interface EmployeeEsicCalculationService {

    EmployeeEsicCalculation saveEmployeeEsicCalculation(Long EmployeePersonalInfoId, String month, Integer year);
    Optional<EmployeeEsicCalculation> getEmployeeEsicCalculationByEmpCode(String empCode, String month, Integer year);
    Optional<EmployeeEsicCalculation> verifyPfCalculation(Long id);
    String deleteEsicCalculation(Long id);
}
