package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "employee_pf_calculation")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmployeePfCalculation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "emp_code", nullable = false)
    private String empCode;

    @Column(name = "emp_name", nullable = false)
    private String empName;

    @Column(name = "department")
    private String department;

    @Column(name = "designation")
    private String designation;

    @Column(name = "month", nullable = false)
    private String month;

    @Column(name = "year", nullable = false)
    private Integer year;

    @Column(name = "total_working_days")
    private Integer totalWorkingDays;

    @Column(name = "total_present_days")
    private Integer totalPresentDays;

    @Column(name = "total_absent_days")
    private Integer totalAbsentDays;

    @Column(name = "basic_salary")
    private Double basicSalary;

    @Column(name = "employee_pf_amount")
    private Double employeePfAmount;

    @Column(name = "employer_epf_amount")
    private Double employerEpfAmount;

    @Column(name = "employer_nps_amount")
    private Double employerNpsAmount;

    @Column(name = "total_employer_contribution")
    private Double totalEmployerContribution;

    @Column(name = "month_days")
    private Integer monthDays;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Long suspendedStatus;

    @Column(name = "is_approved")
    private Boolean isApproved;
}
