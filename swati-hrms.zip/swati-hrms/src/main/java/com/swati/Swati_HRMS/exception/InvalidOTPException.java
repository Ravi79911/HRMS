package com.swati.Swati_HRMS.exception;

import lombok.Data;

@Data
public class InvalidOTPException extends RuntimeException {

    public InvalidOTPException(String message) {
        super(message);
    }

    public InvalidOTPException(String message, Throwable cause) {
        super(message, cause);
    }

}
