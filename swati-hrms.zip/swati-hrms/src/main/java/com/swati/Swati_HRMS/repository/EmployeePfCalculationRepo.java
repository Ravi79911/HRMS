package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.EmployeePayroll;
import com.swati.Swati_HRMS.model.EmployeePfCalculation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface EmployeePfCalculationRepo extends JpaRepository<EmployeePfCalculation, Long> {

    Optional<EmployeePfCalculation> findByEmpCodeAndMonthAndYear(String empCode, String month, Integer year);
}
