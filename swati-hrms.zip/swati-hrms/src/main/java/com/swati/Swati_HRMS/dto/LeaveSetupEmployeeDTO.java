package com.swati.Swati_HRMS.dto;

import lombok.Data;

import java.util.List;

@Data
public class LeaveSetupEmployeeDTO {

    private Long employeeId;
    private Long createdBy;
    private List<LeaveTypeMasterAssignment> leaveTypeMasterAssignments;

    @Data
    public static class LeaveTypeMasterAssignment {
        private Long leaveTypeMasterId;
        private Long assignedLeaves; // Getters and setters
    }
}
