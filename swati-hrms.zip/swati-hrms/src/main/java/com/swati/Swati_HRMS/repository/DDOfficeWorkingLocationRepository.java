package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.DDOfficeWorkingLocation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface DDOfficeWorkingLocationRepository extends JpaRepository<DDOfficeWorkingLocation, Long> {

    List<DDOfficeWorkingLocation> findBySuspendedStatus(Integer suspendedStatus);
}
