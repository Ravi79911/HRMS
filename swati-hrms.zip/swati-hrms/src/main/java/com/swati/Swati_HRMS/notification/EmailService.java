package com.swati.Swati_HRMS.notification;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;

@Service
@Slf4j
public class EmailService {

    @Autowired
    JavaMailSender javaMailSender;

    @Value("${hr.email}")
    private String hrEmail;

    /**
     * Sends an HTML email with a custom sender name.
     *
     * @param toEmail Recipient email address
     * @param subject Subject of the email
     * @param message HTML content for the email body
     */

//    public void sendEmail(String toEmail, String subject, String message) {
//        SimpleMailMessage mailMessage = new SimpleMailMessage();
//        mailMessage.setTo(toEmail);
//        mailMessage.setSubject(subject);
//        mailMessage.setText(message);
//        javaMailSender.send(mailMessage);
//    }
    public void sendEmail(String toEmail, String subject, String message) {
        try {
            MimeMessage mimeMessage = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

            helper.setTo(toEmail);
            helper.setSubject(subject);
            helper.setText(message, true);
            helper.setFrom("swatitest1ind1990@gmail.com", "Swati Industries");

            javaMailSender.send(mimeMessage);

            log.info("Email sent successfully to {}", toEmail);

        } catch (Exception e) {
            log.error("Failed to send email to {}. Error: {}", toEmail, e.getMessage(), e);
        }
    }

    // method to send a notification on email after user registration (ADMIN PORTAL)
    @Async
    public void sendRegistrationConfirmationEmailBeforeOtpVerification(String email, String password, String employeeId, String role, String employeeName) throws MessagingException, UnsupportedEncodingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
        helper.setFrom("swatitest1ind1990@gmail.com", "Swati Industries");
        helper.setTo(email);
        helper.setSubject("Your registration is successful - HRMS");

        helper.setText("""
                    <div style="font-family: Arial, sans-serif; background-color: #f4f4f9; padding: 30px; border-radius: 10px; max-width: 600px; margin: auto;">
                        <div style="text-align: center; margin-bottom: 20px;">
                            <img src="https://swatiind.com/wp-content/uploads/2023/07/Swati-Enterprises-Final.png" alt="Swati Enterprises" style="max-width: 150px; height: auto;"/>
                        </div>
                        <div style="background-color: #ffffff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                            <h2 style="color: #333333;">Dear %s,</h2>
                            <p style="font-size: 16px; color: #555555;">Welcome to Swati Industries! Your registration for HRMS is successful.</p>
                            <p style="font-size: 16px; color: #555555;">Your Employee ID: <strong>%s</strong></p>
                            <p style="font-size: 16px; color: #555555;">Role: <strong>%s</strong></p>
                            <p style="font-size: 16px; color: #555555;">Username: <strong>%s</strong></p>
                            <p style="font-size: 16px; color: #555555;">Your account password: <strong>%s</strong></p>
                            <p style="font-size: 16px; color: #555555;">Please verify your Email ID with OTP to explore our services.</p>
                            <p style="font-size: 16px; color: #555555;">If you need any assistance, feel free to reach out.</p>
                        </div>
                        <div style="text-align: center; margin-top: 30px;">
                            <p style="font-size: 14px; color: #888888;">Best regards,</p>
                            <p style="font-size: 16px; color: #333333;">Swati Industries</p>
                            <p style="font-size: 14px; color: #888888;">HR Department</p>
                            <a href="https://www.swatiind.com" target="_blank" style="color: #007bff; text-decoration: none; font-size: 16px;">Visit our website</a>
                        </div>
                    </div>
                """.formatted(employeeName, employeeId, role, email, password), true);

        javaMailSender.send(mimeMessage);
    }

    // method to send a notification on email after user registration after successful otp verification
    public void sendConfirmationEmailAfterOTPVerification(String employeeName, String email) throws MessagingException, UnsupportedEncodingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
        helper.setFrom("swatitest1ind1990@gmail.com", "Swati Industries");
        helper.setTo(email);
        helper.setSubject("Welcome to Swati Industries");

        helper.setText("""
                    <div style="font-family: Arial, sans-serif; background-color: #f4f4f9; padding: 30px; border-radius: 10px; max-width: 600px; margin: auto;">
                        <div style="text-align: center; margin-bottom: 20px;">
                            <img src="https://swatiind.com/wp-content/uploads/2023/07/Swati-Enterprises-Final.png" alt="Swati Enterprises" style="max-width: 150px; height: auto;"/>
                        </div>
                        <div style="background-color: #ffffff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                            <h2 style="color: #333333;">Dear %s,</h2>
                            <p style="font-size: 16px; color: #555555;">Welcome to the Swati Industries! Your registration was successful for HRMS.</p>
                            <p style="font-size: 16px; color: #555555;">We are glad to have you as part of the community. If you need any assistance, please feel free to reach out.</p>
                        </div>
                        <div style="text-align: center; margin-top: 30px;">
                            <p style="font-size: 14px; color: #888888;">Best regards,</p>
                            <p style="font-size: 16px; color: #333333;">Swati Industries</p>
                            <p style="font-size: 14px; color: #888888;">HR Department</p>
                            <a href="https://www.swatiind.com" target="_blank" style="color: #007bff; text-decoration: none; font-size: 16px;">Visit our website</a>
                        </div>
                    </div>
                """.formatted(employeeName), true);

        javaMailSender.send(mimeMessage);
    }

    // method to send help & support ticket creation email
    public void sendHelpAndSupportTicketConfirmationEmail(String email, String employeeName, String ticketSubject, String ticketDescription) throws MessagingException, UnsupportedEncodingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
        helper.setFrom("swatitest1ind1990@gmail.com", "Swati Industries");
        helper.setTo(hrEmail);
        helper.setSubject("New Help & Support Ticket Created - HRMS");
        helper.setText("""
                <div style="font-family: Arial, sans-serif; background-color: #f4f4f9; padding: 30px; border-radius: 10px; max-width: 600px; margin: auto;">
                    <div style="text-align: center; margin-bottom: 20px;">
                        <img src="https://swatiind.com/wp-content/uploads/2023/07/Swati-Enterprises-Final.png" alt="Swati Enterprises" style="max-width: 150px; height: auto;"/>
                    </div>
                    <div style="background-color: #ffffff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                        <h2 style="color: #333333;">Dear HR Team,</h2>
                        <p style="font-size: 16px; color: #555555;">A new help and support ticket has been created by <strong>%s</strong>.</p>
                        <p style="font-size: 16px; color: #555555;">Subject: <strong>%s</strong></p>
                        <p style="font-size: 16px; color: #555555;">Description: <strong>%s</strong></p>
                        <p style="font-size: 16px; color: #555555;">Please review the ticket and take the necessary actions as per the guidelines. If further information is required, feel free to contact the employee.</p>
                    </div>
                    <div style="text-align: center; margin-top: 30px;">
                        <p style="font-size: 14px; color: #888888;">Best regards,</p>
                        <p style="font-size: 16px; color: #333333;">Swati Industries</p>
                        <p style="font-size: 14px; color: #888888;">HR Department</p>
                        <a href="https://www.swatiind.com" target="_blank" style="color: #007bff; text-decoration: none; font-size: 16px;">Visit our website</a>
                    </div>
                </div>
                """.formatted(employeeName, ticketSubject, ticketDescription), true);

        javaMailSender.send(mimeMessage);
    }

    // method to send help & support ticket resolution email
    public void sendTicketResolvedNotification(String employeeEmail, String employeeName, String ticketSubject, String ticketDescription) throws MessagingException, UnsupportedEncodingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
        helper.setFrom("swatitest1ind1990@gmail.com", "Swati Industries");
        helper.setTo(employeeEmail);
        helper.setSubject("Your Help & Support Ticket has been Resolved - HRMS");

        helper.setText("""
                <div style="font-family: Arial, sans-serif; background-color: #f4f4f9; padding: 30px; border-radius: 10px; max-width: 600px; margin: auto;">
                    <div style="text-align: center; margin-bottom: 20px;">
                        <img src="https://swatiind.com/wp-content/uploads/2023/07/Swati-Enterprises-Final.png" alt="Swati Enterprises" style="max-width: 150px; height: auto;"/>
                    </div>
                    <div style="background-color: #ffffff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                        <h2 style="color: #333333;">Dear %s,</h2>
                        <p style="font-size: 16px; color: #555555;">We are pleased to inform you that your help and support ticket has been resolved. Below are the details:</p>
                        <p style="font-size: 16px; color: #555555;">Ticket Subject: <strong>%s</strong></p>
                        <p style="font-size: 16px; color: #555555;">Ticket Description: <strong>%s</strong></p>
                        <p style="font-size: 16px; color: #555555;">Please feel free to reach out if you have any further questions or issues. Thank you for using our help and support services.</p>
                    </div>
                    <div style="text-align: center; margin-top: 30px;">
                        <p style="font-size: 14px; color: #888888;">Best regards,</p>
                        <p style="font-size: 16px; color: #333333;">Swati Industries</p>
                        <p style="font-size: 14px; color: #888888;">HR Department</p>
                        <a href="https://www.swatiind.com" target="_blank" style="color: #007bff; text-decoration: none; font-size: 16px;">Visit our website</a>
                    </div>
                </div>
                """.formatted(employeeName, ticketSubject, ticketDescription), true);

        javaMailSender.send(mimeMessage);
    }

    // method to send profile update confirmation email
    public void sendProfileUpdateConfirmationEmail(String email) throws MessagingException, UnsupportedEncodingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
        helper.setFrom("swatitest1ind1990@gmail.com", "Swati Industries");
        helper.setTo(email);
        helper.setSubject("Your Profile Details Updated Successfully - vvcmc");

        helper.setText("""
                    <div style="font-family: Arial, sans-serif; background-color: #f4f4f9; padding: 30px; border-radius: 10px; max-width: 600px; margin: auto;">
                        <div style="text-align: center; margin-bottom: 20px;">
                            <img src="https://swatiind.com/wp-content/uploads/2023/07/Swati-Enterprises-Final.png" alt="Swati Enterprises" style="max-width: 150px; height: auto;"/>
                        </div>
                        <div style="background-color: #ffffff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                            <h2 style="color: #333333;">Dear User :- %s,</h2>
                            <p style="font-size: 16px; color: #555555;">Your profile details have been successfully updated in the Vasai Virar City Municipal Corporation.</p>
                            <p style="font-size: 16px; color: #555555;">Thank you for keeping your information up to date. If you have any further questions or need assistance, feel free to reach out to us.</p>
                        </div>
                        <div style="text-align: center; margin-top: 30px;">
                            <p style="font-size: 14px; color: #888888;">Best regards,</p>
                            <p style="font-size: 16px; color: #333333;">Swati Industries</p>
                            <a href="https://www.swatiind.com" target="_blank" style="color: #007bff; text-decoration: none; font-size: 16px;">Visit our website</a>
                        </div>
                    </div>
                """.formatted(email), true);

        javaMailSender.send(mimeMessage);
    }

    // method to send retrieve username email
    public void sendUsernameToUserEmail(String userEmail, String username, String employeeName) throws MessagingException, UnsupportedEncodingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
        helper.setFrom("swatitest1ind1990@gmail.com", "Swati Industries");
        helper.setTo(userEmail);
        helper.setSubject("Your username for HRMS has been retrieved");

        helper.setText("""
                    <div style="font-family: Arial, sans-serif; background-color: #f4f4f9; padding: 30px; border-radius: 10px; max-width: 600px; margin: auto;">
                        <div style="text-align: center; margin-bottom: 20px;">
                            <img src="https://swatiind.com/wp-content/uploads/2023/07/Swati-Enterprises-Final.png" alt="Swati Enterprises" style="max-width: 150px; height: auto;"/>
                        </div>
                        <div style="background-color: #ffffff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                            <h2 style="color: #333333;">Dear %s,</h2>
                            <p style="font-size: 16px; color: #555555;">We are here to help! Your username for HRMS has been successfully retrieved.</p>
                            <p style="font-size: 16px; color: #555555;">Your Email Id is: <strong>%s</strong></p>
                            <p style="font-size: 16px; color: #555555;">Your Username is: <strong>%s</strong></p>
                            <p style="font-size: 16px; color: #555555;">If you didn't request this, please contact our support team immediately.</p>
                            <p style="font-size: 16px; color: #555555;">Thank you for using HRMS services!</p>
                        </div>
                        <div style="text-align: center; margin-top: 30px;">
                            <p style="font-size: 14px; color: #888888;">Best regards,</p>
                            <p style="font-size: 16px; color: #333333;">Swati Industries</p>
                            <p style="font-size: 14px; color: #888888;">HR Department</p>
                            <a href="https://www.swatiind.com" target="_blank" style="color: #007bff; text-decoration: none; font-size: 16px;">Visit our website</a>
                        </div>
                    </div>
                """.formatted(employeeName, userEmail, username), true);

        javaMailSender.send(mimeMessage);
    }

    // method to send change email/mobile with username
    public void sendEmailOrMobileChangeConfirmationEmail(String userEmail, String username, String contactType) throws MessagingException, UnsupportedEncodingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
        helper.setFrom("swatitest1ind1990@gmail.com", "Swati Industries");
        helper.setTo(userEmail);
        String subject = "Your " + contactType + " has been successfully updated - vvcmc";
        helper.setSubject(subject);

        helper.setText("""
                    <div style="font-family: Arial, sans-serif; background-color: #f4f4f9; padding: 30px; border-radius: 10px; max-width: 600px; margin: auto;">
                        <div style="text-align: center; margin-bottom: 20px;">
                            <img src="https://swatiind.com/wp-content/uploads/2023/07/Swati-Enterprises-Final.png" alt="Swati Enterprises" style="max-width: 150px; height: auto;"/>
                        </div>
                        <div style="background-color: #ffffff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                            <h2 style="color: #333333;">Dear User :- %s,</h2>
                            <p style="font-size: 16px; color: #555555;">We are here to assist you! Your <strong>%s</strong> has been successfully updated with Vasai Virar City Municipal Corporation.</p>
                            <p style="font-size: 16px; color: #555555;">Your username is: <strong>%s</strong></p>
                            <p style="font-size: 16px; color: #555555;">If you didn’t request this change or if there was an error, please contact our support team immediately.</p>
                            <p style="font-size: 16px; color: #555555;">Thank you for using VVCMC services!</p>
                        </div>
                        <div style="text-align: center; margin-top: 30px;">
                            <p style="font-size: 14px; color: #888888;">Best regards,</p>
                            <p style="font-size: 16px; color: #333333;">Swati Industries</p>
                            <a href="https://www.swatiind.com" target="_blank" style="color: #007bff; text-decoration: none; font-size: 16px;">Visit our website</a>
                        </div>
                    </div>
                """.formatted(username, contactType, username), true);

        javaMailSender.send(mimeMessage);
    }

    // method to send reset password email
    public void sendResetPasswordEmail(String email, String token, String employeeName) throws MessagingException, UnsupportedEncodingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
        helper.setTo(email);
        helper.setFrom("swatitest1ind1990@gmail.com", "Swati Industries");
        helper.setSubject("Reset Your Password - HRMS");

        helper.setText("""
                    <div style="font-family: Arial, sans-serif; background-color: #f4f4f9; padding: 30px; border-radius: 10px; max-width: 600px; margin: auto;">
                        <div style="text-align: center; margin-bottom: 20px;">
                            <img src="https://swatiind.com/wp-content/uploads/2023/07/Swati-Enterprises-Final.png" alt="Swati Enterprises" style="max-width: 150px; height: auto;"/>
                        </div>
                        <div style="background-color: #ffffff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                            <h2 style="color: #333333;">Dear %s,</h2>
                            <p style="font-size: 16px; color: #555555;">Username: <strong>%s</strong></p>
                            <p style="font-size: 16px; color: #555555;">We received a request to reset your password for Swati Industries HRMS portal.</p>
                            <p style="font-size: 16px; color: #555555;">Please click the link below to reset your password:</p>
                            <p style="font-size: 16px; color: #555555;">
                                <a href="http://192.168.29.245:8087/hrms/auth/resetPassword?token=%s" target="_blank" style="background-color: #007bff; color: #ffffff; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Reset Password</a>
                            </p>
                            <p style="font-size: 16px; color: #555555;">This link will expire in 5 minutes for security reasons. If you did not request a password reset, you can safely ignore this email.</p>
                        </div>
                        <div style="text-align: center; margin-top: 30px;">
                            <p style="font-size: 14px; color: #888888;">Best regards,</p>
                            <p style="font-size: 16px; color: #333333;">Swati Industries</p>
                            <p style="font-size: 14px; color: #888888;">HR Department</p>
                            <a href="https://www.swatiind.com" target="_blank" style="color: #007bff; text-decoration: none; font-size: 16px;">Visit our website</a>
                        </div>
                    </div>
                """.formatted(employeeName, email, token), true);

        javaMailSender.send(mimeMessage);
    }

    // method to send password change success email
    public void sendChangePasswordSuccessEmail(String employeeName, String email) throws MessagingException, UnsupportedEncodingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
        helper.setTo(email);
        helper.setFrom("swatitest1ind1990@gmail.com", "Swati Industries");
        helper.setSubject("Password Change Successful - HRMS");

        helper.setText("""
                    <div style="font-family: Arial, sans-serif; background-color: #f4f4f9; padding: 30px; border-radius: 10px; max-width: 600px; margin: auto;">
                        <div style="text-align: center; margin-bottom: 20px;">
                            <img src="https://swatiind.com/wp-content/uploads/2023/07/Swati-Enterprises-Final.png" alt="Swati Enterprises" style="max-width: 150px; height: auto;"/>
                        </div>
                        <div style="background-color: #ffffff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                            <h2 style="color: #333333;">Dear %s,</h2>
                            <p style="font-size: 16px; color: #555555;">We are happy to inform you that your password has been successfully changed for Swati Industries - HRMS Portal.</p>
                            <p style="font-size: 16px; color: #555555;">If you didn't initiate this request, please contact our support team immediately to secure your account.</p>
                            <p style="font-size: 16px; color: #555555;">If this was you, no further action is needed. You can now use your new password to log in.</p>
                        </div>
                        <div style="text-align: center; margin-top: 30px;">
                            <p style="font-size: 14px; color: #888888;">Best regards,</p>
                            <p style="font-size: 16px; color: #333333;">Swati Industries</p>
                            <p style="font-size: 14px; color: #888888;">HR Department</p>
                            <a href="https://www.swatiind.com" target="_blank" style="color: #007bff; text-decoration: none; font-size: 16px;">Visit our website</a>
                        </div>
                    </div>
                """.formatted(employeeName), true);

        javaMailSender.send(mimeMessage);
    }

    // method to send reset password successfully email
    public void sendResetPasswordSuccessEmail(String employeeName, String email) throws MessagingException, UnsupportedEncodingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
        helper.setFrom("swatitest1ind1990@gmail.com", "Swati Industries");
        helper.setTo(email);
        helper.setSubject("Password Reset Successful - HRMS");

        helper.setText("""
                    <div style="font-family: Arial, sans-serif; background-color: #f4f4f9; padding: 30px; border-radius: 10px; max-width: 600px; margin: auto;">
                        <div style="text-align: center; margin-bottom: 20px;">
                            <img src="https://swatiind.com/wp-content/uploads/2023/07/Swati-Enterprises-Final.png" alt="Swati Enterprises" style="max-width: 150px; height: auto;"/>
                        </div>
                        <div style="background-color: #ffffff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                            <h2 style="color: #333333;">Dear %s,</h2>
                            <p style="font-size: 16px; color: #555555;">Your password for Swati Industries HRMS portal has been successfully reset.</p>
                            <p style="font-size: 16px; color: #555555;">If you did not request this change, please contact support immediately.</p>
                        </div>
                        <div style="text-align: center; margin-top: 30px;">
                            <p style="font-size: 14px; color: #888888;">Best regards,</p>
                            <p style="font-size: 16px; color: #333333;">Swati Industries</p>
                            <p style="font-size: 14px; color: #888888;">HR Department</p>
                            <a href="https://www.swatiind.com" target="_blank" style="color: #007bff; text-decoration: none; font-size: 16px;">Visit our website</a>
                        </div>
                    </div>
                """.formatted(employeeName), true);

        javaMailSender.send(mimeMessage);
    }

    // method to send complaint register notification in grievance
    public void sendComplaintRegisterEmailNotification(String email, String complaintNo) throws MessagingException, UnsupportedEncodingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
        helper.setFrom("swatitest1ind1990@gmail.com", "Swati Industries");
        helper.setTo(email);
        helper.setSubject("Complaint Registered - VVCMC");

        helper.setText("""
                    <div style="font-family: Arial, sans-serif; background-color: #f4f4f9; padding: 30px; border-radius: 10px; max-width: 600px; margin: auto;">
                        <div style="text-align: center; margin-bottom: 20px;">
                            <img src="https://swatiind.com/wp-content/uploads/2023/07/Swati-Enterprises-Final.png" alt="Swati Enterprises" style="max-width: 150px; height: auto;"/>
                        </div>
                        <div style="background-color: #ffffff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                            <h2 style="color: #333333;">Dear User: %s</h2>
                            <p style="font-size: 16px; color: #555555;">Your complaint has been successfully submitted. Your complaint number is <strong>%s</strong>.</p>
                            <p style="font-size: 16px; color: #555555;">We will review your complaint and take appropriate action. You will be notified of any updates.</p>
                            <p style="font-size: 16px; color: #555555;">If you did not submit this complaint, please contact support immediately.</p>
                        </div>
                        <div style="text-align: center; margin-top: 30px;">
                            <p style="font-size: 14px; color: #888888;">Best regards,</p>
                            <p style="font-size: 16px; color: #333333;">Swati Industries</p>
                            <a href="https://www.swatiind.com" target="_blank" style="color: #007bff; text-decoration: none; font-size: 16px;">Visit our website</a>
                        </div>
                    </div>
                """.formatted(email, complaintNo), true);

        javaMailSender.send(mimeMessage);
    }

}
