package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
@Table(name = "employee_payroll_setup")
public class EmployeePayrollSetup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotNull(message = "created_by cannot be null")
    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "emp_id", referencedColumnName = "id", nullable = false)
    private EmployeePersonalDetails employee;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "employee_payroll_setup_basic",
            joinColumns = @JoinColumn(name = "payroll_setup_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "basic_list_id", referencedColumnName = "id")
    )
    private List<BasicList> basicLists;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "employee_payroll_setup_allowance",
            joinColumns = @JoinColumn(name = "payroll_setup_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "allowance_list_id", referencedColumnName = "id")
    )
    private List<AllowanceList> allowanceLists;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "employee_payroll_setup_deduction",
            joinColumns = @JoinColumn(name = "payroll_setup_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "deduction_list_id", referencedColumnName = "id")
    )
    private List<DeductionList> deductionLists;

}
