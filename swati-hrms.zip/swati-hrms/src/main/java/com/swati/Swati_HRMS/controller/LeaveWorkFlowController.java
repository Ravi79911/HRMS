package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.model.LeaveWorkFlow;
import com.swati.Swati_HRMS.service.LeaveWorkFlowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/leaveworkflow")
public class LeaveWorkFlowController {

    @Autowired
    private LeaveWorkFlowService leaveWorkFlowService;

    @PostMapping("/saveLeaveWorkFlowMasterForProjectManager")
    public ResponseEntity<?> saveLeaveWorkFlowMaster(@RequestBody LeaveWorkFlow leaveWorkFlow){
        ApiResponse response = ApiResponse.success("Leave work flow saved successfully", leaveWorkFlowService.handleLeaveWorkFlowForProjectManager(leaveWorkFlow));
        return ResponseEntity.ok(response);
     }


    @PostMapping("/saveLeaveWorkFlowMasterForHR")
    public ResponseEntity<?> saveLeaveWorkFlowMasterForHR(@RequestBody LeaveWorkFlow leaveWorkFlow){
        ApiResponse response = ApiResponse.success("Leave work flow saved successfully", leaveWorkFlowService.handleLeaveWorkFlowForHR(leaveWorkFlow));
        return ResponseEntity.ok(response);
    }


    @GetMapping("/getAllLeaveWorkFlowMaster")
    public ResponseEntity<?> getAllLeaveWorkFlowMaster(){
        ApiResponse response = ApiResponse.success("Leave work flow fetched successfully", leaveWorkFlowService.getAllLeaveWorkFlow());
        return ResponseEntity.ok(response);
    }
}
