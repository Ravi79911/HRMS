package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.dto.EmployeeDocumentsDTO;
import com.swati.Swati_HRMS.model.EmployeeDocument;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public interface EmployeeDocumentService {

    EmployeeDocument createEmployeeDocument(EmployeeDocument employeeDocument, Long documentListId, MultipartFile documentFile);

    List<String> getDocumentUrlsByEmployeePersonalDetailsId(Long employeePersonalDetailsId);

    List<EmployeeDocumentsDTO> getEmployeeKeySkillByEmployeePersonalDetailsId(Long id);

}
