package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.LeaveApplication;
import com.swati.Swati_HRMS.repository.LeaveApplicationRepository;
import com.swati.Swati_HRMS.service.LeaveApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class LeaveApplicationServiceImpl implements LeaveApplicationService {

    @Autowired
    private LeaveApplicationRepository leaveApplicationRepository;

    @Override
    public LeaveApplication saveLeaveApplication(LeaveApplication leaveApplication) {
        leaveApplication.setStatus("In Process");
        leaveApplication.setCreatedDate(LocalDateTime.now());
        leaveApplication.setSuspendedStatus(0L);
        return leaveApplicationRepository.save(leaveApplication);
    }

    @Override
    public Optional<LeaveApplication> getLeaveApplicationById(Long id) {
       Optional<LeaveApplication> leaveApplication = leaveApplicationRepository.findById(id);
        if (leaveApplication.isPresent()) {
            return leaveApplication;
        }
        throw new RuntimeException("LeaveApplication not found : " + id);
    }

    @Override
    public List<LeaveApplication> getAllLeaveApplication() {
        return leaveApplicationRepository.findAll();
    }

    @Override
    public Optional<LeaveApplication> changeStatusOfLeaveApplicationById(Long id) {
        Optional<LeaveApplication> leaveApplication = leaveApplicationRepository.findById(id);
        if (leaveApplication.isPresent()) {
            leaveApplication.get().setSuspendedStatus(1L);
            leaveApplicationRepository.save(leaveApplication.get());
            return leaveApplication;
        }
        throw new RuntimeException("LeaveApplication not found : " + id);
    }

    @Override
    public List<LeaveApplication> getLeaveApplicationsByEmployeeId(Long employeeId) {
        return leaveApplicationRepository.findByLeaveSetupEmpEmployeeId(employeeId);
    }
}
