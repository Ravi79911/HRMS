package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.model.BankDetails;
import com.swati.Swati_HRMS.service.BankDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/employee/bankdetails")
public class BankDetailsController {

    @Autowired
    private BankDetailsService bankDetailsService;


    @PostMapping("/saveBankDetails")
    public ResponseEntity<?> saveBankDetails(@RequestBody BankDetails bankDetails){
        ApiResponse response= ApiResponse.success("Bank Details saved successfully", bankDetailsService.saveBankDetails(bankDetails));
        return ResponseEntity.ok(response);
    }

    @PutMapping("/updateBankDetails/{id}")
    public ResponseEntity<?> updateBankDetails(@PathVariable Long id, @RequestBody BankDetails bankDetails){
        ApiResponse response= ApiResponse.success("Bank Details updated successfully", bankDetailsService.updateBankDetails(id, bankDetails));
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getBankDetailsById/{id}")
    public ResponseEntity<?> getBankDetailsById(@PathVariable Long id){
        ApiResponse response= ApiResponse.success("Bank Details fetched successfully", bankDetailsService.getBankDetails(id));
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getAllBankDetails")
    public ResponseEntity<?> getAllBankDetails(){
        ApiResponse response= ApiResponse.success("Bank Details fetched successfully", bankDetailsService.getAllBankDetails());
        return ResponseEntity.ok(response);
    }

    @PatchMapping("/changeStatusOfBankDetailsById/{id}")
    public ResponseEntity<?> changeStatusOfBankDetailsById(@PathVariable Long id){
        ApiResponse response= ApiResponse.success("Bank Details status changed successfully", bankDetailsService.changeSuspendedStatus(id));
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/deleteBankDetailsById/{id}")
    public ResponseEntity<?> deleteBankDetailsById(@PathVariable Long id){
        ApiResponse response= ApiResponse.success("Bank Details deleted successfully", bankDetailsService.deleteBankDetails(id));
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getBankDetailsByEmployeePersonalId/{id}")
    public ResponseEntity<?> getBankDetailsByEmployeeId(@PathVariable Long id){
        ApiResponse response= ApiResponse.success("Bank Details fetched successfully", bankDetailsService.getBankDetailsByEmpId(id));
        return ResponseEntity.ok(response);
    }
}
