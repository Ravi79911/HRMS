package com.swati.Swati_HRMS.controller;


import com.swati.Swati_HRMS.dto.LeaveSetupEmployeeDTO;
import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.model.LeaveSetupEmployee;
import com.swati.Swati_HRMS.service.LeaveSetupEmployeeService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/leavesetupemployee")
public class LeaveSetupEmployeeController {

    @Autowired
    private LeaveSetupEmployeeService leaveSetupEmployeeService;

    @PostMapping("/saveLeaveSetupEmployee")
    public ResponseEntity<ApiResponse> saveLeaveSetupEmployee(@RequestBody LeaveSetupEmployeeDTO leaveSetupEmployeeRequest) {
        // Assuming LeaveSetupEmployeeRequest is a DTO containing employeeId, createdBy, and a list of leaveTypeMasterAssignments
        List<LeaveSetupEmployee> leaveSetupEmployees = leaveSetupEmployeeService
                .createLeaveSetupEmployeeMaster(leaveSetupEmployeeRequest.getLeaveTypeMasterAssignments(),
                        leaveSetupEmployeeRequest.getEmployeeId(),
                        leaveSetupEmployeeRequest.getCreatedBy());

        ApiResponse response = ApiResponse.success("Leave setup employees created successfully", leaveSetupEmployees);
        return ResponseEntity.ok(response);
    }



    @GetMapping("/getAllLeaveSetupEmployee")
    public ResponseEntity<?> getAllLeaveSetupEmployee() {
        ApiResponse response = ApiResponse.success("Leave setup employee fetched successfully", leaveSetupEmployeeService.getAllLeaveSetupMaster());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getLeaveSetupEmployeeById/{id}")
    public ResponseEntity<?> getLeaveSetupEmployeeById(@PathVariable Long id) {
        Optional<LeaveSetupEmployee> leaveSetupEmployee = leaveSetupEmployeeService.getLeaveSetupMasterById(id);
        ApiResponse response = ApiResponse.success("Leave setup employee fetched successfully", leaveSetupEmployee);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/updateLeaveSetupEmployee")
    public ResponseEntity<ApiResponse> updateLeaveSetupEmployee(@RequestBody LeaveSetupEmployeeDTO leaveSetupEmployeeRequest) {
        // Assuming LeaveSetupEmployeeRequest is a DTO containing employeeId, updatedBy, and a list of leaveTypeMasterAssignments
        List<LeaveSetupEmployee> leaveSetupEmployees = leaveSetupEmployeeService
                .updateLeaveSetupEmployeeMaster(leaveSetupEmployeeRequest.getLeaveTypeMasterAssignments(),
                        leaveSetupEmployeeRequest.getEmployeeId(),
                        leaveSetupEmployeeRequest.getCreatedBy());  // Updated by is typically the same as createdBy for this operation

        ApiResponse response = ApiResponse.success("Leave setup employees updated successfully", leaveSetupEmployees);
        return ResponseEntity.ok(response);
    }


    @PatchMapping("/changeStatusOfLeaveSetupEmployeeById/{id}")
    public ResponseEntity<?> changeStatusOfLeaveSetupEmployeeById(@PathVariable Long id) {
        ApiResponse response = ApiResponse.success("Leave setup employee status changed successfully", leaveSetupEmployeeService.changeStatusOfLeaveSetupMasterById(id));
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/deleteLeaveSetupEmployeeById/{id}")
    public ResponseEntity<?> deleteLeaveSetupEmployeeById(@PathVariable Long id) {
        ApiResponse response = ApiResponse.success("Leave setup employee deleted successfully", leaveSetupEmployeeService.deleteLeaveSetupMasterById(id));
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getLeaveSetupEmployeeByEmployeeId/{employeeId}")
    public ResponseEntity<?> getLeaveSetupEmployeeByEmployeeId(@PathVariable Long employeeId) {
        ApiResponse response = ApiResponse.success("Leave setup employee fetched successfully", leaveSetupEmployeeService.getLeaveSetupMasterByEmployeeId(employeeId));
        return ResponseEntity.ok(response);
    }

}
