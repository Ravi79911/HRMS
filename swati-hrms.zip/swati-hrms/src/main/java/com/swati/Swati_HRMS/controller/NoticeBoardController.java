package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.model.NoticeBoard;
import com.swati.Swati_HRMS.service.NoticeBoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/noticeboard")
public class NoticeBoardController {

    @Autowired
    private NoticeBoardService noticeBoardService;

    @GetMapping("/upcoming-holidays")
    public ResponseEntity<List<NoticeBoard>> getUpcomingHolidayNotices() {
        List<NoticeBoard> notices = noticeBoardService.getUpcomingHolidayNotices();
        return ResponseEntity.ok(notices);
    }

    @PostMapping("/createNotice")
    public ResponseEntity<NoticeBoard> createNotice(@RequestBody NoticeBoard noticeBoard) {
        NoticeBoard createdNotice = noticeBoardService.createNotice(noticeBoard);
        return ResponseEntity.ok(createdNotice);
    }
}
