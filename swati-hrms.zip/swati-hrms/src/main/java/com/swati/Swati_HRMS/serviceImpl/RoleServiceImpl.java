package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.exception.ResourceNotFoundException;
import com.swati.Swati_HRMS.model.Role;
import com.swati.Swati_HRMS.repository.RoleRepository;
import com.swati.Swati_HRMS.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class RoleServiceImpl implements RoleService {

    @Autowired
    RoleRepository roleRepository;

    @Override
    public Role createRole(Role role) {
        role.setSuspendedStatus(role.getSuspendedStatus() != null ? role.getSuspendedStatus() : 0);
        role.setUpdatedBy(role.getUpdatedBy() != null ? role.getUpdatedBy() : 0);
        role.setCreatedDate(LocalDateTime.now());
        role.setUpdatedDate(LocalDateTime.now());
        return roleRepository.saveAndFlush(role);
    }

    @Override
    public List<Role> getAllRoles() {
        return roleRepository.findAll();
    }

    @Override
    public Role getRoleById(Long id) {
        return roleRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("Role", "id", id));
    }

    @Override
    public Role updateRoleById(Long id, Role role) {
        Role existingRole = getRoleById(id);
        existingRole.setRoleName(role.getRoleName());
        existingRole.setCreatedBy(role.getCreatedBy());
        existingRole.setUpdatedBy(role.getUpdatedBy());
        existingRole.setUpdatedDate(LocalDateTime.now());
        return roleRepository.saveAndFlush(existingRole);
    }

    @Override
    public Role updateSuspendedStatus(Long id, Integer suspendedStatus, int updatedBy) {
        Role existingRole = getRoleById(id);
        existingRole.setSuspendedStatus(suspendedStatus);
        existingRole.setUpdatedBy(updatedBy);
        existingRole.setUpdatedDate(LocalDateTime.now());
        return roleRepository.saveAndFlush(existingRole);
    }

}
