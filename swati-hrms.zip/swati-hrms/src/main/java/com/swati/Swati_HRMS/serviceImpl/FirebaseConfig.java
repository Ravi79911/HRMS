package com.swati.Swati_HRMS.serviceImpl;

//import com.google.auth.oauth2.GoogleCredentials;
//import com.google.firebase.FirebaseApp;
//import com.google.firebase.FirebaseOptions;
//import org.springframework.context.annotation.Configuration;
//
//import javax.annotation.PostConstruct;
//import java.io.FileInputStream;
//import java.io.IOException;
//
//@Configuration
//public class FirebaseConfig {
//
//    @PostConstruct
//    public void initialize() throws IOException {
//        FileInputStream serviceAccount =
//                new FileInputStream("C:\\Users\\swati\\OneDrive\\Desktop\\swati-hrms\\src\\main\\resources\\firebase/hrms-9e5ab-firebase-adminsdk-fbsvc-1d14699198.json");
//
//        GoogleCredentials credentials = GoogleCredentials.fromStream(serviceAccount);
//
//        FirebaseOptions options = new FirebaseOptions.Builder()
//                .setCredentials(credentials)
//                .build();
//
//        if (FirebaseApp.getApps().isEmpty()) {
//            FirebaseApp.initializeApp(options);
//        }
//    }

//}
