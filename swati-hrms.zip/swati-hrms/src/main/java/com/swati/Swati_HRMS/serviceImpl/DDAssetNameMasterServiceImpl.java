package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.DDAssetNameMaster;
import com.swati.Swati_HRMS.repository.DDAssetNameMasterRepository;
import com.swati.Swati_HRMS.service.DDAssetNameMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class DDAssetNameMasterServiceImpl implements DDAssetNameMasterService {

    @Autowired
    private DDAssetNameMasterRepository ddAssetNameMasterRepository;

    @Override
    public DDAssetNameMaster saveAssetName(DDAssetNameMaster ddAssetNameMaster) {
        ddAssetNameMaster.setCreatedDate(LocalDateTime.now());
        ddAssetNameMaster.setSuspendedStatus(0);
        return ddAssetNameMasterRepository.save(ddAssetNameMaster);
    }

    @Override
    public Optional<DDAssetNameMaster> getAssetNameById(Integer id) {
        return ddAssetNameMasterRepository.findById(id);
    }

    @Override
    public Optional<DDAssetNameMaster> UpdateAssetName(Integer id, DDAssetNameMaster ddAssetNameMaster) {
       Optional<DDAssetNameMaster> existingddAssetNameMaster = ddAssetNameMasterRepository.findById(id);
       if (existingddAssetNameMaster.isPresent()) {
           existingddAssetNameMaster.get().setAssetName(ddAssetNameMaster.getAssetName());
           return Optional.of(ddAssetNameMasterRepository.save(existingddAssetNameMaster.get()));
       }else {
           return Optional.empty();
       }
    }

    @Override
    public List<DDAssetNameMaster> getAllAssetNameMaster() {
        return ddAssetNameMasterRepository.findBySuspendedStatus(0);
    }

    @Override
    public Optional<DDAssetNameMaster> changeStatusOfAssetNameById(Integer id) {
       Optional<DDAssetNameMaster> ddAssetNameMaster = ddAssetNameMasterRepository.findById(id);
       if (ddAssetNameMaster.isPresent()) {
           ddAssetNameMaster.get().setSuspendedStatus(1);
           return Optional.of(ddAssetNameMasterRepository.save(ddAssetNameMaster.get()));
       }else {
           return Optional.empty();
       }
    }
}
