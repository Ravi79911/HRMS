package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.StreamList;
import com.swati.Swati_HRMS.repository.StreamListRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface StreamListService {

    StreamList saveStream(StreamList streamList);
    List<StreamList> getAllStream();
    StreamList updateStreamById(Long id, StreamList updatedStreamList);
    StreamList changeStatusOfStreamById(Long id);
}
