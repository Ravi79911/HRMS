package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.service.EmployeeEsicCalculationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Month;
import java.time.YearMonth;

@CrossOrigin
@RestController
@RequestMapping("/employee/esic")
public class EmployeeEsicCalculationController {

    @Autowired
    private EmployeeEsicCalculationService employeeEsicCalculationService;

    @PostMapping("/saveEmployeeEsicCalculation")
    public ResponseEntity<?> saveEmployeeEsicCalculation(@RequestParam Long EmployeePersonalInfoId,@RequestParam String month,@RequestParam Integer year) {
        //  Validate month and year are not current or future
        if (!isValidHistoricalDate(month, year)) {
            ApiResponse errorResponse = ApiResponse.failure("Cannot process current or future months", "INVALID_DATE_RANGE");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
        ApiResponse response = ApiResponse.success("Employee Esic Calculation saved successfully", employeeEsicCalculationService.saveEmployeeEsicCalculation(EmployeePersonalInfoId, month, year));
        return ResponseEntity.ok(response);
    }

    @PatchMapping("/verifyEsic/{esicCalculationId}")
    public ResponseEntity<?> verifyEsic(@PathVariable Long esicCalculationId) {
        ApiResponse response= ApiResponse.success("Esic verified successfully", employeeEsicCalculationService.verifyPfCalculation(esicCalculationId));
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getEmployeeEsicCalculationByEmpCode/{empCode}/{month}/{year}")
    public ResponseEntity<?> getEmployeeEsicCalculationByEmpCode(@PathVariable String empCode, @PathVariable String month, @PathVariable Integer year) {
        if (!isValidHistoricalDate(month, year)) {
            ApiResponse errorResponse = ApiResponse.failure("Cannot process current or future months", "INVALID_DATE_RANGE");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
        ApiResponse response = ApiResponse.success("Employee Esic Calculation fetched successfully", employeeEsicCalculationService.getEmployeeEsicCalculationByEmpCode(empCode, month, year));
        return ResponseEntity.ok(response);
    }

    private boolean isValidHistoricalDate(String monthStr, Integer year) {
        try {
            // Convert month string to Month enum (case insensitive)
            Month requestMonth = Month.valueOf(monthStr.toUpperCase());
            YearMonth requestYearMonth = YearMonth.of(year, requestMonth);
            YearMonth currentYearMonth = YearMonth.now();

            // Check if the requested year is future
            if (year > currentYearMonth.getYear()) {
                return false;
            }

            // If same year, ensure the month is before current month
            if (year.equals(currentYearMonth.getYear())) {
                return requestMonth.getValue() < currentYearMonth.getMonth().getValue();
            }

            // Past years are always valid
            return true;
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid month provided: " + monthStr);
            return false;
        }
    }

    @DeleteMapping("/deleteEmployeeEsicCalculation/{esicCalculationId}")
    public ResponseEntity<?> deleteEmployeeEsicCalculation(@PathVariable Long esicCalculationId) {
        ApiResponse response= ApiResponse.success("Esic deleted successfully", employeeEsicCalculationService.deleteEsicCalculation(esicCalculationId));
        return ResponseEntity.ok(response);
    }
}
