package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.EventCalendarMaster;
import com.swati.Swati_HRMS.repository.EventCalendarMasterRepository;
import com.swati.Swati_HRMS.service.EventCalendarMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class EventCalendarMasterServiceImpl implements EventCalendarMasterService {

    @Autowired
    private EventCalendarMasterRepository eventCalendarMasterRepository;

    @Override
    public EventCalendarMaster saveEventCalendarMaster(EventCalendarMaster eventCalendarMaster) {
       eventCalendarMaster.setCreatedDate(LocalDateTime.now());
       eventCalendarMaster.setUpdatedDate(LocalDateTime.now());
       eventCalendarMaster.setSuspendedStatus(0);
       return eventCalendarMasterRepository.saveAndFlush(eventCalendarMaster);
    }

    @Override
    public Optional<EventCalendarMaster> getEventCalendarMasterById(Long id) {
        return eventCalendarMasterRepository.findById(id);
    }

    @Override
    public Optional<EventCalendarMaster> updateEventCalendarMaster(Long id, EventCalendarMaster eventCalendarMaster) {
        Optional<EventCalendarMaster> existingeventCalendarMaster = eventCalendarMasterRepository.findById(id);
        if (existingeventCalendarMaster.isPresent()) {
            eventCalendarMaster.setId(existingeventCalendarMaster.get().getId());
            eventCalendarMaster.setCreatedDate(existingeventCalendarMaster.get().getCreatedDate());
            eventCalendarMaster.setCreatedBy(existingeventCalendarMaster.get().getCreatedBy());
            eventCalendarMaster.setUpdatedDate(LocalDateTime.now());
            eventCalendarMaster.setSuspendedStatus(existingeventCalendarMaster.get().getSuspendedStatus());
            return Optional.of(eventCalendarMasterRepository.saveAndFlush(eventCalendarMaster));
        } else {
            throw new RuntimeException("EventCalendarMaster not found : " + id);
        }
    }

    @Override
    public Optional<EventCalendarMaster> changeStatusOfEventCalendarMasterById(Long id) {
        Optional<EventCalendarMaster> existingeventCalendarMaster = eventCalendarMasterRepository.findById(id);
        if (existingeventCalendarMaster.isPresent()) {
            existingeventCalendarMaster.get().setSuspendedStatus(1);
            return Optional.of(eventCalendarMasterRepository.saveAndFlush(existingeventCalendarMaster.get()));
        } else {
            throw new RuntimeException("EventCalendarMaster not found : " + id);
        }
    }

    @Override
    public String deleteEventCalendarMasterById(Long id) {
        Optional<EventCalendarMaster> existingeventCalendarMaster = eventCalendarMasterRepository.findById(id);
        if (existingeventCalendarMaster.isPresent()) {
            eventCalendarMasterRepository.deleteById(existingeventCalendarMaster.get().getId());
        } else {
            throw new RuntimeException("EventCalendarMaster not found : " + id);
        }
        return "EventCalendarMaster deleted successfully";
    }

    @Override
    public List<EventCalendarMaster> getAllEventCalendarMaster() {
        return eventCalendarMasterRepository.findBySuspendedStatus(0);
    }
}
