package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.DegreeList;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface DegreeListService {

    DegreeList saveDegree(DegreeList degreeList);

    List<DegreeList> getAllDegree();

    Optional<DegreeList> UpdateDegreeById(Long id, DegreeList updateDegreeList);

    Optional<DegreeList> changeStatusOfDegreeById(Long id);

}
