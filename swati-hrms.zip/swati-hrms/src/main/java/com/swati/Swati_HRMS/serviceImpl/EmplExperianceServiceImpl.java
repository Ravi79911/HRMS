package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.dto.EmployeeExperienceDetailsDTO;
import com.swati.Swati_HRMS.model.EmployeeExperienceDetails;
import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import com.swati.Swati_HRMS.repository.EmpExperianceRepository;
import com.swati.Swati_HRMS.service.EmpExperianceService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmplExperianceServiceImpl implements EmpExperianceService {

    @Autowired
    private EmpExperianceRepository empExperianceRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public EmployeeExperienceDetails saveEmployeeExperience(EmployeeExperienceDetails employeeExperienceDetails) {
        employeeExperienceDetails.setCreatedDate(LocalDateTime.now());
        employeeExperienceDetails.setSuspendedStatus(0);
        return empExperianceRepository.save(employeeExperienceDetails);
    }

    @Override
    public List<EmployeeExperienceDetailsDTO> getEmployeeKeySkillByEmployeePesronalDetailsId(Long id) {
        List<EmployeeExperienceDetails> employeeExperienceDetails = empExperianceRepository.findByEmployeePersonalDetails_Id(id);
        return employeeExperienceDetails.stream()
                .map(skill -> modelMapper.map(skill, EmployeeExperienceDetailsDTO.class))
                .collect(Collectors.toList());
    }
}
