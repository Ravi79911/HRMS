package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.EmployeeIdCounter;
import com.swati.Swati_HRMS.repository.EmployeeIdCounterRepository;
import com.swati.Swati_HRMS.service.EmployeeIdCounterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class EmployeeIdCounterServiceImpl implements EmployeeIdCounterService {

    @Autowired
    EmployeeIdCounterRepository employeeIdCounterRepository;

    @Override
    @Transactional
    public int getNextCounterValue(String counterName) {
        EmployeeIdCounter counter = employeeIdCounterRepository.findByCounterName(counterName)
                .orElseThrow(() -> new IllegalStateException("counter not found: " + counterName));

//        System.out.println("Current counter value: " + counter.getCounterValue());

        int nextValue = counter.getCounterValue() + 1;
        counter.setCounterValue(nextValue);

//        System.out.println("New counter value: " + nextValue);

        employeeIdCounterRepository.saveAndFlush(counter);
        return nextValue;
    }

}
