package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.dto.EmployeeDTO;
import com.swati.Swati_HRMS.model.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public interface EmployeeService {

    Employee createUserMaster(Employee employee, MultipartFile userPicture);

    void generateAndSendOtp(Employee employee);

    boolean validateEmailOtp(Employee employee, String otp);

    String validateForgotUsernameOtp(Employee employee, String emailOtp);

    void resendEmailOtp(Employee employee);

    String sendOtpForEmailLogin(String email);

    String forgotUsername(ForgotUserNameRequest forgotUserNameRequest);

    String changePassword(Long employeeId, ChangePasswordRequest changePasswordRequest);

    String forgotPassword(String email);

    String resetPassword(String token, ForgotPassword forgotPassword);

    Employee findEmployeeProfileByJwt(String jwt);

    Employee updateFcmToken(Long employeeId, RequestFcmToken requestFcmToken);

    List<EmployeeDTO> getAllEmployee();

    Employee findByUserId(Long id);

    boolean isEmailExists(String email);

    boolean isMobileNumberExists(String mobileNo);

    boolean isUserNameExists(String userName);

}
