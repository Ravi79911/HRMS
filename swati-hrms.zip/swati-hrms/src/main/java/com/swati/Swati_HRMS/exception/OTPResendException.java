package com.swati.Swati_HRMS.exception;

import lombok.Data;

@Data
public class OTPResendException extends RuntimeException {

    public OTPResendException(String message) {
        super(message);
    }

    public OTPResendException(String message, Throwable cause) {
        super(message, cause);
    }

}
