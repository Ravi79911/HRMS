package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.model.LeaveApplication;
import com.swati.Swati_HRMS.service.LeaveApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/leaveApplication")
public class LeaveApplicationController {

    @Autowired
    private LeaveApplicationService leaveApplicationService;

    @PostMapping("/saveLeaveApplication")
    public ResponseEntity<ApiResponse> saveLeaveApplication(@RequestBody LeaveApplication leaveApplication){
        LeaveApplication leaveApplication1 = leaveApplicationService.saveLeaveApplication(leaveApplication);
        ApiResponse response = ApiResponse.success("Leave application saved successfully", leaveApplication1);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getAllLeaveApplication")
    public ResponseEntity<ApiResponse> getAllLeaveApplication(){
        ApiResponse response = ApiResponse.success("Leave application fetched successfully", leaveApplicationService.getAllLeaveApplication());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getLeaveApplicationById/{id}")
    public ResponseEntity<ApiResponse> getLeaveApplicationById(@PathVariable Long id){
        ApiResponse response = ApiResponse.success("Leave application fetched successfully", leaveApplicationService.getLeaveApplicationById(id));
        return ResponseEntity.ok(response);
    }

    @PatchMapping("/changeStatusOfLeaveApplicationById/{id}")
    public ResponseEntity<ApiResponse> changeStatusOfLeaveApplicationById(@PathVariable Long id){
        ApiResponse response = ApiResponse.success("Leave application status changed successfully", leaveApplicationService.changeStatusOfLeaveApplicationById(id));
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getByEmployee/{employeeId}")
    public ResponseEntity<ApiResponse> getLeaveApplicationsByEmployee(@PathVariable Long employeeId) {
        List<LeaveApplication> leaveApplications = leaveApplicationService.getLeaveApplicationsByEmployeeId(employeeId);

        if (leaveApplications.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.failure("No leave applications found for employee", "LEAVE_APPLICATION_NOT_FOUND"));
        }

        return ResponseEntity.ok(ApiResponse.success("Leave applications fetched successfully", leaveApplications));
    }

}
