package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.dto.EmployeeDocumentsDTO;
import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.exception.ResourceNotFoundException;
import com.swati.Swati_HRMS.model.DocumentList;
import com.swati.Swati_HRMS.model.EmployeeDocument;
import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import com.swati.Swati_HRMS.repository.DocumentListRepository;
import com.swati.Swati_HRMS.repository.EmployeePersonalDetailsRepository;
import com.swati.Swati_HRMS.service.EmployeeDocumentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/employeeDocument")
public class EmployeeDocumentController {

    @Autowired
    EmployeeDocumentService employeeDocumentService;

    @Autowired
    EmployeePersonalDetailsRepository employeePersonalDetailsRepository;

    @Autowired
    DocumentListRepository documentListRepository;

    @PostMapping("/uploadEmployeeDocument")
    public ResponseEntity<ApiResponse> createEmployeeDocuments(@RequestParam("documentFile") MultipartFile documentFile,
                                                               @RequestParam("empMasterId") Long empMasterId,
                                                               @RequestParam("documentListId") Long documentListId,
                                                               @RequestParam("createdBy") Integer createdBy) {

        try {
            EmployeePersonalDetails employeePersonalDetail = employeePersonalDetailsRepository.findById(empMasterId)
                    .orElseThrow(() -> new ResourceNotFoundException("EmployeePersonalDetails", "id", empMasterId));
            DocumentList documentList = documentListRepository.findById(documentListId)
                    .orElseThrow(() -> new ResourceNotFoundException("DocumentList", "id", documentListId));

            EmployeeDocument employeeDocument = new EmployeeDocument();
            employeeDocument.setEmployeePersonalDetails(employeePersonalDetail);
            employeeDocument.setDocuments(documentList);
            employeeDocument.setCreatedBy(createdBy);

            EmployeeDocument savedEmployeeDocument = employeeDocumentService.createEmployeeDocument(employeeDocument, documentListId, documentFile);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(new ApiResponse("Document uploaded successfully.", true, savedEmployeeDocument));
        } catch (ResourceNotFoundException ex) {
            log.error("Resource not found: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (IllegalArgumentException ex) {
            log.error("Invalid argument: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.BAD_REQUEST);
        } catch (RuntimeException ex) {
            log.error("Internal server error: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse("An internal error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception ex) {
            log.error("Unexpected error: {}", ex.getMessage());
            return new ResponseEntity<>(new ApiResponse("Unexpected error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getEmployeeDocumentUploadDetailsURLs/{employeePersonalDetailsId}")
    public ResponseEntity<ApiResponse> getEmployeeDocumentsByEmployeePersonalDetailsId(@PathVariable("employeePersonalDetailsId") Long employeePersonalDetailsId) {
        try {
            List<String> documentUrls = employeeDocumentService.getDocumentUrlsByEmployeePersonalDetailsId(employeePersonalDetailsId);
            return ResponseEntity.ok(new ApiResponse("Document URLs retrieved successfully.", true, documentUrls));
        } catch (ResourceNotFoundException ex) {
            return new ResponseEntity<>(new ApiResponse(ex.getMessage(), false), HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ApiResponse("An unexpected error occurred.", false), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getDocuments/ByEmpPersonalDetailsId/{id}")
    public ResponseEntity<List<EmployeeDocumentsDTO>> getDocuments(@PathVariable("id") Long id) {
        List<EmployeeDocumentsDTO> documents = employeeDocumentService.getEmployeeKeySkillByEmployeePersonalDetailsId(id);
        return ResponseEntity.ok(documents);
    }

}
