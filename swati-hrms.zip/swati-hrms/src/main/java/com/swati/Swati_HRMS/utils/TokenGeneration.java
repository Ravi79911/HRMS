package com.swati.Swati_HRMS.utils;

import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class TokenGeneration {

    public String generateToken() {
        StringBuilder token = new StringBuilder();

        return token.append(UUID.randomUUID().toString())
                .append(UUID.randomUUID().toString()).toString();
    }

}
