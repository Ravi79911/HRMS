package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.LeaveTypeMaster;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface LeaveTypeMasterService {

    LeaveTypeMaster createLeaveTypemaster(LeaveTypeMaster leaveTypeMaster);
    Optional<LeaveTypeMaster> getLeaveTypemasterById(Long id);
    Optional<LeaveTypeMaster> updateLeaveTypemaster(Long id, LeaveTypeMaster leaveTypeMaster);
    Optional<LeaveTypeMaster> changeStatusOfLeaveTypemasterById(Long id);
    List<LeaveTypeMaster> getAllLeaveTypemaster();
    String deleteLeaveTypemasterById(Long id);
}
