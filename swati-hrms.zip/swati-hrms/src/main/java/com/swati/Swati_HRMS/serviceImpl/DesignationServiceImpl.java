package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.Department;
import com.swati.Swati_HRMS.model.Designation;
import com.swati.Swati_HRMS.repository.DesignationRepository;
import com.swati.Swati_HRMS.service.DesignationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class DesignationServiceImpl implements DesignationService {

    @Autowired
    private DesignationRepository designationRepository;

    @Override
    public Designation saveDesignation(Designation designation) {
        designation.setCreatedDate(LocalDateTime.now());
        designation.setSuspendedStatus(0);
        return designationRepository.save(designation);
    }

    @Override
    public List<Designation> getAllDesignations() {
        return designationRepository.findBySuspendedStatus(0);
    }

    @Override
    public Optional<Designation> updateDesignationById(Long id, Designation updatedDesignation) {
        Optional<Designation> designation = designationRepository.findById(id);
        if (designation.isPresent()) {
            designation.get().setUpdatedDate(LocalDateTime.now());
            designation.get().setUpdatedBy(updatedDesignation.getUpdatedBy());
            designation.get().setDesignation(updatedDesignation.getDesignation());
            designationRepository.save(designation.get());
        }
        return designation;
    }

    @Override
    public Optional<Designation> changeStatusOfDesignationById(Long id) {
        Optional<Designation> designation = designationRepository.findById(id);
        if (designation.isPresent()) {
            designation.get().setSuspendedStatus(1);
            designationRepository.save(designation.get());
        }
        return designation;
    }
}
