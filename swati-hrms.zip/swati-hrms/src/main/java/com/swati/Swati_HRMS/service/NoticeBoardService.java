package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.NoticeBoard;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface NoticeBoardService {

    List<NoticeBoard> getUpcomingHolidayNotices();
    NoticeBoard createNotice(NoticeBoard noticeBoard);
}
