package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "support_ticket")
public class HelpAndSupportTicket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotEmpty(message = "Subject cannot be empty")
    private String subject;

    @NotEmpty(message = "Description cannot be empty")
    @Size(min = 10, message = "Description should be at least 10 characters long")
    private String description;

    private String status = "Open";

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "emp_per_id", referencedColumnName = "id", nullable = false)
    private EmployeePersonalDetails employeePersonalDetails;

}
