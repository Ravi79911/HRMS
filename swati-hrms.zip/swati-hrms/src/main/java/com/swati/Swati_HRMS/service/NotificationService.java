package com.swati.Swati_HRMS.service;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface NotificationService {

    List<String> sendBirthdayNotifications();

}
