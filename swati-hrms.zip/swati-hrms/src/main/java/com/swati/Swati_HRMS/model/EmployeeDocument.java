package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "add_documents")
public class EmployeeDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "file_Name")
    private String docFile;

    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "emp_master_id", referencedColumnName = "id", nullable = false)
    private EmployeePersonalDetails employeePersonalDetails;

    @ManyToOne//(fetch = FetchType.LAZY)
    @JoinColumn(name = "doc_id", referencedColumnName = "id")
    private DocumentList documents;

}
