package com.swati.Swati_HRMS.dto;

import com.swati.Swati_HRMS.model.Department;
import com.swati.Swati_HRMS.model.Designation;
import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class EmpJoiningDetailsDTO {

    private Long id;
    private LocalDate joiningDate;
    private String location;
    private String createdBy;
    private LocalDateTime createdDate;
    private int suspendedStatus;
    private Designation designation;
    private Department department;

}
