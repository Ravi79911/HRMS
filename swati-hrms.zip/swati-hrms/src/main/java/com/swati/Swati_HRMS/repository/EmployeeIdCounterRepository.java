package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.EmployeeIdCounter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface EmployeeIdCounterRepository extends JpaRepository<EmployeeIdCounter, Long> {

    Optional<EmployeeIdCounter> findByCounterName(String counterName);

}
