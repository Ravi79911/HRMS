package com.swati.Swati_HRMS.controller;


import com.swati.Swati_HRMS.dto.EmpJoiningDetailsDTO;
import com.swati.Swati_HRMS.model.EmpJoiningDetails;
import com.swati.Swati_HRMS.service.EmpJoiningService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/empJoining")
public class EmpJoiningController {

    @Autowired
    private EmpJoiningService empJoiningService;

    @PostMapping("/saveEmpJoining")
    public ResponseEntity<EmpJoiningDetails> saveEmpJoining(@RequestBody EmpJoiningDetails empJoining){
        EmpJoiningDetails empJoiningDetails = empJoiningService.saveEmpJoining(empJoining);
        return ResponseEntity.ok().body(empJoiningDetails);
    }

    @GetMapping("/getEmployeeKeySkillByEmployeePesronalDetailsId/{id}")
    public ResponseEntity<List<EmpJoiningDetailsDTO>> getEmployeeKeySkillByEmployeePesronalDetailsId(@PathVariable Long id){
        List<EmpJoiningDetailsDTO> empJoiningDetails = empJoiningService.getEmployeeKeySkillByEmployeePesronalDetailsId(id);
        return ResponseEntity.ok().body(empJoiningDetails);
    }
}
