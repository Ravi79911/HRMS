package com.swati.Swati_HRMS.exception;

import io.jsonwebtoken.MalformedJwtException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    // handle ResourceNotFoundException
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ApiResponse> resourceNotFoundExceptionHandler(ResourceNotFoundException ex) {
        log.error("Resource not found: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                LocalDateTime.now(),
                "RESOURCE_NOT_FOUND",
                null
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
    }

    // handle validation errors (MethodArgumentNotValidException)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse> handleMethodArgsNotValidException(MethodArgumentNotValidException ex) {
        log.warn("Validation error: {}", ex.getMessage());

        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach(error -> {
            String fieldName = ((FieldError) error).getField();
            String message = error.getDefaultMessage();
            errors.put(fieldName, message);
        });

        ApiResponse apiResponse = new ApiResponse(
                "Validation failed",
                false,
                LocalDateTime.now(),
                "VALIDATION_ERROR",
                errors
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }

    // handle BadCredentialsException (invalid credentials)
    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity<ApiResponse> handleBadCredentialsException(BadCredentialsException ex) {
        log.error("Bad credentials: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                "BAD_CREDENTIALS_ERROR"
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }

    // handle MaxUploadSizeExceededException (file size exceeds maximum allowed limit)
    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<ApiResponse> handleMaxSizeException(MaxUploadSizeExceededException ex) {
        log.warn("File size exceeded: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                "File size exceeds the maximum allowed limit",
                false,
                "MAX_UPLOAD_SIZE_EXCEEDED"
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.PAYLOAD_TOO_LARGE);
    }

    // handle IllegalArgumentException
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ApiResponse> handleIllegalArgumentException(IllegalArgumentException ex) {
        log.error("Illegal argument: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                "ILLEGAL_ARGUMENT"
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }

    // handle RuntimeException (specific handling for RuntimeException)
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ApiResponse> handleRuntimeException(RuntimeException ex) {
        log.error("RuntimeException occurred: {}", ex.getMessage(), ex);
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                LocalDateTime.now(),
                "RUNTIME_ERROR",
                null
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    // handle uncaught general exceptions
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse> handleGenericException(Exception ex) {
        log.error("Unexpected error: {}", ex.getMessage(), ex);
        ApiResponse apiResponse = new ApiResponse(
                "An unexpected error occurred. Please try again later.",
                false,
                "INTERNAL_SERVER_ERROR"
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    // handle API exception
    @ExceptionHandler(ApiException.class)
    public ResponseEntity<ApiResponse> handleApiException(ApiException ex) {
        log.error("API exception occurred: {}", ex.getMessage(), ex);
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                LocalDateTime.now(),
                "API_ERROR",
                null
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    // handle EmployeeNotFoundException
    @ExceptionHandler(EmployeeNotFoundException.class)
    public ResponseEntity<ApiResponse> handleEmployeeNotFoundException(EmployeeNotFoundException ex) {
        log.error("Employee not found: {}", ex.getMessage(), ex);
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                LocalDateTime.now(),
                "EMPLOYEE_NOT_FOUND",
                null
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
    }

    // handle MalformedJwtException (Invalid JWT token)
    @ExceptionHandler(MalformedJwtException.class)
    public ResponseEntity<ApiResponse> handleMalformedJwtException(MalformedJwtException ex) {
        log.error("Malformed JWT Token: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                "Malformed JWT token, please provide a valid token.",
                false,
                LocalDateTime.now(),
                "JWT_MALFORMED",
                Map.of()
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }

    // handle TokenNotFoundException (token not found)
    @ExceptionHandler(TokenNotFoundException.class)
    public ResponseEntity<ApiResponse> handleTokenNotFoundException(TokenNotFoundException ex) {
        log.error("Token Not Found: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                "TOKEN_NOT_FOUND"
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }

    // handle SQLException (database-related errors)
    @ExceptionHandler(SQLException.class)
    public ResponseEntity<ApiResponse> handleSQLException(SQLException ex) {
        log.error("Database error: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                "Database error occurred. Please try again later.",
                false,
                LocalDateTime.now(),
                "DATABASE_ERROR",
                Map.of()
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    // handle OTP validation exception
    @ExceptionHandler(InvalidOTPException.class)
    public ResponseEntity<ApiResponse> handleInvalidOTPException(InvalidOTPException ex) {
        log.error("Invalid OTP error: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                LocalDateTime.now(),
                "OTP_VALIDATION_ERROR",
                null
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }

    // handle OTP resend exception
    @ExceptionHandler(OTPResendException.class)
    public ResponseEntity<ApiResponse> handleOtpResendException(OTPResendException ex) {
        log.error("OTP resend error: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                LocalDateTime.now(),
                "OTP_RESEND_ERROR",
                null
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }

    // handle OTPExpiredException (OTP expired)
    @ExceptionHandler(OTPExpiredException.class)
    public ResponseEntity<ApiResponse> handleOTPExpiredException(OTPExpiredException ex) {
        log.error("OTP expired: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                LocalDateTime.now(),
                "OTP_EXPIRED",
                null
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }

    // handle EmailNotRegisteredException (email not registered)
    @ExceptionHandler(EmailNotRegisteredException.class)
    public ResponseEntity<ApiResponse> handleEmailNotRegisteredException(EmailNotRegisteredException ex) {
        log.error("Email not registered: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                LocalDateTime.now(),
                "EMAIL_NOT_REGISTERED",
                null
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }

    // handle InvalidEmailAddressException (Invalid Email Address)
    @ExceptionHandler(InvalidEmailAddressException.class)
    public ResponseEntity<ApiResponse> handleInvalidEmailAddressException(InvalidEmailAddressException ex) {
        log.error("Invalid Email Address: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                LocalDateTime.now(),
                "INVALID_EMAIL_ADDRESS",
                null
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }

    // handle OtpGenerationException (OTP generation or sending failed)
    @ExceptionHandler(OTPGenerationException.class)
    public ResponseEntity<ApiResponse> handleOtpGenerationException(OTPGenerationException ex) {
        log.error("OTP generation or sending failed: {}", ex.getMessage(), ex);
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                LocalDateTime.now(),
                "OTP_GENERATION_FAILED",
                null
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    // handle InvalidPasswordException (invalid password)
    @ExceptionHandler(InvalidPasswordException.class)
    public ResponseEntity<ApiResponse> handleInvalidPasswordException(InvalidPasswordException ex) {
        log.error("Invalid Password: {}", ex.getMessage());
        ApiResponse apiResponse = new ApiResponse(
                ex.getMessage(),
                false,
                "INVALID_PASSWORD"
        );
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }

}
