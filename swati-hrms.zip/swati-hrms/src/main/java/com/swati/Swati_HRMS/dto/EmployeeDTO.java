package com.swati.Swati_HRMS.dto;

import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class EmployeeDTO {

    private Long id;
    private String employeeId;
    private String employeeName;
    private String fatherName;
    private String department;
    private String address;
    private String email;
    private String mobileNo;
    private LocalDate dateOfBirth;
    private String userName;
    private boolean isEmailVerified;
    private boolean isVerified;
    private Integer suspendedStatus;
    private List<RoleDTO> roles;
    private EmployeePersonalDetails employeePersonalDetails;

}
