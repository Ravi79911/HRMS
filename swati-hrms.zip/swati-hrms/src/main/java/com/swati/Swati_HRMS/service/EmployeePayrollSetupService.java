package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.dto.EmployeePayrollResponse;
import com.swati.Swati_HRMS.model.EmployeePayrollSetup;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface EmployeePayrollSetupService {

    EmployeePayrollSetup createEmployeePayrollSetup(EmployeePayrollSetup employeePayrollSetup);

    List<EmployeePayrollSetup> getAllEmployeePayrollSetup();

    double calculateGrossSalary(EmployeePayrollSetup payrollSetup);
    double calculateNetSalary(EmployeePayrollSetup payrollSetup);
    double calculateDeductions(EmployeePayrollSetup payrollSetup);
    Optional<EmployeePayrollSetup> getPayrollSetupsByEmployeeId(Long employeeId);

    List<EmployeePayrollResponse> getAllEmployeePayrolls(String month, Integer year);
    EmployeePayrollResponse getEmployeePayrollByEmpCode(String empCode, String month, Integer year);
    List<EmployeePayrollResponse> getEmployeePayrollsByDepartment(String department, String month, Integer year);

}
