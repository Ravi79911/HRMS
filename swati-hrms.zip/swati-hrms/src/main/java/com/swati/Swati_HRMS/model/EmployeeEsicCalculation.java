package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "employee_esic_calculation")
public class EmployeeEsicCalculation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "emp_code", nullable = false)
    private String empCode;

    @Column(name = "emp_name", nullable = false)
    private String empName;

    private String department;

    private String designation;

    @Column(nullable = false)
    private String month;

    @Column(nullable = false)
    private Integer year;

    @Column(name = "month_days")
    private Long monthDays;

    @Column(name = "total_working_days")
    private Integer totalWorkingDays;

    @Column(name = "total_present_days")
    private Integer totalPresentDays;

    @Column(name = "total_absent_days")
    private Integer totalAbsentDays;

    @Column(name = "gross_salary")
    private Double grossSalary;

    @Column(name = "employee_contribution_amount")
    private Double employeeContributionAmount;

    @Column(name = "employer_contribution_amount")
    private Double employerContributionAmount;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Long suspendedStatus;

    @Column(name = "is_approved")
    private Boolean isApproved;
}
