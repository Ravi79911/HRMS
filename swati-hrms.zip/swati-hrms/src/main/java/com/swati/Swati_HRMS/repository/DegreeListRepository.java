package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.DegreeList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface DegreeListRepository extends JpaRepository<DegreeList, Long> {

    List<DegreeList> findAllBySuspendedStatus(int suspendedStatus);

    @Query("SELECT d FROM DegreeList d WHERE d.suspendedStatus = 0 ORDER BY d.id ASC")
    List<DegreeList> findAllActiveByOriginalOrder();

}
