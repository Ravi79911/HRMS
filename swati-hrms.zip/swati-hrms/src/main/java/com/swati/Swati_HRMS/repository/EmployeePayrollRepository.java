package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.EmployeePayroll;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface EmployeePayrollRepository extends JpaRepository<EmployeePayroll, Long> {

    Optional<EmployeePayroll> findByEmpCodeAndMonthAndYear(String empCode, String month, Integer year);
    List<EmployeePayroll> findByEmpCode(String empCode);
    List<EmployeePayroll> findByMonthAndYear(String month, Integer year);
    List<EmployeePayroll> findByDepartmentAndMonthAndYear(String department, String month, Integer year);
}
