package com.swati.Swati_HRMS.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("http://192.168.29.245:9093", "http://localhost:3000", "http://www.swatiind.co.in:9093")
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/empSignupProfilePic/**", "/employeeDocuments/**")
                .addResourceLocations(
                        "file:D:/Backend_Project/swati-hrms/src/main/resources/static/empSignupProfilePic/",
                        "file:D:/Backend_Project/swati-hrms/src/main/resources/static/employeeDocuments/"
                );
    }

}