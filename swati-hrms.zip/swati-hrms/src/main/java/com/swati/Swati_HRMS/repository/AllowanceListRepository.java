package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.AllowanceList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface AllowanceListRepository extends JpaRepository<AllowanceList, Long> {
    List<AllowanceList> findBySuspendedStatus(int suspendedStatus);
}
