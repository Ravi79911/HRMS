package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.exception.ApiException;
import com.swati.Swati_HRMS.exception.EmailNotRegisteredException;
import com.swati.Swati_HRMS.exception.InvalidOTPException;
import com.swati.Swati_HRMS.exception.ResourceNotFoundException;
import com.swati.Swati_HRMS.jwt.JwtHelper;
import com.swati.Swati_HRMS.model.*;
import com.swati.Swati_HRMS.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@CrossOrigin
@RestController
@RequestMapping("/auth")
public class AuthenticationController {

    @Autowired
    EmployeeRepository employeeRepository;

    @Autowired
    UserDetailsService userDetailsService;

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    JwtHelper jwtHelper;

    @PostMapping("/authenticate")
    public ResponseEntity<?> login(@RequestBody JwtRequest request) {
        String usernameOrMobile = request.getEmailOrEmployeeId(); // email, employee id, or username
        String password = request.getPassword();

        // Authenticate the user
        this.doAuthenticate(usernameOrMobile, password);

        // Load user details
        UserDetails userDetails = userDetailsService.loadUserByUsername(usernameOrMobile);

        if (!(userDetails instanceof org.springframework.security.core.userdetails.User)) {
            // If user details type mismatch occurs, throw an exception
            throw new ApiException("Employee details type mismatch.");
        }

        // Retrieve employee by email, mobile, or username
        Employee employee = employeeRepository.findByEmailOrEmployeeIdOrUserName(usernameOrMobile)
                .orElseThrow(() -> new ResourceNotFoundException("Employee", "identifier", usernameOrMobile));

        // Check email verification status
        if (!employee.isEmailVerified()) {
            return new ResponseEntity<>(new LoginResponse("Please verify your email with OTP",
                    employee.getId(), employee.getEmployeePersonalDetails().getEmployeeId(), employee.getEmployeePersonalDetails().getId(), employee.getEmail(), employee.getMobileNo(),
                    employee.getRole().get(0).getRoleName(), HttpStatus.BAD_REQUEST.name()), HttpStatus.BAD_REQUEST);
        }

        // Generate JWT tokens (Access and Refresh)
        String accessToken = jwtHelper.generateAccessToken(employee);
        String refreshToken = jwtHelper.generateRefreshToken(employee);

        // Prepare JWT response
        JwtResponse response = JwtResponse.builder()
                .accessToken(accessToken)
                .refreshToken(refreshToken)
                .email(employee.getEmail())
                .mobileNumber(employee.getMobileNo())
                .employeeId(employee.getId())
                .employeeCode(employee.getEmployeePersonalDetails().getEmployeeId())
                .employeePersonalDetailsId(employee.getEmployeePersonalDetails().getId())
                .role(employee.getRole().get(0).getRoleName()) // assuming first role is sufficient
                .build();

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    // authentication for email id with OTP
    @PostMapping("/authenticateWithEmailOtp")
    public ResponseEntity<?> verifyEmailOtpAndLogin(@RequestBody EmailOtpLoginRequest emailOtpLoginRequest) {
        try {
            Employee employee = employeeRepository.findByEmail(emailOtpLoginRequest.getEmail()).orElse(null);

            if (employee == null) {
                throw new EmailNotRegisteredException("Email not registered");
            }

            // verify OTP
            if (!isOtpValid(employee, emailOtpLoginRequest.getOtp())) {
                throw new InvalidOTPException("Invalid or expired OTP");
            }

            // if OTP is valid, mark email id as verified
            employee.setEmailVerified(true);
            employee.setEmailOtp(null);  // clear OTP
            employee.setEmailOtpGeneratedDateTime(null);  // clear expiration time
            employeeRepository.saveAndFlush(employee);

            // generate JWT tokens
            String accessToken = jwtHelper.generateAccessToken(employee);
            String refreshToken = jwtHelper.generateRefreshToken(employee);

            // return response with tokens
            JwtResponse response = JwtResponse.builder()
                    .accessToken(accessToken)
                    .refreshToken(refreshToken)
                    .email(employee.getEmail())
                    .mobileNumber(employee.getMobileNo())
                    .employeeId(employee.getId())
                    .employeeCode(employee.getEmployeePersonalDetails().getEmployeeId())
                    .employeePersonalDetailsId(employee.getEmployeePersonalDetails().getId())
                    .role(employee.getRole().get(0).getRoleName())
                    .build();

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (EmailNotRegisteredException ex) {
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (InvalidOTPException ex) {
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            return new ResponseEntity<>("An unexpected error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/refreshToken")
    public ResponseEntity<?> refreshToken(@RequestBody RefreshTokenRequest request) {
        final String refreshToken = request.getRefreshToken();
        String username;

        try {
            username = jwtHelper.getUsernameFromToken(refreshToken);
        } catch (Exception e) {
            throw new ApiException("Invalid or expired refresh token.");
        }

        // retrieve employee data from the database
        Employee employee = employeeRepository.findByEmail(username)
                .orElseThrow(() -> new ResourceNotFoundException("Employee", "email", username));

        // validate the refresh token
        if (jwtHelper.validateToken(refreshToken, employee)) {
            // Generate new access and refresh tokens
            String newAccessToken = jwtHelper.generateAccessToken(employee);
            String newRefreshToken = jwtHelper.generateRefreshToken(employee);

            // prepare and return new token response
            JwtResponse response = JwtResponse.builder()
                    .accessToken(newAccessToken)
                    .refreshToken(newRefreshToken)
                    .email(employee.getEmail())
                    .mobileNumber(employee.getMobileNo())
                    .employeeId(employee.getId())
                    .employeeCode(employee.getEmployeePersonalDetails().getEmployeeId())
                    .employeePersonalDetailsId(employee.getEmployeePersonalDetails().getId())
                    .role(employee.getRole().get(0).getRoleName())
                    .build();

            return ResponseEntity.ok(response);
        } else {
            throw new ApiException("Invalid or expired refresh token.");
        }
    }

    private boolean isOtpValid(Employee employee, String otp) {
        // check if OTP exists and if it is not expired
        return employee.getEmailOtp() != null && employee.getEmailOtp().equals(otp) &&
                employee.getEmailOtpGeneratedDateTime() != null && employee.getEmailOtpGeneratedDateTime().isAfter(LocalDateTime.now());
    } // end of isOtpValid & verifyEmailOtpAndLogin

    // helper method to authenticate the user
    private void doAuthenticate(String usernameOrMobile, String password) {
        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(usernameOrMobile, password);
        try {
            authenticationManager.authenticate(authentication);
        } catch (BadCredentialsException e) {
            throw new ApiException("Invalid credentials, please check your username or password.");
        }
    }

}