package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.model.DegreeList;
import com.swati.Swati_HRMS.service.DegreeListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/degreeList")
public class DegreeListController {

    @Autowired
    private DegreeListService degreeListService;

    @PostMapping("/save")
    public ResponseEntity<DegreeList> saveDegreeList(@RequestBody DegreeList degreeList){
        return ResponseEntity.ok(degreeListService.saveDegree(degreeList));
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<DegreeList>> getAllDegreeList(){
        return ResponseEntity.ok(degreeListService.getAllDegree());
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<DegreeList> updateDegreeList(@PathVariable Long id, @RequestBody DegreeList updatedDegreeList){
        Optional<DegreeList> updated = degreeListService.UpdateDegreeById(id, updatedDegreeList);
        return updated.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PatchMapping("/changeStatus/{id}")
    public ResponseEntity<DegreeList> changeStatusOfDegreeById(@PathVariable Long id){
        Optional<DegreeList> updated = degreeListService.changeStatusOfDegreeById(id);
        return updated.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

}
