package com.swati.Swati_HRMS.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class EmailOtpLoginRequest {

    private String email;
    private String otp;

}
