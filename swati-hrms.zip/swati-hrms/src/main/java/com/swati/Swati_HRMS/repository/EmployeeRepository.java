package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    Optional<Employee> findByUserName(String userName);

    Optional<Employee> findByEmail(String email);

    Optional<Employee> findByMobileNo(String mobileNo);

    Optional<Employee> findByEmployeeId(String employeeId);

    boolean existsByEmail(String email);

    boolean existsByMobileNo(String mobileNo);

    boolean existsByUserName(String userName);

    Optional<Employee> findByToken(String token);

    @Query("SELECT e FROM Employee e WHERE e.email = :emailOrEmployeeIdOrUserName OR e.employeeId = :emailOrEmployeeIdOrUserName OR e.userName = :emailOrEmployeeIdOrUserName")
    Optional<Employee> findByEmailOrEmployeeIdOrUserName(@Param("emailOrEmployeeIdOrUserName") String emailOrEmployeeIdOrUserName);

    Employee findTopByOrderByIdDesc();

    @Query("SELECT e FROM Employee e JOIN e.role r WHERE r.roleName = :roleName")
    Optional<Employee> findFirstByRoleName(@Param("roleName") String roleName);

    // find employee by date of birth for upcoming birthday notifications
    @Query("SELECT e FROM Employee e WHERE MONTH(e.dateOfBirth) = :month AND DAY(e.dateOfBirth) BETWEEN :startDay AND :endDay")
    List<Employee> findByUpcomingBirthdays(@Param("month") int month, @Param("startDay") int startDay, @Param("endDay") int endDay);

}
