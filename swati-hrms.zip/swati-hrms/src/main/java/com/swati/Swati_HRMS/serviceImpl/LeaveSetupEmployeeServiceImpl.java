package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.dto.LeaveSetupEmployeeDTO;
import com.swati.Swati_HRMS.model.Employee;
import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import com.swati.Swati_HRMS.model.LeaveSetupEmployee;
import com.swati.Swati_HRMS.model.LeaveTypeMaster;
import com.swati.Swati_HRMS.repository.EmployeePersonalDetailsRepository;
import com.swati.Swati_HRMS.repository.EmployeeRepository;
import com.swati.Swati_HRMS.repository.LeaveSetupEmployeeRepository;
import com.swati.Swati_HRMS.repository.LeaveTypeMasterRepository;
import com.swati.Swati_HRMS.service.LeaveSetupEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class LeaveSetupEmployeeServiceImpl implements LeaveSetupEmployeeService {

    @Autowired
    private LeaveSetupEmployeeRepository leaveSetupEmployeeRepository;

    @Autowired
    private EmployeePersonalDetailsRepository employeeRepository;

    @Autowired
    private LeaveTypeMasterRepository leaveTypeMasterRepository;

    @Override
    public List<LeaveSetupEmployee> createLeaveSetupEmployeeMaster(List<LeaveSetupEmployeeDTO.LeaveTypeMasterAssignment> leaveTypeMasterAssignments, Long employeeId, Long createdBy) {
        List<LeaveSetupEmployee> leaveSetupEmployees = new ArrayList<>();

        // Check if employee exists
        Optional<EmployeePersonalDetails> employeeOpt = employeeRepository.findById(employeeId);
        if (!employeeOpt.isPresent()) {
            throw new RuntimeException("Employee with ID " + employeeId + " does not exist in employee_master table.");
        }

        // Retrieve the employee entity
        EmployeePersonalDetails employee = employeeOpt.get();

        // Proceed with creating leave setup employee records
        for (LeaveSetupEmployeeDTO.LeaveTypeMasterAssignment assignment : leaveTypeMasterAssignments) {
            LeaveTypeMaster leaveTypeMaster = leaveTypeMasterRepository.findById(assignment.getLeaveTypeMasterId())
                    .orElseThrow(() -> new RuntimeException("LeaveTypeMaster not found: " + assignment.getLeaveTypeMasterId()));

            LeaveSetupEmployee leaveSetupEmployee = new LeaveSetupEmployee();
            leaveSetupEmployee.setCreatedBy(createdBy);
            leaveSetupEmployee.setCreatedDate(LocalDateTime.now());
            leaveSetupEmployee.setUpdatedDate(LocalDateTime.now());
            leaveSetupEmployee.setSuspendedStatus(0L);
            leaveSetupEmployee.setUpdatedBy(createdBy);
            leaveSetupEmployee.setEmployee(employee);
            leaveSetupEmployee.setLeaveTypeMaster(leaveTypeMaster);
            leaveSetupEmployee.setAssignedLeaves(assignment.getAssignedLeaves());

            leaveSetupEmployees.add(leaveSetupEmployee);
        }

        return leaveSetupEmployeeRepository.saveAll(leaveSetupEmployees);
    }




    @Override
    public Optional<LeaveSetupEmployee> getLeaveSetupMasterById(Long id) {
       Optional<LeaveSetupEmployee> leaveSetup = leaveSetupEmployeeRepository.findById(id);
        if (leaveSetup.isPresent()) {
            return leaveSetup;
        }
        throw new RuntimeException("LeaveSetupEmployee not found : " + id);
    }

    @Override
    public List<LeaveSetupEmployee> updateLeaveSetupEmployeeMaster(List<LeaveSetupEmployeeDTO.LeaveTypeMasterAssignment> leaveTypeMasterAssignments, Long employeeId, Long updatedBy) {
        List<LeaveSetupEmployee> leaveSetupEmployees = new ArrayList<>();

        // Check if employee exists
        Optional<EmployeePersonalDetails> employeeOpt = employeeRepository.findById(employeeId);
        if (!employeeOpt.isPresent()) {
            throw new RuntimeException("Employee with ID " + employeeId + " does not exist in employee_master table.");
        }

        // Retrieve the employee entity
        EmployeePersonalDetails employee = employeeOpt.get();

        // Iterate over the provided leave type assignments
        for (LeaveSetupEmployeeDTO.LeaveTypeMasterAssignment assignment : leaveTypeMasterAssignments) {
            LeaveTypeMaster leaveTypeMaster = leaveTypeMasterRepository.findById(assignment.getLeaveTypeMasterId())
                    .orElseThrow(() -> new RuntimeException("LeaveTypeMaster not found: " + assignment.getLeaveTypeMasterId()));

            // Check if LeaveSetupEmployee record already exists for this employee and leave type
            Optional<LeaveSetupEmployee> existingLeaveSetup = leaveSetupEmployeeRepository
                    .findByEmployeeAndLeaveTypeMaster(employee, leaveTypeMaster);

            LeaveSetupEmployee leaveSetupEmployee;
            if (existingLeaveSetup.isPresent()) {
                // If record exists, update it
                leaveSetupEmployee = existingLeaveSetup.get();
                leaveSetupEmployee.setAssignedLeaves(assignment.getAssignedLeaves());
                leaveSetupEmployee.setUpdatedBy(updatedBy);
                leaveSetupEmployee.setUpdatedDate(LocalDateTime.now());
            } else {
                // If record doesn't exist, create a new record
                leaveSetupEmployee = new LeaveSetupEmployee();
                leaveSetupEmployee.setCreatedBy(updatedBy);
                leaveSetupEmployee.setCreatedDate(LocalDateTime.now());
                leaveSetupEmployee.setUpdatedDate(LocalDateTime.now());
                leaveSetupEmployee.setSuspendedStatus(0L);
                leaveSetupEmployee.setUpdatedBy(updatedBy);
                leaveSetupEmployee.setEmployee(employee);
                leaveSetupEmployee.setLeaveTypeMaster(leaveTypeMaster);
                leaveSetupEmployee.setAssignedLeaves(assignment.getAssignedLeaves());
            }

            leaveSetupEmployees.add(leaveSetupEmployee);
        }

        // Save the updated or new records
        return leaveSetupEmployeeRepository.saveAll(leaveSetupEmployees);
    }


    @Override
    public Optional<LeaveSetupEmployee> changeStatusOfLeaveSetupMasterById(Long id) {
        Optional<LeaveSetupEmployee> leaveSetup = leaveSetupEmployeeRepository.findById(id);
        if (leaveSetup.isPresent()) {
            leaveSetup.get().setSuspendedStatus(1L);
            leaveSetupEmployeeRepository.save(leaveSetup.get());
            return leaveSetup;
        }
        throw new RuntimeException("LeaveSetupEmployee not found : " + id);
    }

    @Override
    public List<LeaveSetupEmployee> getAllLeaveSetupMaster() {
        return leaveSetupEmployeeRepository.findAll();
    }

    @Override
    public String deleteLeaveSetupMasterById(Long id) {
        Optional<LeaveSetupEmployee> leaveSetup = leaveSetupEmployeeRepository.findById(id);
        if (leaveSetup.isPresent()) {
            leaveSetupEmployeeRepository.deleteById(leaveSetup.get().getId());
        } else {
            throw new RuntimeException("LeaveSetupEmployee not found : " + id);
        }
        return "LeaveSetupEmployee deleted successfully";
    }

    @Override
    public List<LeaveSetupEmployee> getLeaveSetupMasterByEmployeeId(Long employeeId) {
        List<LeaveSetupEmployee> leaveSetup = leaveSetupEmployeeRepository.findByEmployee_Id(employeeId);
        if (leaveSetup.isEmpty()) {
            throw new RuntimeException("LeaveSetupEmployee not found : " + employeeId);
        }
        return leaveSetup;
    }
}
