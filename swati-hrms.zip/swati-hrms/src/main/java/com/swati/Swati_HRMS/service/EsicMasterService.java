package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.EsicMaster;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface EsicMasterService {

    EsicMaster saveEsicMaster(EsicMaster esicMaster);

    List<EsicMaster> findAllEsicMaster();

    EsicMaster updateEsicMaster(Long id, EsicMaster updatedEsicMaster);

}
