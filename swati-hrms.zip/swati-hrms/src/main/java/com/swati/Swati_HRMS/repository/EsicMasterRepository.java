package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.EsicMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface EsicMasterRepository extends JpaRepository<EsicMaster,Long> {
    EsicMaster findTopBySuspendedStatusOrderByUpdatedDateDesc(int i);
}
