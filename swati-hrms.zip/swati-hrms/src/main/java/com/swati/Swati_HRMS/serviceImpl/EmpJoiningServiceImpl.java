package com.swati.Swati_HRMS.serviceImpl;


import com.swati.Swati_HRMS.dto.EmpEducationDetailsDTO;
import com.swati.Swati_HRMS.dto.EmpJoiningDetailsDTO;
import com.swati.Swati_HRMS.model.EmpEducationDetails;
import com.swati.Swati_HRMS.model.EmpJoiningDetails;
import com.swati.Swati_HRMS.repository.EmpJoiningRepository;
import com.swati.Swati_HRMS.service.EmpJoiningService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmpJoiningServiceImpl implements EmpJoiningService {

    @Autowired
    private EmpJoiningRepository empJoiningRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public EmpJoiningDetails saveEmpJoining(EmpJoiningDetails empJoiningDetails) {
        empJoiningDetails.setCreatedDate(LocalDateTime.now());
        empJoiningDetails.setSuspendedStatus(0);
        return empJoiningRepository.save(empJoiningDetails);
    }

    @Override
    public List<EmpJoiningDetailsDTO> getEmployeeKeySkillByEmployeePesronalDetailsId(Long id) {
        List<EmpJoiningDetails> empJoiningDetailsDTOS = empJoiningRepository.findByEmployeePersonalDetails_Id(id);
        return empJoiningDetailsDTOS.stream()
                .map(skill -> modelMapper.map(skill, EmpJoiningDetailsDTO.class))
                .collect(Collectors.toList());
    }
}
