package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.LeaveApplication;
import com.swati.Swati_HRMS.model.LeaveWorkFlow;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface LeaveWorkFlowRepository extends JpaRepository<LeaveWorkFlow,Long> {

    LeaveWorkFlow findFirstByApplicationIdOrderByCreatedDateDesc(LeaveApplication applicationId);

}
