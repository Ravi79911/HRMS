package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.LeaveApplication;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface LeaveApplicationService {

    LeaveApplication saveLeaveApplication(LeaveApplication leaveApplication);
    Optional<LeaveApplication> getLeaveApplicationById(Long id);
    List<LeaveApplication> getAllLeaveApplication();
    Optional<LeaveApplication> changeStatusOfLeaveApplicationById(Long id);
    List<LeaveApplication> getLeaveApplicationsByEmployeeId(Long employeeId);
}
