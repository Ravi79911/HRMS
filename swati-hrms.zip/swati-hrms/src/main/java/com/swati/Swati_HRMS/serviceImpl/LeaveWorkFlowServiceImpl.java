package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.Employee;
import com.swati.Swati_HRMS.model.LeaveApplication;
import com.swati.Swati_HRMS.model.LeaveSetupEmployee;
import com.swati.Swati_HRMS.model.LeaveWorkFlow;
import com.swati.Swati_HRMS.repository.EmployeeRepository;
import com.swati.Swati_HRMS.repository.LeaveApplicationRepository;
import com.swati.Swati_HRMS.repository.LeaveSetupEmployeeRepository;
import com.swati.Swati_HRMS.repository.LeaveWorkFlowRepository;
import com.swati.Swati_HRMS.service.LeaveWorkFlowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class LeaveWorkFlowServiceImpl implements LeaveWorkFlowService {

    @Autowired
    private LeaveWorkFlowRepository leaveWorkFlowRepository;

    @Autowired
    private LeaveApplicationRepository leaveApplicationRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private LeaveSetupEmployeeRepository leaveSetupEmployeeRepository;

    @Override
    public List<LeaveWorkFlow> getAllLeaveWorkFlow() {
        return leaveWorkFlowRepository.findAll();
    }

    @Override
    public LeaveWorkFlow handleLeaveWorkFlowForProjectManager(LeaveWorkFlow leaveWorkFlow) {
        leaveWorkFlow.setCreatedDate(LocalDateTime.now());
        leaveWorkFlow.setSuspendedStatus(0L);

        Optional<LeaveApplication> leaveApplicationOpt = leaveApplicationRepository.findById(leaveWorkFlow.getApplicationId().getId());

        // Check if LeaveApplication exists
        if (!leaveApplicationOpt.isPresent()) {
            throw new IllegalArgumentException("LeaveApplication not found for the given application ID.");
        }

        LeaveApplication leaveApplication = leaveApplicationOpt.get();
        String leaveStatus = leaveWorkFlow.getLeaveStatus();

        // Get Reporting Manager
        Optional<Employee> reportingManager = employeeRepository.findFirstByRoleName("REPORTING MANAGER");

        if (!reportingManager.isPresent()) {
            throw new IllegalArgumentException("REPORTING MANAGER user not found.");
        }

        switch (leaveApplication.getStatus()) {
            case "In Process":
                leaveWorkFlow.setCurrentUserId(reportingManager.get());

                // If Reporting Manager sets "UNAPPROVED", update LeaveApplication status
                if ("UNAPPROVED".equals(leaveStatus)) {
                    leaveApplication.setStatus("UNAPPROVED");
                    leaveApplicationRepository.save(leaveApplication);
                } else {
                    // If Reporting Manager sets "APPROVED", forward to HR Manager
                    Optional<Employee> hrManager = employeeRepository.findFirstByRoleName("HUMAN RESOURCE");

                    if (!hrManager.isPresent()) {
                        throw new IllegalArgumentException("HUMAN RESOURCE user not found.");
                    }

                    leaveWorkFlow.setNextUserId(hrManager.get());
                }
                return leaveWorkFlowRepository.save(leaveWorkFlow);

            case "APPROVED":
                LeaveWorkFlow leaveWorkFlow1 = leaveWorkFlowRepository.findFirstByApplicationIdOrderByCreatedDateDesc(leaveWorkFlow.getApplicationId());
                return leaveWorkFlow1;

            default:
                throw new RuntimeException("Invalid Status: " + leaveApplication.getStatus());
        }
    }


    @Override
    public LeaveWorkFlow handleLeaveWorkFlowForHR(LeaveWorkFlow leaveWorkFlow) {
        leaveWorkFlow.setCreatedDate(LocalDateTime.now());
        leaveWorkFlow.setSuspendedStatus(0L);

        LeaveWorkFlow leaveWorkFlow1 = leaveWorkFlowRepository.findFirstByApplicationIdOrderByCreatedDateDesc(leaveWorkFlow.getApplicationId());

        if (leaveWorkFlow1.getLeaveStatus().equals("APPROVED")) {
            leaveWorkFlow.setLeaveStatus("APPROVED");

            // Get the leave application
            LeaveApplication leaveApplication = leaveApplicationRepository.findById(leaveWorkFlow.getApplicationId().getId()).get();

            // Get the leave setup for the employee
            LeaveSetupEmployee leaveSetup = leaveApplication.getLeaveSetupEmp();

            // Check if leave setup exists and has assigned leaves
            if (leaveSetup == null || leaveSetup.getAssignedLeaves() == null || leaveSetup.getAssignedLeaves() == 0) {
                // Set a message in remarks when there are no days available
                leaveWorkFlow.setRemarks("No days for leave available for this leave type.");
            } else {
                // Subtract one day from assigned leaves
                leaveSetup.setAssignedLeaves(leaveSetup.getAssignedLeaves() - 1);

                // Update the leave setup
                leaveSetup.setUpdatedDate(LocalDateTime.now());
                leaveSetup.setUpdatedBy(leaveWorkFlow.getCreatedBy()); // Assuming HR's ID is the created_by

                // Save the updated leave setup
                leaveSetupEmployeeRepository.save(leaveSetup);
            }

            // Update the leave application status
            leaveApplication.setStatus("APPROVED");
            leaveApplicationRepository.save(leaveApplication);

            return leaveWorkFlowRepository.save(leaveWorkFlow);
        }

        return leaveWorkFlow1;
    }
}
