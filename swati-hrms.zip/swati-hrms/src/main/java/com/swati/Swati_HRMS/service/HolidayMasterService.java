package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.HolidayMaster;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface HolidayMasterService {

    HolidayMaster createHolidayMaster(HolidayMaster holidayMaster);
    Optional<HolidayMaster> getHolidayMasterById(Long id);
    Optional<HolidayMaster> updateHolidayMaster(Long id, HolidayMaster holidayMaster);
    Optional<HolidayMaster> changeStatusOfHolidayMasterById(Long id);
    String deleteHolidayMasterById(Long id);
    List<HolidayMaster> getAllHolidayMaster();
}
