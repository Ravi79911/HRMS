package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.DDOfficeWorkingLocation;
import com.swati.Swati_HRMS.repository.DDOfficeWorkingLocationRepository;
import com.swati.Swati_HRMS.service.DDOfficeWorkingLocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class DDOfficeWorkingLocationServiceImpl implements DDOfficeWorkingLocationService {

    @Autowired
    private DDOfficeWorkingLocationRepository ddOfficeWorkingLocationRepository;

    @Override
    public DDOfficeWorkingLocation saveDDOfficeWorkingLocation(DDOfficeWorkingLocation ddOfficeWorkingLocation) {
        ddOfficeWorkingLocation.setCreatedDate(LocalDateTime.now());
        ddOfficeWorkingLocation.setSuspendedStatus(0);
        return ddOfficeWorkingLocationRepository.save(ddOfficeWorkingLocation);
    }

    @Override
    public List<DDOfficeWorkingLocation> getAllDDOfficeWorkingLocation() {
        return ddOfficeWorkingLocationRepository.findBySuspendedStatus(0);
    }

    @Override
    public Optional<DDOfficeWorkingLocation> getDDOfficeWorkingLocationById(Long id) {
        return ddOfficeWorkingLocationRepository.findById(id);
    }

    @Override
    public String deleteDDOfficeWorkingLocationById(Long id) {
        Optional<DDOfficeWorkingLocation> ddOfficeWorkingLocation = ddOfficeWorkingLocationRepository.findById(id);
        if(ddOfficeWorkingLocation.isPresent()) {
            ddOfficeWorkingLocation.get().setSuspendedStatus(1);
            ddOfficeWorkingLocationRepository.save(ddOfficeWorkingLocation.get());
            return "Deleted";
        } else {
            return "Not Found";
        }
    }
}
