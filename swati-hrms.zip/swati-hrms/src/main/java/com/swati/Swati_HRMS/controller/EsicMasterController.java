package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.model.EsicMaster;
import com.swati.Swati_HRMS.service.EsicMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/esic/master")
public class EsicMasterController {

    @Autowired
    private EsicMasterService esicMasterService;

    @PostMapping("/create")
    public ResponseEntity<EsicMaster> createEsicMaster(@Valid @RequestBody EsicMaster esicMaster) {
        EsicMaster createdEsicMaster = esicMasterService.saveEsicMaster(esicMaster);
        if (createdEsicMaster == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdEsicMaster);
    }

    @GetMapping("/getAllEsicMaster")
    public ResponseEntity<List<EsicMaster>> getAllEsicMaster() {
        List<EsicMaster> esicMasters = esicMasterService.findAllEsicMaster();
        return ResponseEntity.ok(esicMasters);
    }

    @PutMapping("/EsicMaster/update/{id}")
    public ResponseEntity<EsicMaster> updateEsicMaster(@PathVariable("id") Long id, @RequestBody EsicMaster updatedEsicMaster) {
        try {
            EsicMaster updated = esicMasterService.updateEsicMaster(id, updatedEsicMaster);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

}
