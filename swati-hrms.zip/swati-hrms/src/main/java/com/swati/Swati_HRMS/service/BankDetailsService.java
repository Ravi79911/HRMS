package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.BankDetails;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface BankDetailsService {

    BankDetails saveBankDetails(BankDetails bankDetails);
    Optional<BankDetails> getBankDetails(Long id);
    String deleteBankDetails(Long id);
    Optional<BankDetails> updateBankDetails(Long id, BankDetails bankDetails);
    List<BankDetails> getAllBankDetails();
    Optional<BankDetails> getBankDetailsByEmpId(Long id);
    Optional<BankDetails> changeSuspendedStatus(Long id);
}
