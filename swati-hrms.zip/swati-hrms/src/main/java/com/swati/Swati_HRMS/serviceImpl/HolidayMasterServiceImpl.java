package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.HolidayMaster;
import com.swati.Swati_HRMS.repository.HolidayMasterRepository;
import com.swati.Swati_HRMS.service.HolidayMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class HolidayMasterServiceImpl implements HolidayMasterService {

    @Autowired
    private HolidayMasterRepository holidayMasterRepository;

    @Override
    public HolidayMaster createHolidayMaster(HolidayMaster holidayMaster) {
        holidayMaster.setCreatedDate(LocalDateTime.now());
        holidayMaster.setUpdatedDate(LocalDateTime.now());
        holidayMaster.setSuspendedStatus(0);
        return holidayMasterRepository.saveAndFlush(holidayMaster);
    }

    @Override
    public Optional<HolidayMaster> getHolidayMasterById(Long id) {
        return holidayMasterRepository.findById(id);
    }

    @Override
    public Optional<HolidayMaster> updateHolidayMaster(Long id, HolidayMaster holidayMaster) {
        Optional<HolidayMaster> existingHolidayMaster = holidayMasterRepository.findById(id);
        if (existingHolidayMaster.isPresent()) {
            holidayMaster.setId(existingHolidayMaster.get().getId());
            holidayMaster.setCreatedBy(existingHolidayMaster.get().getCreatedBy());
            holidayMaster.setCreatedDate(existingHolidayMaster.get().getCreatedDate());
            holidayMaster.setSuspendedStatus(0);
            holidayMaster.setUpdatedDate(LocalDateTime.now());
            return Optional.of(holidayMasterRepository.saveAndFlush(holidayMaster));
        }else {
            throw new RuntimeException("Holiday Master not found : " + id);
        }

    }

    @Override
    public Optional<HolidayMaster> changeStatusOfHolidayMasterById(Long id) {
        Optional<HolidayMaster> holidayMaster = holidayMasterRepository.findById(id);
        if (holidayMaster.isPresent()) {
            holidayMaster.get().setSuspendedStatus(1);
            holidayMasterRepository.save(holidayMaster.get());
        }
        return holidayMaster;
    }

    @Override
    public String deleteHolidayMasterById(Long id) {
        HolidayMaster holidayMaster = holidayMasterRepository.findById(id).get();
        if (holidayMaster==null) {
            return "Holiday Master not found";
        }else {
            holidayMasterRepository.deleteById(id);
            return "Holiday Master deleted successfully";
        }
    }

    @Override
    public List<HolidayMaster> getAllHolidayMaster() {
        return holidayMasterRepository.findBySuspendedStatus(0);
    }
}
