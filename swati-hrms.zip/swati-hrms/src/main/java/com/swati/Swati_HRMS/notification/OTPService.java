package com.swati.Swati_HRMS.notification;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Random;

@Service
public class OTPService {

    @Autowired
    EmailService emailService;

    /**
     * Generates a 6-digit OTP.
     *
     * @return A 6-digit OTP as a String.
     */
    public String generateOTP() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000);  // generates a 6-digit number
        return String.valueOf(otp);
    }

    // method to send otp to employee email at the time of employee registration
    @Async
    public void sendEmailOTP(String email, String otp, String employeeName) {
        String subject = "Verify your email address - HRMS";

        String message = "<div style='font-family:Arial, sans-serif; background-color:#f4f4f9; padding:30px; border-radius:10px; max-width:600px; margin:auto;'>"
                + "<div style='text-align:center; margin-bottom:20px;'>"
                + "<img src='https://swatiind.com/wp-content/uploads/2023/07/Swati-Enterprises-Final.png' alt='Swati Industries' style='max-width:150px; height:auto;' />"
                + "</div>"
                + "<div style='background-color:#ffffff; padding:20px; border-radius:10px; box-shadow:0 4px 8px rgba(0, 0, 0, 0.1);'>"
                + "<h2 style='color:#333333;'>Dear " + employeeName + ",</h2>"
                + "<p style='font-size:16px; color:#555555;'>We have received a request to verify your account. Below is your One-Time Password (OTP) for verification:</p>"
                + "<div style='font-size:24px; font-weight:bold; color:#333333; background-color:#e0f7fa; padding:10px; text-align:center; border-radius:5px;'>"
                + otp
                + "</div>"
                + "<p style='font-size:16px; color:#555555;'>Please enter this OTP in the required field to complete your verification process.</p>"
                + "<p style='font-size:16px; color:#555555;'>If you did not request this OTP, please ignore this email.</p>"
                + "</div>"
                + "<div style='text-align:center; margin-top:30px;'>"
                + "<p style='font-size:14px; color:#888888;'>Best regards,</p>"
                + "<p style='font-size:16px; color:#333333;'>Swati Industries</p>"
                + "<p style='font-size:14px; color:#888888;'>HR Department</p>"
                + "<a href='https://swatiind.com/' target='_blank' style='color:#007bff; text-decoration:none; font-size:16px;'>Visit our website</a>"
                + "</div>"
                + "</div>";

        emailService.sendEmail(email, subject, message);
    }

    // method to send otp to employee email at the time of employee login
    @Async
    public void sendEmailOTPForLogin(String email, String otp, String employeeName) {
        String subject = "Login OTP - HRMS";

        String message = "<div style='font-family:Arial, sans-serif; background-color:#f4f4f9; padding:30px; border-radius:10px; max-width:600px; margin:auto;'>"
                + "<div style='text-align:center; margin-bottom:20px;'>"
                + "<img src='https://swatiind.com/wp-content/uploads/2023/07/Swati-Enterprises-Final.png' alt='Swati Industries' style='max-width:150px; height:auto;' />"
                + "</div>"
                + "<div style='background-color:#ffffff; padding:20px; border-radius:10px; box-shadow:0 4px 8px rgba(0, 0, 0, 0.1);'>"
                + "<h2 style='color:#333333;'>Dear " + employeeName + ",</h2>"
                + "<p style='font-size:16px; color:#555555;'>We have received a request to login your account. Below is your One-Time Password (OTP) for login:</p>"
                + "<div style='font-size:24px; font-weight:bold; color:#333333; background-color:#e0f7fa; padding:10px; text-align:center; border-radius:5px;'>"
                + otp
                + "</div>"
                + "<p style='font-size:16px; color:#555555;'>Please enter this OTP in the required field to complete your login process.</p>"
                + "<p style='font-size:16px; color:#555555;'>If you did not request this OTP, please ignore this email.</p>"
                + "</div>"
                + "<div style='text-align:center; margin-top:30px;'>"
                + "<p style='font-size:14px; color:#888888;'>Best regards,</p>"
                + "<p style='font-size:16px; color:#333333;'>Swati Industries</p>"
                + "<p style='font-size:14px; color:#888888;'>HR Department</p>"
                + "<a href='https://swatiind.com/' target='_blank' style='color:#007bff; text-decoration:none; font-size:16px;'>Visit our website</a>"
                + "</div>"
                + "</div>";

        emailService.sendEmail(email, subject, message);
    }

}
