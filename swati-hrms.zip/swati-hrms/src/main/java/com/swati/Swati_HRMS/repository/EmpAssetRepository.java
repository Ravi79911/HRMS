package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.EmpAsset;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface EmpAssetRepository extends JpaRepository<EmpAsset, Long> {
    List<EmpAsset> findByEmployeePersonalDetails_Id(Long id);
}
