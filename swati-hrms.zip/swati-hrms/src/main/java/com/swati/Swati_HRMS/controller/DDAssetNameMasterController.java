package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.model.DDAssetNameMaster;
import com.swati.Swati_HRMS.service.DDAssetNameMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/ddassetnamemaster")
public class DDAssetNameMasterController {

    @Autowired
    private DDAssetNameMasterService ddAssetNameMasterService;

    @PostMapping("/saveAssetName")
    public ResponseEntity<?> saveAssetName(@RequestBody DDAssetNameMaster ddAssetNameMaster) {
        ApiResponse response = ApiResponse.success("Asset name saved successfully", ddAssetNameMasterService.saveAssetName(ddAssetNameMaster));
        return ResponseEntity.ok(response);
    }

    @PutMapping("/updateAssetName/{id}")
    public ResponseEntity<?> updateAssetName(@PathVariable Integer id, @RequestBody DDAssetNameMaster ddAssetNameMaster) {
        ApiResponse response = ApiResponse.success("Asset name updated successfully", ddAssetNameMasterService.UpdateAssetName(id, ddAssetNameMaster));
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getAssetNameById/{id}")
    public ResponseEntity<?> getAssetNameById(@PathVariable Integer id) {
        ApiResponse response = ApiResponse.success("Asset name fetched successfully", ddAssetNameMasterService.getAssetNameById(id));
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getAllAssetNameMaster")
    public ResponseEntity<?> getAllAssetNameMaster() {
        ApiResponse response = ApiResponse.success("Asset name fetched successfully", ddAssetNameMasterService.getAllAssetNameMaster());
        return ResponseEntity.ok(response);
    }

    @PatchMapping("/changeStatusOfAssetNameMasterById/{id}")
    public ResponseEntity<?> changeStatusOfAssetNameMasterById(@PathVariable Integer id) {
        ApiResponse response = ApiResponse.success("Asset name status changed successfully", ddAssetNameMasterService.changeStatusOfAssetNameById(id));
        return ResponseEntity.ok(response);
    }
}
