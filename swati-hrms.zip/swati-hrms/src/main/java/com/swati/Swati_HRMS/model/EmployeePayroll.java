package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Map;

@Entity
@Table(name = "employee_payroll")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmployeePayroll {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "emp_code", nullable = false)
    private String empCode;

    @Column(name = "emp_name", nullable = false)
    private String empName;

    @Column(name = "department")
    private String department;

    @Column(name = "designation")
    private String designation;

    @Column(name = "month", nullable = false)
    private String month;

    @Column(name = "year", nullable = false)
    private Integer year;

    @Column(name = "total_working_days")
    private Integer totalWorkingDays;

    @Column(name = "total_present_days")
    private Integer totalPresentDays;

    @Column(name = "total_absent_days")
    private Integer totalAbsentDays;

    @Column(name = "basic_salary")
    private Double basicSalary;

    @Column(name = "hra")
    private Double hra;

    @ElementCollection
    @CollectionTable(name = "employee_allowances",
            joinColumns = @JoinColumn(name = "payroll_id"))
    @MapKeyColumn(name = "allowance_name")
    @Column(name = "allowance_amount")
    private Map<String, Double> allowances;

    @Column(name = "gross_salary")
    private Double grossSalary;

    @Column(name = "pf")
    private Double pf;

    @Column(name = "esic")
    private Double esic;

    @Column(name = "total_deductions")
    private Double totalDeductions;

    @Column(name = "net_salary")
    private Double netSalary;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name="suspended_status")
    private Long suspendedStatus;

    @Column(name = "is_approved")
    private Boolean isVerified;
}
