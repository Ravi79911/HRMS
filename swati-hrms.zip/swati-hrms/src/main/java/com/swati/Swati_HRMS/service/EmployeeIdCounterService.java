package com.swati.Swati_HRMS.service;

import org.springframework.stereotype.Service;

@Service
public interface EmployeeIdCounterService {

    int getNextCounterValue(String counterName);

}
