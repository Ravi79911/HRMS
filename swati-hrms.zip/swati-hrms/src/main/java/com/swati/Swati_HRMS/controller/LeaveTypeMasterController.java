package com.swati.Swati_HRMS.controller;


import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.model.LeaveTypeMaster;
import com.swati.Swati_HRMS.service.LeaveTypeMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/leavetype")
public class LeaveTypeMasterController {

    @Autowired
    private LeaveTypeMasterService leaveTypeMasterService;

    @PostMapping("/saveLeaveTypeMaster")
    public ResponseEntity<?> saveLeaveTypeMaster(@RequestBody LeaveTypeMaster leaveTypeMaster){
        LeaveTypeMaster leaveType = leaveTypeMasterService.createLeaveTypemaster(leaveTypeMaster);
        ApiResponse response = ApiResponse.success("LeaveTypeMaster saved successfully", leaveType);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getLeaveTypeMasterById/{id}")
    public ResponseEntity<?> getLeaveTypeMasterById(@PathVariable Long id){
        LeaveTypeMaster leaveTypeMaster = leaveTypeMasterService.getLeaveTypemasterById(id).get();
        ApiResponse response = ApiResponse.success("LeaveTypeMaster fetched successfully", leaveTypeMaster);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getAllLeaveTypeMaster")
    public ResponseEntity<?> getAllLeaveTypeMaster(){
        ApiResponse response = ApiResponse.success("LeaveTypeMaster fetched successfully", leaveTypeMasterService.getAllLeaveTypemaster());
        return ResponseEntity.ok(response);
    }

    @PutMapping("/updateLeaveTypeMaster/{id}")
    public ResponseEntity<?> updateLeaveTypeMaster(@PathVariable Long id, @RequestBody LeaveTypeMaster leaveTypeMaster){
        ApiResponse response = ApiResponse.success("LeaveTypeMaster updated successfully", leaveTypeMasterService.updateLeaveTypemaster(id, leaveTypeMaster));
        return ResponseEntity.ok(response);
    }

    @PatchMapping("/changeStatusOfLeaveTypeMasterById/{id}")
    public ResponseEntity<?> changeStatusOfLeaveTypeMasterById(@PathVariable Long id){
        ApiResponse response = ApiResponse.success("LeaveTypeMaster status changed successfully", leaveTypeMasterService.changeStatusOfLeaveTypemasterById(id));
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/deleteLeaveTypeMasterById/{id}")
    public ResponseEntity<?> deleteLeaveTypeMasterById(@PathVariable Long id){
        ApiResponse response = ApiResponse.success("LeaveTypeMaster deleted successfully", leaveTypeMasterService.deleteLeaveTypemasterById(id));
        return ResponseEntity.ok(response);
    }
}
