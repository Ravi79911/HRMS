package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.model.StreamList;
import com.swati.Swati_HRMS.service.StreamListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/stream")
public class StreamListController {

    @Autowired
    private StreamListService streamListService;

    @PostMapping("/save")
    public ResponseEntity<StreamList> saveStreamList(@RequestBody StreamList streamList){
        return ResponseEntity.ok(streamListService.saveStream(streamList));
    }

    @GetMapping("/all")
    public ResponseEntity<List<StreamList>> getAllStreamList(){
        return ResponseEntity.ok(streamListService.getAllStream());
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<StreamList> updateStreamList(@PathVariable Long id, @RequestBody StreamList updatedStreamList){
        return ResponseEntity.ok(streamListService.updateStreamById(id, updatedStreamList));
    }

    @PatchMapping("/deleteBy/{id}")
    public ResponseEntity<StreamList> suspendStreamList(@PathVariable Long id){
        Optional<StreamList> updated = Optional.ofNullable(streamListService.changeStatusOfStreamById(id));
        return updated.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
