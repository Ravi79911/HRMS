package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.dto.EmployeeStatisticsDTO;
import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.exception.EmployeeNotFoundException;
import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import com.swati.Swati_HRMS.service.EmployeePersonalDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/employeePersonalDetails")
public class EmployeePersonalDetailsController {

    @Autowired
    private EmployeePersonalDetailsService employeePersonalDetailsService;

    @PostMapping("/saveEmployeePersonalDetails")
    public ResponseEntity<EmployeePersonalDetails> saveEmployeePersonalDetails(@RequestBody EmployeePersonalDetails employeePersonalDetails) {
        return ResponseEntity.ok(employeePersonalDetailsService.saveEmployeePersonalDetails(employeePersonalDetails));
    }

    @GetMapping("/getAllEmployeePersonalDetails")
    public ResponseEntity<List<EmployeePersonalDetails>> getAllEmployeePersonalDetails() {
        return ResponseEntity.ok(employeePersonalDetailsService.getAllDocument());
    }

    @GetMapping("/findByEmployeeId/{employeeId}")
    public ResponseEntity<ApiResponse> getEmployeeById(@PathVariable String employeeId) {
        try {
            EmployeePersonalDetails employee = employeePersonalDetailsService.findByEmployeeId(employeeId);
            ApiResponse response = ApiResponse.success("Employee details fetched successfully", employee);
            return ResponseEntity.ok(response);
        } catch (EmployeeNotFoundException ex) {
            ApiResponse response = ApiResponse.failure(ex.getMessage(), "EMPLOYEE_NOT_FOUND");
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/updateEmployeePersonalDetails/{id}")
    public ResponseEntity<Optional<EmployeePersonalDetails>> updateEmployeePersonalDetails(@PathVariable Long id, @RequestBody EmployeePersonalDetails employeePersonalDetails) {
        return ResponseEntity.ok(employeePersonalDetailsService.updateEmployeePersonalDetails(id, employeePersonalDetails));
    }

    @PatchMapping("/deleteBy/{id}")
    public ResponseEntity<EmployeePersonalDetails> deleteEmployeePersonalDetails(@PathVariable("id") Long id) {
        Optional<EmployeePersonalDetails> deleted = employeePersonalDetailsService.changeStatusOfDocumentById(id);
        return deleted.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/findById/{id}")
    public ResponseEntity<Optional<EmployeePersonalDetails>> findById(@PathVariable("id") Long id) {
        return ResponseEntity.ok(employeePersonalDetailsService.getEmployeeWithSkills(id));
    }

    @GetMapping("/statistics")
    public ResponseEntity<EmployeeStatisticsDTO> getEmployeeStatistics() {
        EmployeeStatisticsDTO statistics = employeePersonalDetailsService.getEmployeeStatistics();
        return ResponseEntity.ok(statistics);
    }

    @GetMapping("/count/department/{departmentId}")
    public ResponseEntity<Long> getEmployeeCountByDepartment(@PathVariable Long departmentId) {
        Long count = employeePersonalDetailsService.getEmployeeCountForDepartmentById(departmentId);
        return ResponseEntity.ok(count);
    }

}
