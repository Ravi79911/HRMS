package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.dto.LeaveSetupEmployeeDTO;
import com.swati.Swati_HRMS.model.LeaveSetupEmployee;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface LeaveSetupEmployeeService {

    List<LeaveSetupEmployee> createLeaveSetupEmployeeMaster(List<LeaveSetupEmployeeDTO.LeaveTypeMasterAssignment> leaveTypeMasterAssignments, Long employeeId, Long createdBy);
    Optional<LeaveSetupEmployee> getLeaveSetupMasterById(Long id);
    List<LeaveSetupEmployee> updateLeaveSetupEmployeeMaster(List<LeaveSetupEmployeeDTO.LeaveTypeMasterAssignment> leaveTypeMasterAssignments, Long employeeId, Long updatedBy);
    Optional<LeaveSetupEmployee> changeStatusOfLeaveSetupMasterById(Long id);
    List<LeaveSetupEmployee> getAllLeaveSetupMaster();
    String deleteLeaveSetupMasterById(Long id);
    List<LeaveSetupEmployee> getLeaveSetupMasterByEmployeeId(Long employeeId);
}
