package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.DDWorkMode;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface DDWorkModeService {

    DDWorkMode saveDDWorkMode(DDWorkMode ddWorkMode);
    List<DDWorkMode> getAllDDWorkMode();
    Optional<DDWorkMode> getDDWorkModeById(Long id);
    String deleteDDWorkMode(Long id);
}
