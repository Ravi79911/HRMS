package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.Department;
import com.swati.Swati_HRMS.repository.DepartmentRepository;
import com.swati.Swati_HRMS.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    @Override
    public Department saveDepartment(Department department) {
        department.setCreatedDate(LocalDateTime.now());
        department.setSuspendedStatus(0);
        return departmentRepository.save(department);
    }

    @Override
    public List<Department> getAllDepartments() {
        return departmentRepository.findBySuspendedStatus(0);
    }

    @Override
    public Optional<Department> updateDepartmentById(Long id, Department updatedDepartment) {
        Optional<Department> department = departmentRepository.findById(id);
        if (department.isPresent()) {
            department.get().setUpdatedDate(LocalDateTime.now());
            department.get().setUpdatedBy(updatedDepartment.getUpdatedBy());
            department.get().setDepartment(updatedDepartment.getDepartment());
            departmentRepository.save(department.get());
        }
        return department;
    }


    @Override
    public Optional<Department> changeStatusOfDepartmentById(Long id) {
        Optional<Department> department = departmentRepository.findById(id);
        if (department.isPresent()) {
            department.get().setSuspendedStatus(1);
            departmentRepository.save(department.get());
        }
        return department;
    }
}
