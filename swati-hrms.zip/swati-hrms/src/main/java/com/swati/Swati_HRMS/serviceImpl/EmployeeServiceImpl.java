package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.dto.EmployeeDTO;
import com.swati.Swati_HRMS.dto.RoleDTO;
import com.swati.Swati_HRMS.exception.*;
import com.swati.Swati_HRMS.jwt.JwtHelper;
import com.swati.Swati_HRMS.model.*;
import com.swati.Swati_HRMS.notification.EmailService;
import com.swati.Swati_HRMS.notification.OTPService;
import com.swati.Swati_HRMS.repository.EmployeeRepository;
import com.swati.Swati_HRMS.service.EmployeeService;
import com.swati.Swati_HRMS.utils.PasswordGeneration;
import com.swati.Swati_HRMS.utils.TokenGeneration;
import io.jsonwebtoken.JwtException;
import jakarta.mail.MessagingException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Slf4j
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;

    @Autowired
    JwtHelper jwtHelper;

    @Autowired
    TokenGeneration tokenGeneration;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    EmailService emailService;

    @Autowired
    OTPService otpService;

    @Value("${upload.employee.profilePic.dir}")
    private String BASE_UPLOAD_DIR;

    @Value("${upload.employee.profilePic.dir}")
    private String uploadDir;

    private static final long MAX_FILE_SIZE = 200 * 1024;
    private static final int OTP_EXPIRATION_MINUTES = 5;

    @Override
    public Employee createUserMaster(Employee employee, MultipartFile userPicture) {
        if (isEmailExists(employee.getEmail())) {
            throw new IllegalArgumentException("email address already exists");
        }

        if (isUserNameExists(employee.getUsername())) {
            throw new IllegalArgumentException("username already exists");
        }

        // handle file upload
        if (userPicture != null && !userPicture.isEmpty()) {
            handleFileUpload(userPicture, employee);
        } else {
            System.out.println("uploaded file is null or empty");
        }

        // generate a random password using the PasswordGeneration.class
        String randomPassword = PasswordGeneration.generateRandomPassword();
        employee.setPassword(passwordEncoder.encode(randomPassword));  // encode password
        employee.setUpdatedBy(employee.getUpdatedBy() != null ? employee.getUpdatedBy() : 0);
        employee.setSuspendedStatus(employee.getSuspendedStatus() != null ? employee.getSuspendedStatus() : 0);
        employee.setCreatedDate(LocalDateTime.now());
        employee.setUpdatedDate(LocalDateTime.now());
        Employee savedEmployee = employeeRepository.saveAndFlush(employee);

//        // save the first password change history entry
//        UserMasterPasswordChangeHistory passwordHistory = new UserMasterPasswordChangeHistory();
//        passwordHistory.setUserMasterId(savedUser.getId());
//        passwordHistory.setLastPwdChange(savedUser.getPassword());
//        passwordHistory.setPwdChangedDateTime(LocalDateTime.now());
//        passwordHistory.setIpAddress(savedUser.getIpAddress());
//        passwordHistory.setCreatedBy(savedUser.getUpdatedBy());
//        passwordHistory.setCreatedDate(LocalDateTime.now());
//        passwordHistory.setMunicipalId(savedUser.getMunicipalId());
//        userMasterPasswordChangeHistoryRepository.saveAndFlush(passwordHistory); // end of password change history block

        // after saving the employee, send a confirmation email
        try {
            String roleName = savedEmployee.getRole().stream()
                    .map(Role::getRoleName)
                    .collect(Collectors.joining(", "));

            emailService.sendRegistrationConfirmationEmailBeforeOtpVerification(
                    savedEmployee.getEmail(),
                    randomPassword,
                    savedEmployee.getEmployeeId(),
                    roleName,
                    savedEmployee.getEmployeeName()
            );
        } catch (MessagingException | UnsupportedEncodingException e) {
            log.error("Failed to send confirmation email to {}", savedEmployee.getEmail(), e);
            throw new RuntimeException("failed to send confirmation email");
        } // block end for email sending

        generateAndSendOtp(savedEmployee); // generate otp for email & mobile verification
        return savedEmployee;
    }

    @Override
    public void generateAndSendOtp(Employee employee) {
        try {
            // generate email otp
            String emailOtp = otpService.generateOTP();
            employee.setEmailOtp(emailOtp);
            employee.setEmailOtpGeneratedDateTime(LocalDateTime.now());
            employeeRepository.saveAndFlush(employee);

            // send otp via email
            otpService.sendEmailOTP(employee.getEmail(), emailOtp, employee.getEmployeeName());
        } catch (Exception e) {
            throw new OTPGenerationException("Failed to generate or send OTP for employee: " + employee.getEmail(), e);
        }
    }

    @Override
    public boolean validateEmailOtp(Employee employee, String otp) {
        if (employee.getEmailOtpGeneratedDateTime().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now())) {
            throw new InvalidOTPException("OTP has expired.");
        }

        if (employee.getEmailOtp().equals(otp)) {
            // OTP matches, update email verification status
            employee.setEmailVerified(true);
            employee.setEmailOtp(null); // clear OTP after successful verification
            employee.setEmailOtpGeneratedDateTime(null); // clear OTP timestamp
            employee.setUpdatedDate(LocalDateTime.now());
            employeeRepository.saveAndFlush(employee);

            // check if both email and mobile are verified
            if (employee.isEmailVerified()) {
                employee.setVerified(true); // set overall verified status
                employeeRepository.saveAndFlush(employee);
                // send confirmation email when the user is fully verified
                try {
                    emailService.sendConfirmationEmailAfterOTPVerification(employee.getEmployeeName(), employee.getEmail());
                } catch (MessagingException | UnsupportedEncodingException e) {
                    log.error("Failed to send confirmation email to {}", employee.getEmail(), e);
                }
            }
            return true; // verification successful
        }
        throw new InvalidOTPException("OTP mismatch.");
    }

    @Override
    public String validateForgotUsernameOtp(Employee employee, String emailOtp) {
        LocalDateTime otpGenerationDateTime = LocalDateTime.now();

        // validate email otp
        if (employee.getEmailOtp() == null || !employee.getEmailOtp().equals(emailOtp)) {
            throw new InvalidOTPException("Invalid email OTP.");
        }

        // validate email otp expiration
        if (employee.getEmailOtpGeneratedDateTime().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(otpGenerationDateTime)) {
            throw new OTPExpiredException("Email OTP has expired.");
        }

        // otp is valid, send the username to the user
        try {
            emailService.sendUsernameToUserEmail(employee.getEmail(), employee.getUsername(), employee.getEmployeeName());
            // clear otp after successful verification
            employee.setEmailOtp(null);
            employee.setEmailOtpGeneratedDateTime(null);

            // update verification status
            employee.setEmailVerified(true);
            employee.setUpdatedDate(LocalDateTime.now());
            employeeRepository.saveAndFlush(employee);
        } catch (MessagingException | UnsupportedEncodingException e) {
            log.error("Failed to send username email to {}", employee.getEmail(), e);
            throw new RuntimeException("OTP validated successfully, but we couldn't send the username email at the moment.");
        }
        return "OTP validated successfully. Your username has been sent to your email.";
    }

    @Override
    public void resendEmailOtp(Employee employee) {
        if (employee == null) {
            throw new OTPResendException("Employee not found with the given employee id.");
        }

        // check if OTP has expired
        if (employee.getEmailOtpGeneratedDateTime().plusMinutes(OTP_EXPIRATION_MINUTES).isBefore(LocalDateTime.now())) {
            // OTP expired, regenerate OTP
            String newEmailOtp = otpService.generateOTP();
            if (newEmailOtp == null || newEmailOtp.isEmpty()) {
                throw new OTPResendException("Failed to generate a new OTP.");
            }

            employee.setEmailOtp(newEmailOtp);
            employee.setEmailOtpGeneratedDateTime(LocalDateTime.now());
            employeeRepository.saveAndFlush(employee);

            // send the new OTP via email
            otpService.sendEmailOTP(employee.getEmail(), newEmailOtp, employee.getEmployeeName());
        } else {
            // OTP is still valid, send the existing OTP
            otpService.sendEmailOTP(employee.getEmail(), employee.getEmailOtp(), employee.getEmployeeName());
        }
    }

    @Override
    public String sendOtpForEmailLogin(String email) {
        // check if the email exists in the database
        Employee employee = employeeRepository.findByEmail(email).orElse(null);

        if (employee == null) {
            throw new EmailNotRegisteredException("Email is not registered: " + email);
        }

        try {
            // generate and send OTP
            String emailOtp = otpService.generateOTP();
            otpService.sendEmailOTPForLogin(email, emailOtp, employee.getEmployeeName());

            // store the OTP and expiration in the database
            employee.setEmailOtp(emailOtp);
            employee.setEmailOtpGeneratedDateTime(LocalDateTime.now().plusMinutes(OTP_EXPIRATION_MINUTES));
            employeeRepository.saveAndFlush(employee);

            return "OTP sent successfully";
        } catch (Exception e) {
            throw new OTPGenerationException("Failed to send OTP to email: " + email, e);
        }
    }

    @Override
    public String forgotUsername(ForgotUserNameRequest forgotUserNameRequest) {
        // validate if the email exists
        Employee employee = employeeRepository.findByEmail(forgotUserNameRequest.getEmail())
                .orElseThrow(() -> new EmailNotFoundException("Email not found: " + forgotUserNameRequest.getEmail()));

        // generate OTP for the email
        generateAndSendOtp(employee);
        return "OTP has been sent to your email. Please verify.";
    }

    @Override
    public String changePassword(Long employeeId, ChangePasswordRequest changePasswordRequest) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new EmployeeNotFoundException("Employee not found with id: " + employeeId));

        // validate old password
        if (!passwordEncoder.matches(changePasswordRequest.getOldPassword(), employee.getPassword())) {
            throw new InvalidPasswordException("Old password is incorrect");
        }

        // check if new password & confirm password are the same
        if (!changePasswordRequest.getNewPassword().equals(changePasswordRequest.getConfirmPassword())) {
            throw new InvalidPasswordException("New password and confirm password are not the same");
        }

        // check if new password is different from the old password
        if (passwordEncoder.matches(changePasswordRequest.getNewPassword(), employee.getPassword())) {
            throw new InvalidPasswordException("Your new password can't be the same as your old password");
        }

        // update the password
        employee.setPassword(passwordEncoder.encode(changePasswordRequest.getNewPassword()));
        employee.setUpdatedDate(LocalDateTime.now());
        employeeRepository.saveAndFlush(employee);

        // send confirmation email
        try {
            emailService.sendChangePasswordSuccessEmail(employee.getEmployeeName(), employee.getEmail());
        } catch (MessagingException | UnsupportedEncodingException e) {
            log.error("Failed to send confirmation email to {}", employee.getEmail(), e);
            throw new RuntimeException("Password change successful, but confirmation email couldn't be sent at the moment.");
        }
        return "Your password has been changed successfully";
    }

    @Override
    public String forgotPassword(String email) {
        Employee employee = employeeRepository.findByEmail(email)
                .orElseThrow(() -> new EmailNotFoundException("Email not found: " + email));

        String generateToken = tokenGeneration.generateToken();

        try {
            emailService.sendResetPasswordEmail(email, generateToken, employee.getEmployeeName());
        } catch (Exception e) {
            throw new RuntimeException("Unable to send reset link. Please try again later.");
        }

        employee.setToken(generateToken);
        employee.setTokenGeneratedDateTime(LocalDateTime.now());
        try {
            employeeRepository.saveAndFlush(employee);
        } catch (Exception ex) {
            throw new RuntimeException("Error occurred while saving the token. Please try again.");
        }
        return "Please check your email, a link has been sent to reset your password.";
    }

    @Override
    public String resetPassword(String token, ForgotPassword forgotPassword) {
        if (!forgotPassword.getNewPassword().equals(forgotPassword.getConfirmPassword())) {
            throw new InvalidPasswordException("New password doesn't match the confirm password.");
        }

        Employee employee = employeeRepository.findByToken(token)
                .orElseThrow(() -> new TokenNotFoundException("Invalid or expired token"));

        if (Duration.between(employee.getTokenGeneratedDateTime(), LocalDateTime.now()).getSeconds() >= 5 * 60) {
            throw new ExpiredTokenException("Your session has expired. Please request a new reset password link.");
        }

        if (passwordEncoder.matches(forgotPassword.getNewPassword(), employee.getPassword())) {
            throw new InvalidPasswordException("Your new password can't be the same as your previous password.");
        }

        // reset the password and clear the token
        employee.setPassword(passwordEncoder.encode(forgotPassword.getNewPassword()));
        employee.setToken(null);
        employee.setTokenGeneratedDateTime(null);
        employeeRepository.saveAndFlush(employee);

        // send confirmation email after successful password reset
        try {
            emailService.sendResetPasswordSuccessEmail(employee.getEmployeeName(), employee.getEmail());
        } catch (MessagingException | UnsupportedEncodingException e) {
            log.error("Failed to send confirmation email to {}", employee.getEmail(), e);
            throw new EmailNotFoundException("Password reset successful, but we couldn't send the confirmation email at the moment.");
        }
        return "Your password has been changed successfully. Please login with your new password. A confirmation email has been sent.";
    }

    @Override
    public Employee findEmployeeProfileByJwt(String jwt) {
        try {
            String employeeEmail = jwtHelper.getUsernameFromToken(jwt);
            log.info("Extracted employee email from JWT: {}", employeeEmail);

            Employee employee = employeeRepository.findByEmail(employeeEmail)
                    .orElseThrow(() -> new EmployeeNotFoundException("Employee", "email", employeeEmail));

            log.info("Employee found with email: {}", employee.getEmail());
            return employee;

        } catch (JwtException ex) {
            log.error("Invalid JWT token: {}", ex.getMessage());
            throw new InvalidTokenException("Invalid JWT token", ex);
        } catch (EmployeeNotFoundException ex) {
            log.error("Employee not found: {}", ex.getMessage());
            throw ex;
        } catch (Exception ex) {
            log.error("Error fetching employee profile: {}", ex.getMessage());
            throw new RuntimeException("An error occurred while fetching the employee profile", ex);
        }
    }

    @Override
    public Employee updateFcmToken(Long employeeId, RequestFcmToken requestFcmToken) {
        String fcmToken = requestFcmToken.getFcmToken();
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee", "id", employeeId));
        employee.setFcmToken(fcmToken);
        return employeeRepository.saveAndFlush(employee);
    }

    @Override
    public List<EmployeeDTO> getAllEmployee() {
        try {
            List<Employee> employees = employeeRepository.findAll();

            if (employees.isEmpty()) {
                throw new ResourceNotFoundException("Employee", "id", "No employees found");
            }

            // map Employee entities to EmployeeDTO
            return employees.stream()
                    .map(employee -> {
                        List<RoleDTO> roleDTOs = employee.getRole().stream()
                                .map(role -> {
                                    RoleDTO roleDTO = new RoleDTO();
                                    roleDTO.setId(role.getId());
                                    roleDTO.setRoleName(role.getRoleName());
                                    return roleDTO;
                                })
                                .collect(Collectors.toList());

                        EmployeeDTO employeeDTO = new EmployeeDTO();
                        employeeDTO.setId(employee.getId());
                        employeeDTO.setEmployeeId(employee.getEmployeeId());
                        employeeDTO.setEmployeeName(employee.getEmployeeName());
                        employeeDTO.setFatherName(employee.getFatherName());
                        employeeDTO.setDepartment(employee.getDepartment());
                        employeeDTO.setAddress(employee.getAddress());
                        employeeDTO.setEmail(employee.getEmail());
                        employeeDTO.setMobileNo(employee.getMobileNo());
                        employeeDTO.setDateOfBirth(employee.getDateOfBirth());
                        employeeDTO.setUserName(employee.getUsername());
                        employeeDTO.setEmailVerified(employee.isEmailVerified());
                        employeeDTO.setVerified(employee.isVerified());
                        employeeDTO.setSuspendedStatus(employee.getSuspendedStatus());
                        employeeDTO.setRoles(roleDTOs);
                        employeeDTO.setEmployeePersonalDetails(employee.getEmployeePersonalDetails());
                        return employeeDTO;
                    })
                    .collect(Collectors.toList());
        } catch (Exception ex) {
            log.error("Error occurred while fetching employees", ex);
            throw new RuntimeException("An error occurred while fetching the employee details", ex);
        }
    }

    @Override
    public Employee findByUserId(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee", "id", id));
    }

    @Override
    public boolean isEmailExists(String email) {
        return employeeRepository.existsByEmail(email);
    }

    @Override
    public boolean isMobileNumberExists(String mobileNo) {
        return employeeRepository.existsByMobileNo(mobileNo);
    }

    @Override
    public boolean isUserNameExists(String userName) {
        return employeeRepository.existsByUserName(userName);
    }

    private void handleFileUpload(MultipartFile userPicture, Employee employee) {
        if (userPicture.getSize() > MAX_FILE_SIZE) {
            throw new IllegalArgumentException("file size exceeds 200KB");
        }

        String originalFilename = userPicture.getOriginalFilename();
        if (originalFilename == null || !originalFilename.contains(".")) {
            throw new IllegalArgumentException("invalid file format");
        }

        // generate unique file name using UUID
        String fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
        String newFileName = "empPicture_" + UUID.randomUUID() + fileExtension;

        try {
            // Create directory path
            Path directoryPath = Paths.get(uploadDir);

            // ensure the directory exists (create if not)
            if (!Files.exists(directoryPath)) {
                Files.createDirectories(directoryPath);
            }

            // create the full path where the file will be stored
            Path filePath = directoryPath.resolve(newFileName);

            // write the file to the disk
            Files.write(filePath, userPicture.getBytes());

            // Generate URL for the file
            String fileUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                    .path("/empSignupProfilePic/")
                    .path(newFileName)
                    .toUriString();

            // set the URL in the employee object
            employee.setUserPicture(fileUrl);
        } catch (IOException e) {
            throw new RuntimeException("failed to store file: " + e.getMessage(), e);
        }
    }

}
