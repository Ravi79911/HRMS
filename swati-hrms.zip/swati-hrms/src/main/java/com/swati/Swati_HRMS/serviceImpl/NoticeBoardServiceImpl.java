package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.HolidayMaster;
import com.swati.Swati_HRMS.model.NoticeBoard;
import com.swati.Swati_HRMS.repository.HolidayMasterRepository;
import com.swati.Swati_HRMS.repository.NoticeBoardRepository;
import com.swati.Swati_HRMS.service.NoticeBoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class NoticeBoardServiceImpl implements NoticeBoardService {

    @Autowired
    private NoticeBoardRepository noticeRepository;

    @Autowired
    private HolidayMasterRepository holidayRepository;

    @Override
    public List<NoticeBoard> getUpcomingHolidayNotices() {
        LocalDate today = LocalDate.now();

        // Fetch upcoming holidays
        List<HolidayMaster> upcomingHolidays = holidayRepository.findByDateFromAfter(today);

        // Get list of holiday IDs that already have associated notices
        List<Long> holidayIdsWithNotices = noticeRepository.findByHolidayMasterIsNotNull()
                .stream()
                .map(notice -> notice.getHolidayMaster().getId())
                .collect(Collectors.toList());

        // Convert Holidays to Notices (only for holidays without existing notices)
        List<NoticeBoard> notices = new ArrayList<>();
        for (HolidayMaster holiday : upcomingHolidays) {
            // Skip if a notice for this holiday already exists
            if (holidayIdsWithNotices.contains(holiday.getId())) {
                // Fetch the existing notice to return it
                NoticeBoard existingNotice = noticeRepository.findByHolidayMasterId(holiday.getId());
                if (existingNotice != null) {
                    notices.add(existingNotice);
                }
                continue;
            }

            // Create new notice only if one doesn't exist
            NoticeBoard notice = new NoticeBoard();
            notice.setNoticeName("Upcoming Holiday: " + holiday.getNameOfHoliday());
            notice.setDescription("This is a reminder for " + holiday.getNameOfHoliday());
            notice.setCreatedBy(holiday.getCreatedBy());
            notice.setCreatedDate(LocalDateTime.now());
            notice.setSuspendedStatus(0L);
            notice.setHolidayMaster(holiday);

            // Save the new notice
            noticeRepository.save(notice);
            notices.add(notice);
        }
        return notices;
    }

    @Override
    public NoticeBoard createNotice(NoticeBoard noticeBoard) {
      noticeBoard.setCreatedDate(LocalDateTime.now());
      noticeBoard.setSuspendedStatus(0L);
      return noticeRepository.saveAndFlush(noticeBoard);
    }
}

