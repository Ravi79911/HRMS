package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.LeaveWorkFlow;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface LeaveWorkFlowService {

    List<LeaveWorkFlow> getAllLeaveWorkFlow();
    LeaveWorkFlow handleLeaveWorkFlowForProjectManager(LeaveWorkFlow leaveWorkFlow);
    LeaveWorkFlow handleLeaveWorkFlowForHR(LeaveWorkFlow leaveWorkFlow);
}
