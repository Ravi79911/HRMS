package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.EventCalendarMaster;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface EventCalendarMasterService {

    EventCalendarMaster saveEventCalendarMaster(EventCalendarMaster eventCalendarMaster);
    Optional<EventCalendarMaster> getEventCalendarMasterById(Long id);
    Optional<EventCalendarMaster> updateEventCalendarMaster(Long id, EventCalendarMaster eventCalendarMaster);
    Optional<EventCalendarMaster> changeStatusOfEventCalendarMasterById(Long id);
    String deleteEventCalendarMasterById(Long id);
    List<EventCalendarMaster> getAllEventCalendarMaster();
}
