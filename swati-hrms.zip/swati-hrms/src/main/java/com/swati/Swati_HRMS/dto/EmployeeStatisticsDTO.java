package com.swati.Swati_HRMS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class EmployeeStatisticsDTO {
    private Long totalEmployees;
    private Long maleCount;
    private Long femaleCount;
    private Long otherCount;
}
