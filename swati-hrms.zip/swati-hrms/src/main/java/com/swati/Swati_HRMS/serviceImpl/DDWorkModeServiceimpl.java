package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.DDWorkMode;
import com.swati.Swati_HRMS.repository.DDWorkModeRepository;
import com.swati.Swati_HRMS.service.DDWorkModeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class DDWorkModeServiceimpl implements DDWorkModeService {

    @Autowired
    private DDWorkModeRepository ddWorkModeRepository;

    @Override
    public DDWorkMode saveDDWorkMode(DDWorkMode ddWorkMode) {
        ddWorkMode.setCreatedDate(LocalDateTime.now());
        ddWorkMode.setSuspendedStatus(0);
        return ddWorkModeRepository.save(ddWorkMode);
    }

    @Override
    public List<DDWorkMode> getAllDDWorkMode() {
        return ddWorkModeRepository.findBySuspendedStatus(0);
    }

    @Override
    public Optional<DDWorkMode> getDDWorkModeById(Long id) {
        return ddWorkModeRepository.findById(id);
    }

    @Override
    public String deleteDDWorkMode(Long id) {
        Optional<DDWorkMode> ddWorkMode = ddWorkModeRepository.findById(id);
        if(ddWorkMode.isPresent()) {
            ddWorkMode.get().setSuspendedStatus(1);
            ddWorkModeRepository.save(ddWorkMode.get());
            return "Deleted";
        } else {
            return "Not Found";
        }
    }
}
