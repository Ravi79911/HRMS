package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "holiday_master")
public class HolidayMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name_of_holiday", length = 255)
    private String nameOfHoliday;

    @Column(name = "date_to")
    private LocalDate dateTo;  // Changed to LocalTime to store only time

    @Column(name = "date_from")
    private LocalDate dateFrom;  // This will store only date

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;

}
