package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.dto.EmployeePfCalculationDTO;
import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.model.EmployeePayroll;
import com.swati.Swati_HRMS.model.EmployeePayrollSetup;
import com.swati.Swati_HRMS.repository.EmployeePayrollSetupRepository;
import com.swati.Swati_HRMS.service.EmployeePfCalculationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Month;
import java.time.YearMonth;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/employee/pf/calculation")
public class EmployeePfCalculationController {

    @Autowired
    private EmployeePfCalculationService pfcalculationService;

    @Autowired
    private EmployeePayrollSetupRepository payrollSetupRepository;


    @PostMapping("/saveEmployeePfCalculation")
    public ResponseEntity<?> saveEmployeePfCalculation(@RequestParam Long EmployeePersonalInfoId,
                                                         @RequestParam String month,
                                                         @RequestParam Integer year) {

        //  Validate month and year are not current or future
        if (!isValidHistoricalDate(month, year)) {
            ApiResponse errorResponse = ApiResponse.failure("Cannot process current or future months", "INVALID_DATE_RANGE");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
        ApiResponse response = ApiResponse.success("Employee Pf Calculation saved successfully", pfcalculationService.calculatePf(EmployeePersonalInfoId, month, year));
        return ResponseEntity.ok(response);
    }


//    @GetMapping("/getAll")
//    public ResponseEntity<List<EmployeePfCalculationDTO>> getAllPayrolls() {
//        List<EmployeePfCalculationDTO> payrolls = pfcalculationService.getAllPayrolls();
//        return ResponseEntity.ok(payrolls);
//    }
//
//    @GetMapping("/getByEmployeePersonalIdMonthAndByYear")
//    public ResponseEntity<?> getPayrollByEmpCodeAndPeriod(
//            @RequestParam Long employeePersonalId,
//            @RequestParam String month,
//            @RequestParam Integer year) {
//
//        //  Validate month and year are not current or future
//        if (!isValidHistoricalDate(month, year)) {
//            ApiResponse errorResponse = ApiResponse.failure("Cannot process current or future months", "INVALID_DATE_RANGE");
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
//        }
//
//        // Find the payroll setup by ID
//        Optional<EmployeePayrollSetup> payrollSetupOptional = payrollSetupRepository.findByEmployee_Id(employeePersonalId);
//
//        // Return 404 if the payroll setup doesn't exist
//        if (!payrollSetupOptional.isPresent()) {
//            return ResponseEntity.notFound().build();
//        }
//
//        // Get the payroll setup from the Optional
//        EmployeePayrollSetup payrollSetup = payrollSetupOptional.get();
//
//        return new ResponseEntity<>(pfcalculationService.getPayrollByEmpCodeAndPeriod(payrollSetup.getEmployee().getEmployeeId(), month, year), HttpStatus.OK);
//
//    }

    @GetMapping("/getByEmployeeCodeAndMonthAndYear")
    public ResponseEntity<?> getPayrollByEmpCodeAndPeriod(
            @RequestParam String employeeCode,
            @RequestParam String month,
            @RequestParam Integer year) {

        //  Validate month and year are not current or future
        if (!isValidHistoricalDate(month, year)) {
            ApiResponse errorResponse = ApiResponse.failure("Cannot process current or future months", "INVALID_DATE_RANGE");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }

        return new ResponseEntity<>(pfcalculationService.getEmployeePfCalculationByEmpCode(employeeCode, month, year), HttpStatus.OK);
    }

//    @GetMapping("/employee/{empCode}")
//    public ResponseEntity<List<EmployeePfCalculationDTO>> getPayrollsByEmpCode(
//            @PathVariable String empCode) {
//
//        List<EmployeePfCalculationDTO> payrolls = pfcalculationService.getPayrollsByEmpCode(empCode);
//        return ResponseEntity.ok(payrolls);
//    }
//
//    @GetMapping("/period")
//    public ResponseEntity<List<EmployeePfCalculationDTO>> getPayrollsByPeriod(
//            @RequestParam String month,
//            @RequestParam Integer year) {
//
//        List<EmployeePfCalculationDTO> payrolls = pfcalculationService.getPayrollsByPeriod(month, year);
//        return ResponseEntity.ok(payrolls);
//    }

    private boolean isValidHistoricalDate(String monthStr, Integer year) {
        try {
            // Convert month string to Month enum (case insensitive)
            Month requestMonth = Month.valueOf(monthStr.toUpperCase());
            YearMonth requestYearMonth = YearMonth.of(year, requestMonth);
            YearMonth currentYearMonth = YearMonth.now();

            // Check if the requested year is future
            if (year > currentYearMonth.getYear()) {
                return false;
            }

            // If same year, ensure the month is before current month
            if (year.equals(currentYearMonth.getYear())) {
                return requestMonth.getValue() < currentYearMonth.getMonth().getValue();
            }

            // Past years are always valid
            return true;
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid month provided: " + monthStr);
            return false;
        }
    }

//    @GetMapping("/getByDepartmentMonthAndYear")
//    public ResponseEntity<List<?>> getEmployeePayrollsByDepartment(
//            @RequestParam String department,
//            @RequestParam String month,
//            @RequestParam Integer year) {
//
//        //  Validate month and year are not current or future
//        if (!isValidHistoricalDate(month, year)) {
//            ApiResponse errorResponse = ApiResponse.failure("Cannot process current or future months", "INVALID_DATE_RANGE");
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.singletonList(errorResponse));
//        }
//        return ResponseEntity.ok(pfcalculationService.getEmployeePayrollsByDepartment(department, month, year));
//    }
//
//    @PutMapping("/updateById")
//    public ResponseEntity<?> updatePayrollAndApprove(
//            @RequestParam Long payrollId,
//            @RequestBody EmployeePayroll updatedPayrollData) {
//
//        try {
//            Optional<EmployeePfCalculationDTO> response = pfcalculationService.updatePayrollAndApprovedStatus(payrollId, updatedPayrollData);
//
//            if (response.isPresent()) {
//                return ResponseEntity.ok(response.get());
//            } else {
//                return ResponseEntity.notFound().build();
//            }        } catch (Exception e) {
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
//        }
//    }

    @PatchMapping("/verifyPF/{pfCalculationId}")
    public ResponseEntity<?> verifyPF(@PathVariable Long pfCalculationId) {
        ApiResponse response= ApiResponse.success("PF verified successfully", pfcalculationService.verifyPfCalculation(pfCalculationId));
        return ResponseEntity.ok(response);

    }

    @DeleteMapping("/deletePF/{pfCalculationId}")
    public ResponseEntity<?> deletePF(@PathVariable Long pfCalculationId) {
        ApiResponse response = ApiResponse.success("PF deleted successfully", pfcalculationService.deletePfCalculation(pfCalculationId));
        return ResponseEntity.ok(response);
    }
}
