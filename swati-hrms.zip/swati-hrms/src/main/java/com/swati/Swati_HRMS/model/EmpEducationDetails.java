package com.swati.Swati_HRMS.model;


import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "emp_education_details")
public class EmpEducationDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "university_board")
	private String universityBoard;

	@Column(name = "passing_year")
	private String passingYear;

	@Column(name = "cgpa_percentage")
	private String cgpaPercentage;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private LocalDateTime createdDate;

	@Column(name = "updated_by")
	private String updatedBy;

	@Column(name = "updated_date")
	private LocalDateTime updatedDate;

	@Column(name = "suspendend_status")
	private int suspendedStatus;

	@ManyToOne
	@JoinColumn(name = "emp_master_id", referencedColumnName = "id", nullable = false)
	private EmployeePersonalDetails employeePersonalDetails;

	@ManyToOne 
	@JoinColumn(name = "degree_id", referencedColumnName = "id")
	private DegreeList degree; // Changed to Degree object

	@ManyToOne
	@JoinColumn(name = "stream_cource_id", referencedColumnName = "id")
	private StreamList streamCourse; // Changed to Streams object

}
