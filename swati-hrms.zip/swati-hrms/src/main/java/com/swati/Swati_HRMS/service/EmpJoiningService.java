package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.dto.EmpJoiningDetailsDTO;
import com.swati.Swati_HRMS.dto.EmployeeExperienceDetailsDTO;
import com.swati.Swati_HRMS.model.EmpJoiningDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface EmpJoiningService {

    EmpJoiningDetails saveEmpJoining(EmpJoiningDetails empJoiningDetails);
    List<EmpJoiningDetailsDTO> getEmployeeKeySkillByEmployeePesronalDetailsId(Long id);
}
