package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.model.DDOfficeWorkingLocation;
import com.swati.Swati_HRMS.service.DDOfficeWorkingLocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/dd/office/working/location")
public class DDOfficeWorkingLocationController {

    @Autowired
    private DDOfficeWorkingLocationService ddOfficeWorkingLocationService;

    @PostMapping("/saveOfficeWorkingLocation")
    public ResponseEntity<?> saveOfficeWorkingLocation(@RequestBody DDOfficeWorkingLocation ddOfficeWorkingLocation) {
        ApiResponse response= ApiResponse.success("Office Working Location saved successfully", ddOfficeWorkingLocationService.saveDDOfficeWorkingLocation(ddOfficeWorkingLocation));
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getAllOfficeWorkingLocation")
    public ResponseEntity<?> getAllOfficeWorkingLocation() {
        ApiResponse response= ApiResponse.success("Office Working Location fetched successfully", ddOfficeWorkingLocationService.getAllDDOfficeWorkingLocation());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getOfficeWorkingLocationById/{id}")
    public ResponseEntity<?> getOfficeWorkingLocationById(@PathVariable Long id) {
        ApiResponse response= ApiResponse.success("Office Working Location fetched successfully", ddOfficeWorkingLocationService.getDDOfficeWorkingLocationById(id));
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/deleteOfficeWorkingLocationById/{id}")
    public ResponseEntity<?> deleteOfficeWorkingLocationById(@PathVariable Long id) {
        ApiResponse response= ApiResponse.success("Office Working Location deleted successfully", ddOfficeWorkingLocationService.deleteDDOfficeWorkingLocationById(id));
        return ResponseEntity.ok(response);
    }
}
