package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.dto.EmployeeStatisticsDTO;
import com.swati.Swati_HRMS.exception.EmployeeNotFoundException;
import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import com.swati.Swati_HRMS.repository.EmployeePersonalDetailsRepository;
import com.swati.Swati_HRMS.service.EmployeePersonalDetailsService;
import com.swati.Swati_HRMS.utils.EmployeeIdGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeePersonalDetailsServiceImpl implements EmployeePersonalDetailsService {

    @Autowired
    EmployeePersonalDetailsRepository employeePersonalDetailsRepository;

    @Autowired
    EmployeeIdGenerator employeeIdGenerator;

    @Override
    public EmployeePersonalDetails saveEmployeePersonalDetails(EmployeePersonalDetails employeePersonalDetails) {
        String employeeId = employeeIdGenerator.generateEmployeeId();
        employeePersonalDetails.setEmployeeId(employeeId);
        employeePersonalDetails.setUpdatedBy(employeePersonalDetails.getUpdatedBy() != null ? employeePersonalDetails.getUpdatedBy() : 0);
        employeePersonalDetails.setSuspendedStatus(employeePersonalDetails.getSuspendedStatus() != null ? employeePersonalDetails.getSuspendedStatus() : 0);
        employeePersonalDetails.setCreatedDate(LocalDateTime.now());
        employeePersonalDetails.setUpdatedDate(LocalDateTime.now());
        return employeePersonalDetailsRepository.saveAndFlush(employeePersonalDetails);
    }

    @Override
    public Optional<EmployeePersonalDetails> updateEmployeePersonalDetails(Long id, EmployeePersonalDetails employeePersonalDetails) {
        return employeePersonalDetailsRepository.findById(id).map(existingEmployee -> {

            // update fields only if they are provided (non-null) in the input
            if (employeePersonalDetails.getOfficeWorkingLocation() != null) {
                existingEmployee.setOfficeWorkingLocation(employeePersonalDetails.getOfficeWorkingLocation());
            }
            if (employeePersonalDetails.getWorkMode() != null) {
                existingEmployee.setWorkMode(employeePersonalDetails.getWorkMode());
            }
            if (employeePersonalDetails.getEmployeeFirstName() != null) {
                existingEmployee.setEmployeeFirstName(employeePersonalDetails.getEmployeeFirstName());
            }
            if (employeePersonalDetails.getEmployeeLastName() != null) {
                existingEmployee.setEmployeeLastName(employeePersonalDetails.getEmployeeLastName());
            }
            if (employeePersonalDetails.getEmployeeFatherName() != null) {
                existingEmployee.setEmployeeFatherName(employeePersonalDetails.getEmployeeFatherName());
            }
            if (employeePersonalDetails.getEmployeeMotherName() != null) {
                existingEmployee.setEmployeeMotherName(employeePersonalDetails.getEmployeeMotherName());
            }
            if (employeePersonalDetails.getDob() != null) {
                existingEmployee.setDob(employeePersonalDetails.getDob());
            }
            if (employeePersonalDetails.getGender() != null) {
                existingEmployee.setGender(employeePersonalDetails.getGender());
            }
            if (employeePersonalDetails.getMobileNo() != null) {
                existingEmployee.setMobileNo(employeePersonalDetails.getMobileNo());
            }
            if (employeePersonalDetails.getEmail() != null) {
                existingEmployee.setEmail(employeePersonalDetails.getEmail());
            }
            if (employeePersonalDetails.getGuardianMobNo() != null) {
                existingEmployee.setGuardianMobNo(employeePersonalDetails.getGuardianMobNo());
            }
            if (employeePersonalDetails.getAadhaarNo() != null) {
                existingEmployee.setAadhaarNo(employeePersonalDetails.getAadhaarNo());
            }
            if (employeePersonalDetails.getPanNo() != null) {
                existingEmployee.setPanNo(employeePersonalDetails.getPanNo());
            }
            if (employeePersonalDetails.getLocalAddress() != null) {
                existingEmployee.setLocalAddress(employeePersonalDetails.getLocalAddress());
            }
            if (employeePersonalDetails.getLocalPinCode() != null) {
                existingEmployee.setLocalPinCode(employeePersonalDetails.getLocalPinCode());
            }
            if (employeePersonalDetails.getLocalCity() != null) {
                existingEmployee.setLocalCity(employeePersonalDetails.getLocalCity());
            }
            if (employeePersonalDetails.getLocalState() != null) {
                existingEmployee.setLocalState(employeePersonalDetails.getLocalState());
            }
            if (employeePersonalDetails.getLocalCountry() != null) {
                existingEmployee.setLocalCountry(employeePersonalDetails.getLocalCountry());
            }
            if (employeePersonalDetails.getPermanentAddress() != null) {
                existingEmployee.setPermanentAddress(employeePersonalDetails.getPermanentAddress());
            }
            if (employeePersonalDetails.getPermanentPinCode() != null) {
                existingEmployee.setPermanentPinCode(employeePersonalDetails.getPermanentPinCode());
            }
            if (employeePersonalDetails.getPermanentCity() != null) {
                existingEmployee.setPermanentCity(employeePersonalDetails.getPermanentCity());
            }
            if (employeePersonalDetails.getPermanentState() != null) {
                existingEmployee.setPermanentState(employeePersonalDetails.getPermanentState());
            }
            if (employeePersonalDetails.getPermanentCountry() != null) {
                existingEmployee.setPermanentCountry(employeePersonalDetails.getPermanentCountry());
            }

            // set updated date and save the changes
            existingEmployee.setUpdatedDate(LocalDateTime.now());
            existingEmployee.setUpdatedBy(employeePersonalDetails.getUpdatedBy());


            employeePersonalDetailsRepository.save(existingEmployee);
            return existingEmployee;
        });
    }

    @Override
    public Optional<EmployeePersonalDetails> changeStatusOfDocumentById(Long id) {
        Optional<EmployeePersonalDetails> employeePersonalDetails = employeePersonalDetailsRepository.findById(id);
        if (employeePersonalDetails.isPresent()) {
            EmployeePersonalDetails employeePersonalDetails1 = employeePersonalDetails.get();
            employeePersonalDetails1.setSuspendedStatus(1);
            employeePersonalDetailsRepository.save(employeePersonalDetails1);
            return employeePersonalDetails;
        }
        return Optional.empty();
    }

    @Override
    public EmployeePersonalDetails findByEmployeeId(String employeeId) {
        return employeePersonalDetailsRepository.findByEmployeeId(employeeId)
                .orElseThrow(() -> new EmployeeNotFoundException("Employee not found with id: " + employeeId));
    }

    @Override
    public List<EmployeePersonalDetails> getAllDocument() {
        return employeePersonalDetailsRepository.findBySuspendedStatus(0);
    }

    @Override
    public Optional<EmployeePersonalDetails> getEmployeeWithSkills(Long id) {
        return employeePersonalDetailsRepository.findById(id);
    }

    @Override
    public EmployeeStatisticsDTO getEmployeeStatistics() {
        Long totalEmployees = employeePersonalDetailsRepository.countActiveEmployees();
        Long maleCount = employeePersonalDetailsRepository.countByGender("Male");
        Long femaleCount = employeePersonalDetailsRepository.countByGender("Female");
        Long otherCount = employeePersonalDetailsRepository.countByGender("Other");

        return new EmployeeStatisticsDTO(totalEmployees, maleCount, femaleCount, otherCount);
    }

    @Override
    public Long getEmployeeCountForDepartmentById(Long departmentId) {
        return employeePersonalDetailsRepository.countByDepartmentId(departmentId);
    }

}
