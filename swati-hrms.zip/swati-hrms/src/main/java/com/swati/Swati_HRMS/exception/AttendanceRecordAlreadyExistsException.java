package com.swati.Swati_HRMS.exception;

public class AttendanceRecordAlreadyExistsException extends RuntimeException {
    public AttendanceRecordAlreadyExistsException(String message) {
        super(message);
    }
}
