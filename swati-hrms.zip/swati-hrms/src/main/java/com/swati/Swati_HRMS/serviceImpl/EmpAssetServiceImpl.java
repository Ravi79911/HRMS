package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.EmpAsset;
import com.swati.Swati_HRMS.repository.EmpAssetRepository;
import com.swati.Swati_HRMS.service.EmpAssetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class EmpAssetServiceImpl implements EmpAssetService {

    @Autowired
    private EmpAssetRepository empAssetRepository;

    @Override
    public EmpAsset saveEmpAsset(EmpAsset empAsset) {
        empAsset.setCreatedDate(LocalDateTime.now());
        empAsset.setSuspendedStatus(0);
        empAsset.setAssignDate(LocalDate.now());
        return empAssetRepository.save(empAsset);
    }

    @Override
    public Optional<EmpAsset> getEmpAssetById(Long id) {
        return empAssetRepository.findById(id);
    }

    @Override
    public Optional<EmpAsset> updateEmpAsset(Long id, EmpAsset empAsset) {
       Optional<EmpAsset> existingempAsset = empAssetRepository.findById(id);
       if (existingempAsset.isPresent()) {
           existingempAsset.get().setDdAssetName(empAsset.getDdAssetName());
           existingempAsset.get().setAssetSerialNo(empAsset.getAssetSerialNo());
           existingempAsset.get().setAssetTag(empAsset.getAssetTag());
           existingempAsset.get().setCondition(empAsset.getCondition());
           existingempAsset.get().setAssignDate(empAsset.getAssignDate());
           existingempAsset.get().setReturnDate(empAsset.getReturnDate());
           existingempAsset.get().setIssuedBy(empAsset.getIssuedBy());
           existingempAsset.get().setSuspendedStatus(empAsset.getSuspendedStatus());
           return Optional.of(empAssetRepository.save(existingempAsset.get()));
    }
        return Optional.empty();
    }

    @Override
    public Optional<EmpAsset> changeStatusOfEmpAssetById(Long id) {
        Optional<EmpAsset> empAsset = empAssetRepository.findById(id);
        if (empAsset.isPresent()) {
            empAsset.get().setSuspendedStatus(1);
            return Optional.of(empAssetRepository.save(empAsset.get()));
        }else {
            return Optional.empty();
        }
    }

    @Override
    public List<EmpAsset> getAllEmpAsset() {
        return empAssetRepository.findAll();
    }

    @Override
    public List<EmpAsset> findByAssetByEmployeeId(Long id) {
        return empAssetRepository.findByEmployeePersonalDetails_Id(id);
    }
}
