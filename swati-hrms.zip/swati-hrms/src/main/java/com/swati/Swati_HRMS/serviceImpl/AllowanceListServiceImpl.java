package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.AllowanceList;
import com.swati.Swati_HRMS.repository.AllowanceListRepository;
import com.swati.Swati_HRMS.service.AllowanceListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class AllowanceListServiceImpl implements AllowanceListService {

    @Autowired
    private AllowanceListRepository allowanceListRepository;

    @Override
    public AllowanceList save(AllowanceList allowanceList) {
        allowanceList.setCreatedDate(LocalDateTime.now());
        allowanceList.setSuspendedStatus(0);
        return allowanceListRepository.save(allowanceList);
    }

    @Override
    public Optional<AllowanceList> updateAllowanceList(Long id, AllowanceList allowanceList) {
       Optional<AllowanceList> allowanceList1 = allowanceListRepository.findById(id);
       if(allowanceList1.isPresent()){
           allowanceList1.get().setAllowanceName(allowanceList.getAllowanceName());
           allowanceList1.get().setAllowanceValue(allowanceList.getAllowanceValue());
           allowanceList1.get().setCalculationType(allowanceList.getCalculationType());
           allowanceList1.get().setUpdatedDate(LocalDateTime.now());
           allowanceList1.get().setUpdatedBy(allowanceList.getUpdatedBy());
           allowanceListRepository.save(allowanceList1.get());
           return allowanceList1;
       }
       return Optional.empty();
    }

    @Override
    public List<AllowanceList> getAllAllowanceList() {
       return allowanceListRepository.findBySuspendedStatus(0);
    }

    @Override
    public Optional<AllowanceList> deleteAllowanceListById(Long id) {

        Optional<AllowanceList> allowanceList = allowanceListRepository.findById(id);
        if(allowanceList.isPresent()){
            allowanceList.get().setSuspendedStatus(1);
            allowanceListRepository.save(allowanceList.get());
            return allowanceList;
        }
        return Optional.empty();
    }
}
