package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.exception.AttendanceRecordAlreadyExistsException;
import com.swati.Swati_HRMS.model.EmployeeAttendance;
import com.swati.Swati_HRMS.serviceImpl.ExcelImportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/attendance")
public class AttendanceController {

    @Autowired
    private ExcelImportService excelImportService;

    @PostMapping("/import")
    public ResponseEntity<String> importAttendance(@RequestParam("file") MultipartFile file) {
        try {
            // Call the service method to process the attendance file
            excelImportService.importAttendance(file);
            return ResponseEntity.status(HttpStatus.OK).body("Attendance data imported successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to import attendance data: " + e.getMessage());
        }
    }




    @GetMapping
    public ResponseEntity<List<EmployeeAttendance>> getAllAttendanceRecords() {
        List<EmployeeAttendance> records = excelImportService.getAllAttendanceRecords();
        return ResponseEntity.ok(records);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EmployeeAttendance> getAttendanceById(@PathVariable Long id) {
        EmployeeAttendance record = excelImportService.getAttendanceById(id);
        return ResponseEntity.ok(record);
    }

    @GetMapping("/employee/{employeeId}")
    public ResponseEntity<List<EmployeeAttendance>> getAttendanceByEmployeeId(
            @PathVariable Integer employeeId) {
        List<EmployeeAttendance> records = excelImportService.getAttendanceByEmployeeId(employeeId);
        return ResponseEntity.ok(records);
    }

    @GetMapping("/month/{month}")
    public ResponseEntity<List<EmployeeAttendance>> getAttendanceByMonth(
            @PathVariable String month) {
        List<EmployeeAttendance> records = excelImportService.getAttendanceByMonth(month);
        return ResponseEntity.ok(records);
    }

    @GetMapping("/search")
    public ResponseEntity<Optional<EmployeeAttendance>> getAttendanceByEmployeeIdAndMonth(
            @RequestParam Integer employeeId,
            @RequestParam String month) {
        Optional<EmployeeAttendance> records = excelImportService.getAttendanceByEmployeeIdAndMonth(employeeId, month);
        return ResponseEntity.ok(records);
    }

    @GetMapping("/getByEmployeePesonalDetailsId/{id}")
    public ResponseEntity<List<EmployeeAttendance>> getAttendanceByEmployeePersonalDetailsId(@PathVariable Long id) {
        List<EmployeeAttendance> records = excelImportService.getAttendanceByEmployeePersonalDetailsId(Math.toIntExact(id));
        return ResponseEntity.ok(records);
    }

    @GetMapping("/getByMonthAndYear/{month}/{year}")
    public ResponseEntity<List<EmployeeAttendance>> getAttendanceByMonthAndYear(@PathVariable String month, @PathVariable Integer year) {
        List<EmployeeAttendance> records = excelImportService.getAttendanceByMonthAndYear(month, year);
        return ResponseEntity.ok(records);
    }

    @GetMapping("/getByMonthAndYearAndEmployeeId/{month}/{year}/{employeeId}")
    public ResponseEntity<Optional<EmployeeAttendance>> getAttendanceByMonthAndYearAndEmployeeId(@PathVariable String month, @PathVariable Integer year, @PathVariable Integer employeeId) {
        Optional<EmployeeAttendance> records = excelImportService.getAttendanceByEmployeeIdAndMonthAndYear(employeeId, month, year);
        return ResponseEntity.ok(records);
    }

    @GetMapping("/getByYear/{year}")
    public ResponseEntity<List<EmployeeAttendance>> getAttendanceByYear(@PathVariable Integer year) {
        List<EmployeeAttendance> records = excelImportService.getAttendanceByYear(year);
        return ResponseEntity.ok(records);
    }
}