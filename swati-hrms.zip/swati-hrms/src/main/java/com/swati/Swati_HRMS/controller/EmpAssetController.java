package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.model.EmpAsset;
import com.swati.Swati_HRMS.service.EmpAssetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/empAsset")
public class EmpAssetController {

    @Autowired
    private EmpAssetService empAssetService;

    @PostMapping("/saveEmpAsset")
    public ResponseEntity<?> saveEmpAsset(@RequestBody EmpAsset empAsset){
        ApiResponse response = ApiResponse.success("Employee Asset saved successfully", empAssetService.saveEmpAsset(empAsset));
        return ResponseEntity.ok(response);
    }

    @PutMapping("/updateEmpAsset/{id}")
    public ResponseEntity<?> updateEmpAsset(@PathVariable Long id, @RequestBody EmpAsset empAsset){
        ApiResponse response = ApiResponse.success("Employee Asset updated successfully", empAssetService.updateEmpAsset(id, empAsset));
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getEmpAssetById/{id}")
    public ResponseEntity<?> getEmpAssetById(@PathVariable Long id){
        ApiResponse response = ApiResponse.success("Employee Asset fetched successfully", empAssetService.getEmpAssetById(id));
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getAllEmpAsset")
    public ResponseEntity<?> getAllEmpAsset(){
        ApiResponse response = ApiResponse.success("Employee Asset fetched successfully", empAssetService.getAllEmpAsset());
        return ResponseEntity.ok(response);
    }

    @PatchMapping("/changeStatusOfEmpAssetById/{id}")
    public ResponseEntity<?> changeStatusOfEmpAssetById(@PathVariable Long id){
        ApiResponse response = ApiResponse.success("Employee Asset status changed successfully", empAssetService.changeStatusOfEmpAssetById(id));
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getEmpAssetByEmpId/{id}")
    public ResponseEntity<List<EmpAsset>> getEmpAssetByEmpId(@PathVariable Long id){
        return ResponseEntity.ok(empAssetService.findByAssetByEmployeeId(id));
    }


}
