package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.model.AllowanceList;
import com.swati.Swati_HRMS.service.AllowanceListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/allowance")
public class AllowanceListController {

    @Autowired
    private AllowanceListService allowanceListService;

    @PostMapping("/save")
    public ResponseEntity<AllowanceList> saveAllowanceList(@RequestBody AllowanceList allowanceList) {
        return ResponseEntity.ok(allowanceListService.save(allowanceList));
    }

    @GetMapping("/all")
    public ResponseEntity<List<AllowanceList>> getAllAllowanceList() {
        return ResponseEntity.ok(allowanceListService.getAllAllowanceList());
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<AllowanceList> updateAllowanceList(@PathVariable Long id, @RequestBody AllowanceList allowanceList) {
        Optional<AllowanceList> updated = allowanceListService.updateAllowanceList(id, allowanceList);
        return updated.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PatchMapping("/deleteBy/{id}")
    public ResponseEntity<AllowanceList> suspendAllowanceList(@PathVariable Long id) {
        Optional<AllowanceList> updated = allowanceListService.deleteAllowanceListById(id);
        return updated.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
