package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.dto.EmployeeKeySkillDTO;
import com.swati.Swati_HRMS.model.EmployeeKeySkill;
import com.swati.Swati_HRMS.repository.EmployeeKeySkillRepository;
import com.swati.Swati_HRMS.service.EmployeeKeySkillService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeKeySkillServiceImpl implements EmployeeKeySkillService {

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private EmployeeKeySkillRepository employeeKeySkillRepository;

    @Override
    public EmployeeKeySkill saveEmployeeKeySkill(EmployeeKeySkill employeeKeySkill) {
        employeeKeySkill.setCreatedDate(LocalDateTime.now());
        employeeKeySkill.setSuspendedStatus(0);
        return employeeKeySkillRepository.save(employeeKeySkill);
    }

    @Override
    public List<EmployeeKeySkillDTO> getEmployeeKeySkillByEmployeePersonalDetailsId(Long id) {
        List<EmployeeKeySkill> employeeKeySkills = employeeKeySkillRepository.findByEmployeePersonalDetails_Id(id);
        return employeeKeySkills.stream()
                .map(skill -> modelMapper.map(skill, EmployeeKeySkillDTO.class))
                .collect(Collectors.toList());
    }
}
