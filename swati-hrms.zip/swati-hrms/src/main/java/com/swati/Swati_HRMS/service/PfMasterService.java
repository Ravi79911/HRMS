package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.PfMaster;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface PfMasterService {

    PfMaster savePfMaster(PfMaster pfMaster);

    List<PfMaster> findAllPfMaster();

    PfMaster updatePfMaster(Long id, PfMaster updatedPfMaster);

}
