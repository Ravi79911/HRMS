package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.Employee;
import com.swati.Swati_HRMS.repository.EmployeeRepository;
import com.swati.Swati_HRMS.service.NotificationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class NotificationServiceImpl implements NotificationService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private FirebaseService firebaseService;

    // scheduled task to send notifications every day at 9 AM
    @Scheduled(cron = "0 0 9 * * ?") // runs at 9 AM every day
    @Override
    public List<String> sendBirthdayNotifications() {
        List<String> birthdayMessages = new ArrayList<>();
        LocalDate today = LocalDate.now();
        LocalDate oneWeekLater = today.plusDays(7);  // next 7 days

        int todayMonth = today.getMonthValue();
        int todayDay = today.getDayOfMonth();

        int endDay = oneWeekLater.getDayOfMonth();

        try {
            // fetch employees whose birthday month matches today's month and the day is within the range (today to one week later)
            List<Employee> employeesWithUpcomingBirthdays = employeeRepository.findByUpcomingBirthdays(todayMonth, todayDay, endDay);

            if (employeesWithUpcomingBirthdays == null || employeesWithUpcomingBirthdays.isEmpty()) {
                return birthdayMessages; // return empty list if no employees found
            }

            for (Employee employee : employeesWithUpcomingBirthdays) {
                String formattedBirthday = employee.getDateOfBirth().format(DateTimeFormatter.ofPattern("MMMM dd")); // format the birthday
                String messageBody = "Don't forget, it's " + employee.getEmployeeName() + "'s birthday on " + formattedBirthday;

                String fcmToken = employee.getFcmToken();
                if (fcmToken != null && !fcmToken.isEmpty()) {
                    try {
                        firebaseService.sendPushNotification(fcmToken, "Upcoming Birthday Reminder!", messageBody);
                        birthdayMessages.add(messageBody);
                    } catch (Exception e) {
                        log.error("Failed to send notification to {}: {}", employee.getEmployeeName(), e.getMessage());
                        birthdayMessages.add("Failed to send notification to " + employee.getEmployeeName() + ": " + e.getMessage());
                    }
                } else {
                    birthdayMessages.add("No FCM token found for " + employee.getEmployeeName());
                }
            }
        } catch (Exception e) {
            log.error("Error fetching employee data or sending notifications: {}", e.getMessage());
            birthdayMessages.add("An error occurred while fetching employee data or sending notifications: " + e.getMessage());
        }
        return birthdayMessages;
    }

}