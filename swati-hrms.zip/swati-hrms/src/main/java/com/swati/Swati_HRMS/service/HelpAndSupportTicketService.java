package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.HelpAndSupportTicket;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface HelpAndSupportTicketService {

    HelpAndSupportTicket createTicket(HelpAndSupportTicket ticket);

    List<HelpAndSupportTicket> getAllTickets();

    Optional<HelpAndSupportTicket> getTicketById(Long id);

    HelpAndSupportTicket updateTicket(Long id, HelpAndSupportTicket ticket);

    boolean resolveTicket(Long id);

    List<HelpAndSupportTicket> getAllTicketsByEmployeeId(Long id);

}
