package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.StreamList;
import com.swati.Swati_HRMS.repository.StreamListRepository;
import com.swati.Swati_HRMS.service.StreamListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class StreamListServiceImpl implements StreamListService {

    @Autowired
    private StreamListRepository streamListRepository;

    @Override
    public StreamList saveStream(StreamList streamList) {
        streamList.setCreatedDate(LocalDateTime.now());
        streamList.setSuspendedStatus(0);
        streamListRepository.save(streamList);
        return streamList;
    }

    @Override
    public List<StreamList> getAllStream() {
        return streamListRepository.findBySuspendedStatus(0);
    }

    @Override
    public StreamList updateStreamById(Long id, StreamList updatedStreamList) {
        Optional<StreamList> streamList = streamListRepository.findById(id);
        if (streamList.isPresent()) {
            StreamList streamList1 = streamList.get();
            streamList1.setUpdatedDate(LocalDateTime.now());
            streamList1.setUpdatedBy(updatedStreamList.getUpdatedBy());
            streamList1.setStream(updatedStreamList.getStream());
            streamListRepository.save(streamList1);
            return streamList1;
        } else {
            return null;
        }
    }

    @Override
    public StreamList changeStatusOfStreamById(Long id) {
        Optional<StreamList> streamList = streamListRepository.findById(id);
        if (streamList.isPresent()) {
            StreamList streamList1 = streamList.get();
            streamList1.setSuspendedStatus(1);
            streamListRepository.save(streamList1);
            return streamList1;
        } else {
            return null;
        }
    }
}
