package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "asset_name_master")
public class DDAssetNameMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment for id
    @Column(name = "id")
    private Long id;

    @Column(name = "asset_name", nullable = false, length = 255)
    private String assetName;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "created_by", nullable = false)
    private Integer createdBy;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;
}
