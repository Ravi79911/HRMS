package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.model.SkillList;
import com.swati.Swati_HRMS.service.SkillListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/skillList")
public class SkillListController {

    @Autowired
    private SkillListService skillListService;

    @PostMapping("/save")
    public ResponseEntity<SkillList> saveSkillList(@RequestBody SkillList skillList){
        return ResponseEntity.ok(skillListService.saveSkill(skillList));
    }

    @GetMapping("/all")
    public ResponseEntity<List<SkillList>> getAllSkillList(){
        return ResponseEntity.ok(skillListService.getAllSkill());
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<SkillList> updateSkillList(@PathVariable Long id, @RequestBody SkillList updatedSkillList) {
        Optional<SkillList> updated = skillListService.updateSkillById(id, updatedSkillList);
        return updated.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PatchMapping("/deleteBy/{id}")
    public ResponseEntity<SkillList> suspendSkillList(@PathVariable Long id) {
        Optional<SkillList> updated = skillListService.changeStatusOfSkillById(id);
        return updated.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
