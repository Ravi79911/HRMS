package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.dto.EmpEducationDetailsDTO;
import com.swati.Swati_HRMS.dto.EmployeeDependentDTO;
import com.swati.Swati_HRMS.model.EmployeeDependent;
import com.swati.Swati_HRMS.service.EmpDependentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/empDependent")
public class EmpDependentController {

    @Autowired
    private EmpDependentService empDependentService;

    @PostMapping("/saveEmpDependent")
    public ResponseEntity<EmployeeDependent> saveEmployeeDependent(@RequestBody EmployeeDependent employeeDependent){
        return ResponseEntity.ok(empDependentService.saveEmployeeDependent(employeeDependent));
    }

    @GetMapping("/findByEmpId/{id}")
    public ResponseEntity<List<EmployeeDependentDTO>>findByEmpId(@PathVariable("id") Long id){
        List<EmployeeDependentDTO> employeeDependentDTO = empDependentService.getEmployeeKeySkillByEmployeePesronalDetailsId(id);
        return ResponseEntity.ok(employeeDependentDTO );

    }
}
