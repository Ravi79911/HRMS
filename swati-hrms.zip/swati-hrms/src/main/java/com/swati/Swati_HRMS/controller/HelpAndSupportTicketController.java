package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.model.HelpAndSupportTicket;
import com.swati.Swati_HRMS.service.HelpAndSupportTicketService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/supportTicket")
public class HelpAndSupportTicketController {

    @Autowired
    private HelpAndSupportTicketService helpAndSupportTicketService;

    // Create a new support ticket
    @PostMapping("/createTicket")
    public ResponseEntity<HelpAndSupportTicket> createTicket(@Valid @RequestBody HelpAndSupportTicket ticket) {
        HelpAndSupportTicket createdTicket = helpAndSupportTicketService.createTicket(ticket);
        return new ResponseEntity<>(createdTicket, HttpStatus.CREATED);
    }

    // Get all support tickets
    @GetMapping("/allTickets")
    public List<HelpAndSupportTicket> getAllTickets() {
        return helpAndSupportTicketService.getAllTickets();
    }

    // Get a ticket by ID
    @GetMapping("/{id}")
    public ResponseEntity<HelpAndSupportTicket> getTicketById(@PathVariable Long id) {
        Optional<HelpAndSupportTicket> ticket = helpAndSupportTicketService.getTicketById(id);
        return ticket.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Update an existing ticket
    @PutMapping("/update/{id}")
    public ResponseEntity<HelpAndSupportTicket> updateTicket(@PathVariable Long id, @Valid @RequestBody HelpAndSupportTicket ticket) {
        HelpAndSupportTicket updatedTicket = helpAndSupportTicketService.updateTicket(id, ticket);
        return updatedTicket != null ? ResponseEntity.ok(updatedTicket) : ResponseEntity.notFound().build();
    }

    // Resolve a support ticket
    @PatchMapping("/resolve/{id}")
    public ResponseEntity<String> resolveTicket(@PathVariable Long id) {
        boolean resolved = helpAndSupportTicketService.resolveTicket(id);
        return resolved ? ResponseEntity.ok("Ticket Resolved") : ResponseEntity.notFound().build();
    }

    @GetMapping("/getAllByEmpId/{empId}")
    public ResponseEntity<List<HelpAndSupportTicket>> getAllByEmpId(@PathVariable Long empId) {
        List<HelpAndSupportTicket> tickets = helpAndSupportTicketService.getAllTicketsByEmployeeId(empId);
        return ResponseEntity.ok(tickets);
    }

}
