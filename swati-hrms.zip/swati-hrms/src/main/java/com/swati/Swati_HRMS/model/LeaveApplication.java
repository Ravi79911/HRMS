package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "leave_application")
public class LeaveApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Auto-increment ID
    private Long id;

    @Column(name = "reason_for_leave", length = 250)
    private String reasonForLeave;

    @Column(name = "description", length = 20000)
    private String description;

    @Column(name = "leave_from")
    private LocalDate leaveFrom;

    @Column(name = "leave_to")
    private LocalDate leaveTo;

    @Column(name = "status")
    private String status;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "suspended_status")
    private Long suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "leave_setup_emp_id", referencedColumnName = "id")
    private LeaveSetupEmployee leaveSetupEmp;
}
