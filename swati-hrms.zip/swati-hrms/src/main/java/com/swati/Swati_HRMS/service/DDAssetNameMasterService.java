package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.DDAssetNameMaster;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface DDAssetNameMasterService {

    DDAssetNameMaster saveAssetName(DDAssetNameMaster ddAssetNameMaster);
    Optional<DDAssetNameMaster> getAssetNameById(Integer id);
    Optional<DDAssetNameMaster> UpdateAssetName(Integer id,DDAssetNameMaster ddAssetNameMaster);
    List<DDAssetNameMaster> getAllAssetNameMaster();
    Optional<DDAssetNameMaster> changeStatusOfAssetNameById(Integer id);
}
