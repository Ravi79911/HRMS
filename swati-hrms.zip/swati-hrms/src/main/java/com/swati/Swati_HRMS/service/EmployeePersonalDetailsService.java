package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.dto.EmployeeStatisticsDTO;
import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface EmployeePersonalDetailsService {

    EmployeePersonalDetails saveEmployeePersonalDetails(EmployeePersonalDetails employeePersonalDetails);

    Optional<EmployeePersonalDetails> updateEmployeePersonalDetails(Long id, EmployeePersonalDetails employeePersonalDetails);

    Optional<EmployeePersonalDetails> changeStatusOfDocumentById(Long id);

    EmployeePersonalDetails findByEmployeeId(String employeeId);

    List<EmployeePersonalDetails> getAllDocument();

    Optional<EmployeePersonalDetails> getEmployeeWithSkills(Long id);

    EmployeeStatisticsDTO getEmployeeStatistics();

    Long getEmployeeCountForDepartmentById(Long departmentId);

}