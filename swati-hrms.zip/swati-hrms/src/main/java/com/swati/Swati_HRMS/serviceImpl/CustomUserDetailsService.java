package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.exception.ResourceNotFoundException;
import com.swati.Swati_HRMS.model.Employee;
import com.swati.Swati_HRMS.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    EmployeeRepository employeeRepository;

    @Override
    public UserDetails loadUserByUsername(String identifier) throws UsernameNotFoundException {
        Employee employee = null;

        if (isValidEmail(identifier)) {
            // find employee by email
            employee = employeeRepository.findByEmail(identifier)
                    .orElseThrow(() -> new ResourceNotFoundException("Employee", "email", identifier));
        } else if (isValidEmployeeId(identifier)) {
            // find employee by employee id
            employee = employeeRepository.findByEmployeeId(identifier)
                    .orElseThrow(() -> new ResourceNotFoundException("Employee", "employee id", identifier));
        } else {
            // find employee by username
            employee = employeeRepository.findByUserName(identifier)
                    .orElseThrow(() -> new ResourceNotFoundException("Employee", "username", identifier));
        }

        // convert roles to authorities
        var authorities = employee.getRole().stream()
                .map(role -> new SimpleGrantedAuthority(role.getRoleName()))
                .collect(Collectors.toList());

        return new User(employee.getUsername(), employee.getPassword(), authorities);
    }

    // utility method to validate email format using regular expression
    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    // utility method to validate employee ID format (3 digits followed by 3 digits, e.g., 339001)
    private boolean isValidEmployeeId(String employeeId) {
        return employeeId != null && employeeId.matches("^[0-9]{3}[0-9]{3}$");
    }

    // utility method to validate mobile number format (10 digits)
//    private boolean isValidMobileNumber(String mobileNo) {
//        return mobileNo != null && mobileNo.matches("^[0-9]{10}$");
//    }

}
