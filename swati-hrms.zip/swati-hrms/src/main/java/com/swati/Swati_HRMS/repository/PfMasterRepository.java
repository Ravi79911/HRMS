package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.PfMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface PfMasterRepository extends JpaRepository<PfMaster,Long> {

    PfMaster findTopBySuspendedStatusOrderByUpdatedDateDesc(int i);
}
