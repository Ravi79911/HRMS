package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.BankDetails;
import com.swati.Swati_HRMS.repository.BankDetailsRepository;
import com.swati.Swati_HRMS.service.BankDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class BankDetailsServiceImpl implements BankDetailsService {

    @Autowired
    private BankDetailsRepository bankDetailsRepository;

    @Override
    public BankDetails saveBankDetails(BankDetails bankDetails) {
        Optional<BankDetails> existingBankDetails = bankDetailsRepository.findByBankNameAndAccountNumber(bankDetails.getBankName(), bankDetails.getAccountNumber());
        if (existingBankDetails.isPresent()) {
            return existingBankDetails.get();
        } else {
            bankDetails.setCreatedDate(LocalDateTime.now());
            bankDetails.setSuspendedStatus(0);
            bankDetails.setUpdatedDate(LocalDateTime.now());
            bankDetails.setUpdatedBy(bankDetails.getCreatedBy());
            return bankDetailsRepository.save(bankDetails);
        }
    }

    @Override
    public Optional<BankDetails> getBankDetails(Long id) {
        return bankDetailsRepository.findById(id);
    }

    @Override
    public String deleteBankDetails(Long id) {
        Optional<BankDetails> bankDetails = bankDetailsRepository.findById(id);
        if (bankDetails.isPresent()) {
            bankDetailsRepository.delete(bankDetails.get());
            return "Bank details deleted successfully";
        } else {
            return "Bank details not found";
        }
    }

    @Override
    public Optional<BankDetails> updateBankDetails(Long id, BankDetails bankDetails) {
        Optional<BankDetails> existingBankDetails = bankDetailsRepository.findById(id);
        if (existingBankDetails.isPresent()) {
            bankDetails.setId(id);
            bankDetails.setUpdatedDate(LocalDateTime.now());
            bankDetails.setUpdatedBy(bankDetails.getCreatedBy());
            return Optional.of(bankDetailsRepository.save(bankDetails));
        } else {
            return Optional.empty();
        }
    }

    @Override
    public List<BankDetails> getAllBankDetails() {
        return bankDetailsRepository.findBySuspendedStatus(0);
    }

    @Override
    public Optional<BankDetails> getBankDetailsByEmpId(Long id) {
        return bankDetailsRepository.findByEmpPerDetailsId_Id(id);
    }

    @Override
    public Optional<BankDetails> changeSuspendedStatus(Long id) {
      Optional<BankDetails> bankDetails = bankDetailsRepository.findById(id);
      if (bankDetails.isPresent()) {
          bankDetails.get().setSuspendedStatus(1);
          return Optional.of(bankDetailsRepository.save(bankDetails.get()));
      }else {
          return Optional.empty();
      }
    }
}
