package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.dto.EmployeePayrollResponse;
import com.swati.Swati_HRMS.model.EmployeePayroll;
import com.swati.Swati_HRMS.model.EmployeePayrollSetup;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface EmployeePayrollService {

//    EmployeePayrollResponse generateAndSavePayroll(EmployeePayrollSetup payrollSetup, String month, Integer year);
EmployeePayrollResponse generateAndSavePayroll(EmployeePayrollSetup payrollSetup, String month, Integer year);
    List<EmployeePayrollResponse> getAllPayrolls();
    Optional<EmployeePayrollResponse> getPayrollByEmpCodeAndPeriod(String empCode, String month, Integer year);
    List<EmployeePayrollResponse> getEmployeePayrollsByDepartment(String department, String month, Integer year);
    Optional<EmployeePayrollResponse> updatePayrollAndApprovedStatus(Long payrollId, EmployeePayroll updatedPayrollData);
    Optional<EmployeePayrollResponse> verifyPayroll(Long payrollId);
    String deletePayroll(Long payrollId);
}
