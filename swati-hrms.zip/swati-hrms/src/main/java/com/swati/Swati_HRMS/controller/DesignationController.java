package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.model.Department;
import com.swati.Swati_HRMS.model.Designation;
import com.swati.Swati_HRMS.service.DesignationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/designation")
public class DesignationController {

    @Autowired
    private DesignationService designationService;

    @PostMapping("/save")
    public ResponseEntity<Designation> saveDesignation(@RequestBody Designation designation){
        return ResponseEntity.ok(designationService.saveDesignation(designation));
    }

    @GetMapping("/all")
    public ResponseEntity<List<Designation>> getAllDesignations(){
        return ResponseEntity.ok(designationService.getAllDesignations());
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Designation> updateDesignation(@PathVariable Long id, @RequestBody Designation updatedDesignation){
        Optional<Designation> updated = designationService.updateDesignationById(id, updatedDesignation);

        return updated.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PatchMapping("/deleteBy/{id}")
    public ResponseEntity<Designation> suspendDesignation(@PathVariable Long id){
        Optional<Designation> updated = designationService.changeStatusOfDesignationById(id);

        return updated.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
