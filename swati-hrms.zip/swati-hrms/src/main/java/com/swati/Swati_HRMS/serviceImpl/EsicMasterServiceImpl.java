package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.model.EsicMaster;
import com.swati.Swati_HRMS.repository.EsicMasterRepository;
import com.swati.Swati_HRMS.service.EsicMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class EsicMasterServiceImpl implements EsicMasterService {

    @Autowired
    private EsicMasterRepository esicMasterRepository;

    @Override
    public EsicMaster saveEsicMaster(EsicMaster esicMaster) {
        LocalDateTime currentDateTime = LocalDateTime.now();
        esicMaster.setCreatedDate(currentDateTime);
        esicMaster.setUpdatedDate(LocalDateTime.now());
        esicMaster.setUpdatedBy(esicMaster.getUpdatedBy() != null ? esicMaster.getUpdatedBy() : 0);
        esicMaster.setSuspendedStatus(esicMaster.getSuspendedStatus() != null ? esicMaster.getSuspendedStatus() : 0);
        return esicMasterRepository.saveAndFlush(esicMaster);
    }

    @Override
    public List<EsicMaster> findAllEsicMaster() {
        return esicMasterRepository.findAll();
    }

    @Override
    public EsicMaster updateEsicMaster(Long id, EsicMaster updatedEsicMaster) {
        Optional<EsicMaster> esicMasterOptional = esicMasterRepository.findById(id);
        if (esicMasterOptional.isPresent()) {
            EsicMaster existingEsicMaster = esicMasterOptional.get();
            existingEsicMaster.setSuspendedStatus(updatedEsicMaster.getSuspendedStatus());
            existingEsicMaster.setEmployeeContributionRate(updatedEsicMaster.getEmployeeContributionRate());
            existingEsicMaster.setEmployerContributionRate(updatedEsicMaster.getEmployerContributionRate());

            return esicMasterRepository.saveAndFlush(existingEsicMaster);
        } else {
            throw new RuntimeException("moduleMaster not found with id: " + id);
        }
    }
}
