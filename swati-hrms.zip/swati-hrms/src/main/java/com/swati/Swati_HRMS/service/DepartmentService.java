package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.Department;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public interface DepartmentService {

    Department saveDepartment(Department department);
    List<Department> getAllDepartments();
    Optional<Department> updateDepartmentById(Long id, Department updatedDepartment);
    Optional<Department> changeStatusOfDepartmentById(Long id);
}
