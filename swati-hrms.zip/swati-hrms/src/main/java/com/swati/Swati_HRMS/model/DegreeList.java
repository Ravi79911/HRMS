package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Set;

@Data
@Entity
@Table(name = "degrees")
public class DegreeList {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Please enter the degree")
    @Column(name = "degree")
    private String degree;

    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspendend_status")
    private Integer suspendedStatus;

    @OneToMany(mappedBy = "degree", cascade = CascadeType.ALL)
    private Set<EmpEducationDetails> empEducationDetails;

}
