package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.model.EmpAsset;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface EmpAssetService {

    EmpAsset saveEmpAsset(EmpAsset empAsset);
    Optional<EmpAsset> getEmpAssetById(Long id);
    Optional<EmpAsset> updateEmpAsset(Long id, EmpAsset empAsset);
    Optional<EmpAsset> changeStatusOfEmpAssetById(Long id);
    List<EmpAsset> getAllEmpAsset();
    List<EmpAsset> findByAssetByEmployeeId(Long id);
}
