package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.dto.EmployeePayrollResponse;
import com.swati.Swati_HRMS.model.*;
import com.swati.Swati_HRMS.repository.EmployeeAttendanceRepository;
import com.swati.Swati_HRMS.repository.EmployeePayrollSetupRepository;
import com.swati.Swati_HRMS.service.EmployeePayrollSetupService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
public class EmployeePayrollSetupServiceImpl implements EmployeePayrollSetupService {

    @Autowired
    EmployeePayrollSetupRepository employeePayrollSetupRepository;

    @Autowired
    private EmployeeAttendanceRepository attendanceRepository;

    @Override
    public EmployeePayrollSetup createEmployeePayrollSetup(EmployeePayrollSetup employeePayrollSetup) {
        try {
            employeePayrollSetup.setUpdatedBy(employeePayrollSetup.getUpdatedBy() != null ? employeePayrollSetup.getUpdatedBy() : 0);
            employeePayrollSetup.setSuspendedStatus(employeePayrollSetup.getSuspendedStatus() != null ? employeePayrollSetup.getSuspendedStatus() : 0);
            employeePayrollSetup.setCreatedDate(LocalDateTime.now());
            employeePayrollSetup.setUpdatedDate(LocalDateTime.now());
            return employeePayrollSetupRepository.saveAndFlush(employeePayrollSetup);
        } catch (Exception ex) {
            log.error("Error occurred while creating employee payroll setup", ex);
            throw new RuntimeException("An error occurred while creating employee payroll setup", ex);
        }
    }

    @Override
    public List<EmployeePayrollSetup> getAllEmployeePayrollSetup() {
        try {
            List<EmployeePayrollSetup> payrollSetups = employeePayrollSetupRepository.findAll();
            if (payrollSetups.isEmpty()) {
                log.warn("No employee payroll setups found");
            }
            return payrollSetups;
        } catch (Exception ex) {
            log.error("Error occurred while fetching employee payroll setups", ex);
            throw new RuntimeException("An error occurred while fetching employee payroll setups", ex);
        }
    }

    @Override
    public Optional<EmployeePayrollSetup> getPayrollSetupsByEmployeeId(Long employeeId) {
        return employeePayrollSetupRepository.findByEmployee_Id(employeeId);
    }

    @Override
    public double calculateGrossSalary(EmployeePayrollSetup payrollSetup) {
        double basicTotal = payrollSetup.getBasicLists().stream()
                .mapToDouble(BasicList::getScaleValue)
                .sum();

        double allowancesTotal = payrollSetup.getAllowanceLists().stream()
                .mapToDouble(AllowanceList::getAllowanceValue)
                .sum();

        return basicTotal  + allowancesTotal;
    }


    @Override
    public double calculateDeductions(EmployeePayrollSetup payrollSetup) {
        double deductionsTotal = payrollSetup.getDeductionLists().stream()
                .mapToDouble(DeductionList::getDeductionValue)
                .sum();
        return deductionsTotal;
    }

    @Override
    public double calculateNetSalary(EmployeePayrollSetup payrollSetup) {
        double grossSalary = calculateGrossSalary(payrollSetup);
        double deductions = calculateDeductions(payrollSetup);
        return grossSalary - deductions;
    }

    @Override
    public List<EmployeePayrollResponse> getAllEmployeePayrolls(String month, Integer year) {
        try {
            List<EmployeePayrollSetup> payrollSetups = employeePayrollSetupRepository.findAll();
            return payrollSetups.stream()
                    .map(setup -> generatePayrollResponse(setup, month, year))
                    .collect(Collectors.toList());
        } catch (Exception ex) {
            log.error("Error occurred while fetching all employee payrolls", ex);
            throw new RuntimeException("An error occurred while fetching all employee payrolls", ex);
        }
    }

    @Override
    public EmployeePayrollResponse getEmployeePayrollByEmpCode(String empCode, String month, Integer year) {
        try {
            Optional<EmployeePayrollSetup> payrollSetup = employeePayrollSetupRepository.findByEmployee_EmployeeId(empCode);
            if (payrollSetup.isEmpty()) {
                log.warn("No payroll setup found for employee code: {}", empCode);
                return null;
            }
            return generatePayrollResponse(payrollSetup.get(), month, year);
        } catch (Exception ex) {
            log.error("Error occurred while fetching payroll for employee code: {}", empCode, ex);
            throw new RuntimeException("An error occurred while fetching payroll for employee code: " + empCode, ex);
        }
    }

    @Override
    public List<EmployeePayrollResponse> getEmployeePayrollsByDepartment(String department, String month, Integer year) {
        try {
            List<EmployeePayrollSetup> payrollSetups = employeePayrollSetupRepository.findByEmployee_Department_Department(department);
            if (payrollSetups.isEmpty()) {
                log.warn("No payroll setups found for department: {}", department);
                return List.of();
            }
            return payrollSetups.stream()
                    .map(setup -> generatePayrollResponse(setup, month, year))
                    .collect(Collectors.toList());
        } catch (Exception ex) {
            log.error("Error occurred while fetching payrolls for department: {}", department, ex);
            throw new RuntimeException("An error occurred while fetching payrolls for department: " + department, ex);
        }
    }



    private EmployeePayrollResponse generatePayrollResponse(EmployeePayrollSetup payrollSetup, String month, Integer year) {
        // Get employee details
        String empCode = payrollSetup.getEmployee().getEmployeeId();
        String empName = payrollSetup.getEmployee().getEmployeeFirstName() + " " + payrollSetup.getEmployee().getEmployeeLastName();
        String department = payrollSetup.getEmployee().getDepartment() != null ?
                payrollSetup.getEmployee().getDepartment().getDepartment() : "Not Assigned";

        // Get attendance for the specified month and year
        Optional<EmployeeAttendance> attendance = attendanceRepository.findByEmployeeIdAndMonthAndYear(
                Integer.parseInt(empCode), month.toLowerCase(), year);

        // Calculate attendance metrics
        int totalWorkingDays = 0;
        int totalPresentDays = 0;
        int totalAbsentDays = 0;

        if (attendance.isPresent()) {
            Map<Integer, String> dailyAttendance = attendance.get().getDailyAttendance();
            totalWorkingDays = dailyAttendance.size();
            totalPresentDays = (int) dailyAttendance.values().stream().filter(status -> status.equals("P")).count();
            totalAbsentDays = totalWorkingDays - totalPresentDays;
        }

        // Calculate salary components
        double basicSalary = payrollSetup.getBasicLists().stream()
                .filter(basic -> basic.getScaleName().equalsIgnoreCase("Basic"))
                .findFirst()
                .map(basic -> basic.getScaleValue())
                .orElse(0.0);

        double hra = payrollSetup.getBasicLists().stream()
                .filter(basic -> basic.getScaleName().equalsIgnoreCase("HRA"))
                .findFirst()
                .map(basic -> basic.getScaleValue())
                .orElse(0.0);

        // Calculate allowances
        double totalAllowances = payrollSetup.getAllowanceLists().stream()
                .mapToDouble(allowance -> allowance.getAllowanceValue())
                .sum();

        // Get individual allowances for display
        Map<String, Double> allowanceBreakdown = payrollSetup.getAllowanceLists().stream()
                .collect(Collectors.toMap(
                        allowance -> allowance.getAllowanceName(),
                        allowance -> allowance.getAllowanceValue()
                ));

        // Calculate gross salary
        double grossSalary = basicSalary + hra + totalAllowances;

        // Calculate deductions
        Map<String, Double> deductionBreakdown = payrollSetup.getDeductionLists().stream()
                .collect(Collectors.toMap(
                        deduction -> deduction.getDeductionName(),
                        deduction -> deduction.getDeductionValue()
                ));

        double pf = deductionBreakdown.getOrDefault("PF", 0.0);
        double esic = deductionBreakdown.getOrDefault("ESIC", 0.0);
        double totalDeductions = payrollSetup.getDeductionLists().stream()
                .mapToDouble(deduction -> deduction.getDeductionValue())
                .sum();

        // Calculate net salary
        double netSalary = grossSalary - totalDeductions;

        // Adjust salary based on attendance if required (pro-rata calculation)
        // Uncomment if you want to implement pro-rata salary calculation
        /*
        if (totalWorkingDays > 0) {
            double attendanceRatio = (double) totalPresentDays / totalWorkingDays;
            grossSalary = grossSalary * attendanceRatio;
            netSalary = grossSalary - totalDeductions;
        }
        */

        // Build and return the response
        return EmployeePayrollResponse.builder()
                .empCode(empCode)
                .empName(empName)
                .department(department)
                .designation(attendance.map(EmployeeAttendance::getDesignation).orElse("Not Available"))
                .month(month)
                .year(year)
                .totalWorkingDays(totalWorkingDays)
                .totalPresentDays(totalPresentDays)
                .totalAbsentDays(totalAbsentDays)
                .basicSalary(basicSalary)
                .hra(hra)
                .allowances(allowanceBreakdown)
                .grossSalary(grossSalary)
                .pf(pf)
                .esic(esic)
                .totalDeductions(totalDeductions)
                .netSalary(netSalary)
                .build();
    }

}
