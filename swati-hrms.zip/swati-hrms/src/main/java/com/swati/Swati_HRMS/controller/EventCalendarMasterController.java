package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.model.EventCalendarMaster;
import com.swati.Swati_HRMS.service.EventCalendarMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/eventCalendarMaster")
public class EventCalendarMasterController {

    @Autowired
    private EventCalendarMasterService eventCalendarMasterService;

    @PostMapping("/saveEventCalendarMaster")
    public ResponseEntity<ApiResponse> saveEventCalendarMaster(@RequestBody EventCalendarMaster eventCalendarMaster) {
        ApiResponse response = ApiResponse.success("Event Calendar Master saved successfully", eventCalendarMasterService.saveEventCalendarMaster(eventCalendarMaster));
        return ResponseEntity.ok(response);
    }

    @PutMapping("/updateEventCalendarMaster/{id}")
    public ResponseEntity<ApiResponse> updateEventCalendarMaster(@PathVariable Long id, @RequestBody EventCalendarMaster eventCalendarMaster) {
        ApiResponse response = ApiResponse.success("Event Calendar Master updated successfully", eventCalendarMasterService.updateEventCalendarMaster(id, eventCalendarMaster));
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getAllEventCalendarMaster")
    public ResponseEntity<ApiResponse> getAllEventCalendarMaster() {
        ApiResponse response = ApiResponse.success("Event Calendar Master fetched successfully", eventCalendarMasterService.getAllEventCalendarMaster());
        return ResponseEntity.ok(response);
    }


    @GetMapping("/getEventCalendarMasterById/{id}")
    public ResponseEntity<ApiResponse> getEventCalendarMasterById(@PathVariable Long id) {
        ApiResponse response = ApiResponse.success("Event Calendar Master fetched successfully", eventCalendarMasterService.getEventCalendarMasterById(id));
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/deleteEventCalendarMasterById/{id}")
    public ResponseEntity<ApiResponse> deleteEventCalendarMasterById(@PathVariable Long id) {
        ApiResponse response = ApiResponse.success("Event Calendar Master deleted successfully", eventCalendarMasterService.deleteEventCalendarMasterById(id));
        return ResponseEntity.ok(response);
    }

    @PatchMapping("/changeStatusOfEventCalendarMasterById/{id}")
    public ResponseEntity<ApiResponse> changeStatusOfEventCalendarMasterById(@PathVariable Long id) {
        ApiResponse response = ApiResponse.success("Event Calendar Master status changed successfully", eventCalendarMasterService.changeStatusOfEventCalendarMasterById(id));
        return ResponseEntity.ok(response);
    }
}
