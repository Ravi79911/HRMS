package com.swati.Swati_HRMS.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmployeePayrollResponse {
    private Long id;
    private String empCode;
    private String empName;
    private String department;
    private String designation;
    private String month;
    private Integer year;
    private Integer totalWorkingDays;
    private Integer totalPresentDays;
    private Integer totalAbsentDays;
    private Double basicSalary;
    private Double hra;
    private Map<String, Double> allowances;
    private Double grossSalary;
    private Double pf;
    private Double esic;
    private Double totalDeductions;
    private Double netSalary;
    private boolean isVerified;

}