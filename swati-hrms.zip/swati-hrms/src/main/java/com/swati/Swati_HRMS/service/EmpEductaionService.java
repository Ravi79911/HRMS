package com.swati.Swati_HRMS.service;

import com.swati.Swati_HRMS.dto.EmpEducationDetailsDTO;
import com.swati.Swati_HRMS.model.EmpEducationDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface EmpEductaionService {

    EmpEducationDetails saveEmpEductaion(EmpEducationDetails empEducationDetails);

    List<EmpEducationDetailsDTO> getEmployeeKeySkillByEmployeePesronalDetailsId(Long id);
}
