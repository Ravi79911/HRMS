package com.swati.Swati_HRMS.dto;

import com.swati.Swati_HRMS.model.Designation;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class EmployeeExperienceDetailsDTO {

    private Long id;
    private String companyName;
    private String designationName;
    private LocalDate fromDate;
    private LocalDate uptoDate;
    private String projectDetails;
    private String createdBy;
    private LocalDateTime createdDate;
    private int suspendedStatus;
    private Designation designation;
}
