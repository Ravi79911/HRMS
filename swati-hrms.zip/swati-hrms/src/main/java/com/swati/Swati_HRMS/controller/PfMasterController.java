package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.model.PfMaster;
import com.swati.Swati_HRMS.service.PfMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/pf/master")
public class PfMasterController {

    @Autowired
    private PfMasterService pfMasterService;

    @PostMapping("/create")
    public ResponseEntity<PfMaster> createPfMaster(@Valid @RequestBody PfMaster pfMaster) {
        PfMaster createdPfMaster = pfMasterService.savePfMaster(pfMaster);
        if (createdPfMaster == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(createdPfMaster);
    }

    @GetMapping("/getAllPfMaster")
    public ResponseEntity<List<PfMaster>> getAllPfMaster() {
        List<PfMaster> pfMasters = pfMasterService.findAllPfMaster();
        return ResponseEntity.ok(pfMasters);
    }

    @PutMapping("/PfMaster/update/{id}")
    public ResponseEntity<PfMaster> updatePfMaster(@PathVariable("id") Long id, @RequestBody PfMaster updatedPfMaster) {
        try {
            PfMaster updated = pfMasterService.updatePfMaster(id, updatedPfMaster);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

}
