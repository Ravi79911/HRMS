package com.swati.Swati_HRMS.exception;

import lombok.Data;

@Data
public class OTPGenerationException extends RuntimeException {

    public OTPGenerationException(String message) {
        super(message);
    }

    public OTPGenerationException(String message, Throwable cause) {
        super(message, cause);
    }

}
