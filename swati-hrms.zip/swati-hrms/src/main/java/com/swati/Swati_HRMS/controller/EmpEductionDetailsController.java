package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.dto.EmpEducationDetailsDTO;
import com.swati.Swati_HRMS.dto.EmployeeKeySkillDTO;
import com.swati.Swati_HRMS.model.EmpEducationDetails;
import com.swati.Swati_HRMS.service.EmpEductaionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/empEductionDetails")
public class EmpEductionDetailsController {

    @Autowired
    private EmpEductaionService empEductaionService;

    @PostMapping("/saveEmpEductionDetails")
    public ResponseEntity<EmpEducationDetails> saveEmpEductionDetails(@RequestBody EmpEducationDetails empEducationDetails) {
        return ResponseEntity.ok(empEductaionService.saveEmpEductaion(empEducationDetails));
    }

    @GetMapping("/getByEmployeeKeySkillByPersonalDetailsId")
    public ResponseEntity<List<EmpEducationDetailsDTO>> getByEmployeeKeySkillId(@RequestParam Long id){
        List<EmpEducationDetailsDTO> employeeEduction = empEductaionService.getEmployeeKeySkillByEmployeePesronalDetailsId(id);
        return ResponseEntity.ok(employeeEduction);
    }
}
