package com.swati.Swati_HRMS.controller;

import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.model.Role;
import com.swati.Swati_HRMS.service.RoleService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/roleMaster")
public class RoleController {

    @Autowired
    RoleService roleService;

    @PostMapping("/createRole")
    public ResponseEntity<ApiResponse> createRole(@Valid @RequestBody Role role) {
        Role createdRole = roleService.createRole(role);
        ApiResponse response = new ApiResponse("role created successfully", true, createdRole);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/getAllRoles")
    public ResponseEntity<ApiResponse> getAllRoles() {
        List<Role> roles = roleService.getAllRoles();
        ApiResponse response = new ApiResponse("roles fetched successfully", true, roles);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/getRoleById/{id}")
    public ResponseEntity<ApiResponse> getRoleById(@PathVariable Long id) {
        Role role = roleService.getRoleById(id);
        ApiResponse response = new ApiResponse("role fetched successfully", true, role);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping("/updateRoleById/{id}")
    public ResponseEntity<ApiResponse> updateRoleById(@PathVariable Long id, @Valid @RequestBody Role role) {
        Role updatedRole = roleService.updateRoleById(id, role);
        ApiResponse response = new ApiResponse("role updated successfully", true, updatedRole);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PatchMapping("/suspendedStatus/{id}")
    public ResponseEntity<ApiResponse> updateSuspendedStatus(@PathVariable Long id, @RequestParam Integer suspendedStatus, @RequestParam int updatedBy) {
        Role updatedRole = roleService.updateSuspendedStatus(id, suspendedStatus, updatedBy);
        ApiResponse response = new ApiResponse("suspended status updated successfully", true, updatedRole);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
