package com.swati.Swati_HRMS.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
@Table(name = "employee_master")
public class Employee implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotBlank(message = "employee Id can't be empty")
    @Column(name = "employee_ids")
    private String employeeId;

    @NotBlank(message = "name of user can't be empty")
    @Column(name = "name_of_user", nullable = false)
    private String employeeName;

    @NotBlank(message = "father's name can't be empty")
    @Column(name = "father_name", nullable = false)
    private String fatherName;

    @NotBlank(message = "department is mandatory")
    @Column(name = "department", nullable = false)
    private String department;

    @NotBlank(message = "address can't be empty")
    @Column(name = "address", nullable = false)
    private String address;

    @Email(message = "email should be valid")
    @Column(name = "email", nullable = false)
    private String email;

    @Pattern(regexp = "^[0-9]{10}$", message = "mobile number must be 10 digits")
    @Column(name = "mobile_no", nullable = false)
    private String mobileNo;

    @Past(message = "date of birth must be in the past")
    @Column(name = "dob", nullable = false)
    private LocalDate dateOfBirth;

    @Column(name = "user_picture")
    private String userPicture;

    @NotBlank(message = "username can't be empty")
    @Column(name = "user_name", nullable = false)
    private String userName;

    @NotBlank(message = "password is required")
    @Size(min = 8, message = "password must be at least 8 characters long")
//    @Pattern(regexp = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$%&_?])[A-Za-z\\d@#$%&_?]{8,}$",
//            message = "Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, one number, and one special character (@#$%&_?)")
    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "is_email_verified")
    private boolean isEmailVerified;

//    @Column(name = "is_mobile_verified")
//    private boolean isMobileVerified;

    @Column(name = "is_verify")
    private boolean isVerified;

    @Column(name = "email_otp")
    private String emailOtp;

    @Column(name = "email_otp_time_stamp")
    private LocalDateTime emailOtpGeneratedDateTime;

//    @Column(name = "mobile_otp")
//    private String mobileOtp;
//
//    @Column(name = "mobile_otp_time_stamp")
//    private LocalDateTime mobileOtpGeneratedDateTime;

    @Column(name = "token")
    private String token;

    @Column(name = "fcm_token")
    private String fcmToken;

    @Column(name = "token_time_stamp")
    private LocalDateTime tokenGeneratedDateTime;

//    @Column(name = "ip_address")
//    private String ipAddress;

    @NotNull(message = "created by is required")
    @Column(name = "created_by", nullable = false)
    private Integer createdBy;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_date", nullable = false)
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

//    @ManyToOne
//    @JoinColumn(name = "role_id", referencedColumnName = "id", nullable = false)
//    private Role role;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "employee_roles",
            joinColumns = @JoinColumn(name = "employee_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "role_id", referencedColumnName = "id")
    )
    private List<Role> role;

    @ManyToOne
    @JoinColumn(name = "emp_per_id", referencedColumnName = "id")
    private EmployeePersonalDetails employeePersonalDetails;

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        if (role == null || role.isEmpty()) {
            return List.of();
        }
        return List.of(new SimpleGrantedAuthority(role.get(0).getRoleName()));
    }

    @Override
    public String getUsername() {
        return this.getEmail();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

}
