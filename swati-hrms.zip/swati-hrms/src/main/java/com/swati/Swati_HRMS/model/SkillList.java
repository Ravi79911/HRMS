package com.swati.Swati_HRMS.model;


import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Data
@Entity
@Table(name = "key_skills")
public class SkillList {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "skill_name")
	private String skillName;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private LocalDateTime createdDate;

	@Column(name = "updated_by")
	private String updatedBy;

	@Column(name = "updated_date")
	private LocalDateTime updatedDate;

	@Column(name = "suspendend_status")
	private int suspendedStatus;

	@OneToMany(mappedBy = "skillList", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<EmployeeKeySkill> KeySkills;
}
