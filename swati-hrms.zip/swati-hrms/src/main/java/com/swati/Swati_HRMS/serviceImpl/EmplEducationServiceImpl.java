package com.swati.Swati_HRMS.serviceImpl;

import com.swati.Swati_HRMS.dto.EmpEducationDetailsDTO;
import com.swati.Swati_HRMS.dto.EmployeeKeySkillDTO;
import com.swati.Swati_HRMS.model.EmpEducationDetails;
import com.swati.Swati_HRMS.model.EmployeeKeySkill;
import com.swati.Swati_HRMS.repository.EmpEducationRepository;
import com.swati.Swati_HRMS.service.EmpEductaionService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmplEducationServiceImpl implements EmpEductaionService {

    @Autowired
    private EmpEducationRepository empEducationRepository;

    @Autowired
    private ModelMapper modelMapper;


    @Override
    public EmpEducationDetails saveEmpEductaion(EmpEducationDetails empEducationDetails) {
        empEducationDetails.setCreatedDate(LocalDateTime.now());
        empEducationDetails.setSuspendedStatus(0);
        return empEducationRepository.save(empEducationDetails);
    }

    @Override
    public List<EmpEducationDetailsDTO> getEmployeeKeySkillByEmployeePesronalDetailsId(Long id) {
        List<EmpEducationDetails> empEducationDetailsDTOS = empEducationRepository.findByEmployeePersonalDetails_Id(id);
        return empEducationDetailsDTOS.stream()
                .map(skill -> modelMapper.map(skill, EmpEducationDetailsDTO.class))
                .collect(Collectors.toList());
    }


}
