package com.swati.Swati_HRMS.controller;


import com.swati.Swati_HRMS.exception.ApiResponse;
import com.swati.Swati_HRMS.model.DDWorkMode;
import com.swati.Swati_HRMS.service.DDWorkModeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/dd/workmode")
public class DDWorkModeController {

    @Autowired
    private DDWorkModeService ddWorkModeService;

    @PostMapping("/saveDDWorkMode")
    public ResponseEntity<?> saveDDWorkMode(@RequestBody DDWorkMode ddWorkMode) {
        ApiResponse response = ApiResponse.success("DD Work Mode saved successfully", ddWorkModeService.saveDDWorkMode(ddWorkMode));
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getAllDDWorkMode")
    public ResponseEntity<?> getAllDDWorkMode() {
        ApiResponse response = ApiResponse.success("DD Work Mode fetched successfully", ddWorkModeService.getAllDDWorkMode());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getDDWorkModeById/{id}")
    public ResponseEntity<?> getDDWorkModeById(@PathVariable Long id) {
        ApiResponse response = ApiResponse.success("DD Work Mode fetched successfully", ddWorkModeService.getDDWorkModeById(id));
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/deleteDDWorkMode/{id}")
    public ResponseEntity<?> deleteDDWorkMode(@PathVariable Long id) {
        ApiResponse response = ApiResponse.success("DD Work Mode deleted successfully", ddWorkModeService.deleteDDWorkMode(id));
        return ResponseEntity.ok(response);
    }
}
