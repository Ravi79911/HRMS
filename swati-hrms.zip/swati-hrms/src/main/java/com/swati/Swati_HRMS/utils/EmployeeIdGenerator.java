package com.swati.Swati_HRMS.utils;

import com.swati.Swati_HRMS.service.EmployeeIdCounterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeIdGenerator {

    @Autowired
    EmployeeIdCounterService employeeIdCounterService;

    private static final String EMPLOYEE_ID_PREFIX = "339";

    public String generateEmployeeId() {
        int uniqueNumber = employeeIdCounterService.getNextCounterValue("employee_id") % 100;
        String uniqueNumberPart = String.format("%03d", uniqueNumber);
        return EMPLOYEE_ID_PREFIX + uniqueNumberPart;
    }

}