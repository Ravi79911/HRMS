package com.swati.Swati_HRMS.repository;

import com.swati.Swati_HRMS.model.EmployeePersonalDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface EmployeePersonalDetailsRepository extends JpaRepository<EmployeePersonalDetails, Long> {

    List<EmployeePersonalDetails> findBySuspendedStatus(int suspendedStatus);

    Optional<EmployeePersonalDetails> findByEmployeeId(String employeeId);

    @Query("SELECT COUNT(e) FROM EmployeePersonalDetails e WHERE e.gender = :gender AND e.suspendedStatus = 0")
    Long countByGender(String gender);

    @Query("SELECT COUNT(e) FROM EmployeePersonalDetails e WHERE e.suspendedStatus = 0")
    Long countActiveEmployees();

    @Query("SELECT COUNT(e) FROM EmployeePersonalDetails e WHERE e.department.id = :departmentId")
    Long countByDepartmentId(Long departmentId);

}