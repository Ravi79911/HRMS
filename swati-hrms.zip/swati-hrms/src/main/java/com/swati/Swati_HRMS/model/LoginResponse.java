package com.swati.Swati_HRMS.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class LoginResponse {

    private String message;
    private Long employeeId;
    private String employeeCode;
    private Long employeePersonalDetailsId;
    private String email;
    private String userName;
    private String mobileNo;
    private String role;

}
